﻿using System.Windows.Forms;
using System;

namespace GestionEcolePrimaire
{
    public partial class ClasseForm : Form
    {
        private Otulis otulis;

        public ClasseForm()
        {
            InitializeComponent();
            otulis = new Otulis();
        }

        private void ClasseForm_Load(object sender, EventArgs e)
        {
            string queryNiveaux = "SELECT Code_Niveau, Libelle_Niveau FROM Niveaux";
            otulis.ChargementCBM(queryNiveaux, comboBoxNiveau);
            LoadClasses();
        }

        private void LoadClasses()
        {
            string queryClasses =
          "SELECT " +
          "c.Code_Classe, " +
          "c.Libelle_Classe AS Nom_Classe, " +
          "c.Code_Niveau, " +
          "n.Libelle_Niveau AS Niveau, " +
          "c.Capacite_Max_Eleve AS Capacite_Max, " +
          "c.Nb_Actuel_Eleve AS Eleves_Actuels, " +
          "(SELECT COUNT(*) FROM Affectations_Classe ac WHERE ac.Code_Classe = c.Code_Classe) AS Nb_Enseignants " +
          "FROM Classe c, Niveaux n " +
          "WHERE c.Code_Niveau = n.Code_Niveau";
            try
            {
                otulis.ChargementDVG(queryClasses, dataGridViewClasses, null);
                if (dataGridViewClasses.Columns["Code_Classe"] != null)
                    dataGridViewClasses.Columns["Code_Classe"].HeaderText = "Code Classe";
                if (dataGridViewClasses.Columns["Nom_Classe"] != null)
                    dataGridViewClasses.Columns["Nom_Classe"].HeaderText = "Nom Classe";
                if (dataGridViewClasses.Columns["Code_Niveau"] != null)
                    dataGridViewClasses.Columns["Code_Niveau"].HeaderText = "Code Niveau";
                if (dataGridViewClasses.Columns["Niveau"] != null)
                    dataGridViewClasses.Columns["Niveau"].HeaderText = "Niveau";
                if (dataGridViewClasses.Columns["Capacite_Max"] != null)
                    dataGridViewClasses.Columns["Capacite_Max"].HeaderText = "Capacité Max";
                if (dataGridViewClasses.Columns["Eleves_Actuels"] != null)
                    dataGridViewClasses.Columns["Eleves_Actuels"].HeaderText = "Élèves Actuels";
                if (dataGridViewClasses.Columns["Nb_Enseignants"] != null)
                    dataGridViewClasses.Columns["Nb_Enseignants"].HeaderText = "Nb Enseignants";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des classes : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            int codeClasse = int.Parse(txtCodeClasse.Text);
            int codeNiveau = int.Parse(comboBoxNiveau.SelectedValue.ToString());
            string libelleClasse = txtLibelleClasse.Text.Replace("'", "''");
            int capaciteMaximale = int.Parse(txtCapaciteMaximale.Text);
            int nbElevesActuel = ParseOrZero(txtNbElevesActuel.Text);

            string checkQuery = "SELECT * FROM Classe WHERE Code_Classe = " + codeClasse;
            try
            {
                bool classExists = otulis.RequttedeRecherche(checkQuery);
                if (classExists)
                {
                    MessageBox.Show("Une classe avec ce Code_Classe existe déjà.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                //codeNiveau;
                string insertQuery =
                    "INSERT INTO Classe (Code_Classe, Code_Niveau, Libelle_Classe, Capacite_Max_Eleve, Nb_Actuel_Eleve) " +
                    "VALUES (" + codeClasse + ", " + comboBoxNiveau.SelectedValue.ToString() + ", '" + libelleClasse + "', " + capaciteMaximale + ", " + nbElevesActuel + ")";

                otulis.RequtteMiseAjour(insertQuery);
                MessageBox.Show("Classe ajoutée avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadClasses();
                ClearInputs();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de l'ajout de la classe : {ex.Message} {ex.StackTrace}",
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModifier_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;

            if (comboBoxNiveau.SelectedValue == null || comboBoxNiveau.SelectedIndex == -1)
            {
                MessageBox.Show("Veuillez sélectionner un niveau valide dans le ComboBox.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            txtCodeNiveau.Text = comboBoxNiveau.SelectedValue.ToString();

            int codeClasse = int.Parse(txtCodeClasse.Text);
            int codeNiveau = int.Parse(txtCodeNiveau.Text);
            string libelleClasse = txtLibelleClasse.Text.Replace("'", "''");
            int capaciteMaximale = int.Parse(txtCapaciteMaximale.Text);
            int nbElevesActuel = ParseOrZero(txtNbElevesActuel.Text);

            if (nbElevesActuel > capaciteMaximale)
            {
                MessageBox.Show("Le nombre d'élèves actuels ne peut pas dépasser la capacité maximale.",
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query =
                "UPDATE Classe SET " +
                "Code_Niveau = " + codeNiveau + ", " +
                "Libelle_Classe = '" + libelleClasse + "', " +
                "Capacite_Max_Eleve = " + capaciteMaximale + ", " +
                "Nb_Actuel_Eleve = " + nbElevesActuel + " " +
                "WHERE Code_Classe = " + codeClasse;

            try
            {
                otulis.RequtteMiseAjour(query);
                MessageBox.Show("Classe modifiée avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadClasses();
                ClearInputs();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la modification de la classe : {ex.Message}\nStack Trace: {ex.StackTrace}",
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodeClasse.Text))
            {
                MessageBox.Show("Veuillez sélectionner une classe à supprimer.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int codeClasse = int.Parse(txtCodeClasse.Text);

            string query = "DELETE FROM Classe WHERE Code_Classe = " + codeClasse;

            try
            {
                otulis.RequtteMiseAjour(query);
                MessageBox.Show("Classe supprimée avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadClasses();
                ClearInputs();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la suppression de la classe : {ex.Message}\nStack Trace: {ex.StackTrace}",
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRechercher_Click(object sender, EventArgs e)
        {
            string searchTerm = txtRechercher.Text.Trim();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                try
                {
                    int.Parse(searchTerm);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Veuillez entrer un Code Niveau valide (nombre entier).", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            string query =
                "SELECT " +
                "c.Code_Classe, " +
                "c.Libelle_Classe, " +
                "c.Code_Niveau, " +
                "n.Libelle_Niveau, " +
                "c.Capacite_Max_Eleve, " +
                "c.Nb_Actuel_Eleve, " +
                "(SELECT COUNT(*) FROM Affectations_Classe ac WHERE ac.Code_Classe = c.Code_Classe) " +
                "FROM Classe c, Niveaux n " +
                "WHERE c.Code_Niveau = n.Code_Niveau" +
                (string.IsNullOrEmpty(searchTerm) ? "" : " AND c.Code_Niveau = " + searchTerm);

            try
            {
                otulis.ChargementDVG(query, dataGridViewClasses, null);
                if (dataGridViewClasses.Columns["Code_Classe"] != null)
                    dataGridViewClasses.Columns["Code_Classe"].HeaderText = "Code Classe";
                if (dataGridViewClasses.Columns["Libelle_Classe"] != null)
                    dataGridViewClasses.Columns["Libelle_Classe"].HeaderText = "Nom Classe";
                if (dataGridViewClasses.Columns["Code_Niveau"] != null)
                    dataGridViewClasses.Columns["Code_Niveau"].HeaderText = "Code Niveau";
                if (dataGridViewClasses.Columns["Libelle_Niveau"] != null)
                    dataGridViewClasses.Columns["Libelle_Niveau"].HeaderText = "Niveau";
                if (dataGridViewClasses.Columns["Capacite_Max_Eleve"] != null)
                    dataGridViewClasses.Columns["Capacite_Max_Eleve"].HeaderText = "Capacité Max";
                if (dataGridViewClasses.Columns["Nb_Actuel_Eleve"] != null)
                    dataGridViewClasses.Columns["Nb_Actuel_Eleve"].HeaderText = "Élèves Actuels";
                if (dataGridViewClasses.Columns["Column1"] != null)
                    dataGridViewClasses.Columns["Column1"].HeaderText = "Nb Enseignants";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la recherche : {ex.Message}\nStack Trace: {ex.StackTrace}",
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridViewClasses_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewClasses.Rows[e.RowIndex];
                txtCodeClasse.Text = row.Cells["Code_Classe"].Value.ToString();
                txtCodeNiveau.Text = row.Cells["Code_Niveau"].Value.ToString();
                //comboBoxNiveau.SelectedValue = row.Cells["Code_Niveau"].Value;
                comboBoxNiveau.SelectedIndex = comboBoxNiveau.FindStringExact(row.Cells["Niveau"].Value.ToString());
                txtLibelleClasse.Text = row.Cells["Nom_Classe"].Value.ToString();
                txtCapaciteMaximale.Text = row.Cells["Capacite_Max"].Value.ToString();
                txtNbElevesActuel.Text = row.Cells["Eleves_Actuels"].Value.ToString();
            }
        }

        private void comboBoxNiveau_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxNiveau.SelectedValue != null)
            {
                txtCodeNiveau.Text = comboBoxNiveau.SelectedValue.ToString();
            }
        }

        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtCodeClasse.Text))
            {
                MessageBox.Show("Le champ Code Classe est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            //if (string.IsNullOrWhiteSpace(txtCodeNiveau.Text))
            //{
                //MessageBox.Show("Le champ Code Niveau est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //return false;
            //}

            if (string.IsNullOrWhiteSpace(txtLibelleClasse.Text))
            {
                MessageBox.Show("Le champ Libellé Classe est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtCapaciteMaximale.Text))
            {
                MessageBox.Show("Le champ Capacité Maximale est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            try
            {
                int.Parse(txtCodeClasse.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Le Code Classe doit être un nombre entier.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            int codeNiveau;
            //txtCodeNiveau.Text
            try
            {
                codeNiveau = int.Parse(comboBoxNiveau.SelectedValue.ToString());
            }
            catch (FormatException)
            {
                MessageBox.Show("Le Code Niveau doit être un nombre entier.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            string checkNiveauQuery = $"SELECT * FROM Niveaux WHERE Code_Niveau = {codeNiveau}";
            if (!otulis.RequttedeRecherche(checkNiveauQuery))
            {
                MessageBox.Show("Le Code Niveau saisi n'existe pas dans la table Niveaux.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            int capaciteMaximale;
            try
            {
                capaciteMaximale = int.Parse(txtCapaciteMaximale.Text);
                if (capaciteMaximale <= 0)
                {
                    MessageBox.Show("La Capacité Maximale doit être un nombre entier positif.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("La Capacité Maximale doit être un nombre entier positif.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (!string.IsNullOrWhiteSpace(txtNbElevesActuel.Text))
            {
                try
                {
                    int nbEleves = int.Parse(txtNbElevesActuel.Text);
                    if (nbEleves < 0)
                    {
                        MessageBox.Show("Le nombre d'élèves actuels doit être un nombre entier non négatif.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Le nombre d'élèves actuels doit être un nombre entier non négatif.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }

            return true;
        }

        private void ClearInputs()
        {
            txtCodeClasse.Text = "";
            txtCodeNiveau.Text = "";
            comboBoxNiveau.SelectedIndex = -1;
            txtLibelleClasse.Text = "";
            txtCapaciteMaximale.Text = "";
            txtNbElevesActuel.Text = "";
            txtRechercher.Text = "";
        }

        private void btn_voirEleves_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodeClasse.Text))
            {
                MessageBox.Show("Veuillez sélectionner une classe pour voir les élèves.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int codeClasse = int.Parse(txtCodeClasse.Text);
            VoirElevesForm f1 = new VoirElevesForm(codeClasse);
            f1.Show();
        }

        private void dataGridViewClasses_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

       
        private int ParseOrZero(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return 0;
            try
            {
                return Convert.ToInt32(input);
            }
            catch
            {
                return 0;
            }
        }
    }
}
