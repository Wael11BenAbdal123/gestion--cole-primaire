﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.CompilerServices.RuntimeHelpers;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace GestionEcolePrimaire
{
    
    public partial class modifierutilisateur : Form
    {
        private Outils outils = new Outils();
        private int codeutilisateur; 
        public modifierutilisateur(int codeutilisateur, string NomUtilisateur, string roleutilisateur, string email, string motDePasse)
        {
            InitializeComponent();
            this.codeutilisateur = codeutilisateur;
            txtCode.Text = codeutilisateur.ToString();
            txtCode.ReadOnly = true;
            txtNom.Text = NomUtilisateur;
            txtEmail.Text = email;
            txtMotDePasse.Text = motDePasse;

            ChargerRoles(roleutilisateur);

            btnEnregistrer.Click += new EventHandler(btnenregistrer_Click);
            btnAnnuler.Click += new EventHandler(btnannuler_Click);

            txtNom.Focus();
        }
        private void ChargerRoles(string roleActuel)
        {
            try
            {
                
                string query = "SELECT DISTINCT Role_Utilisateur FROM Utilisateur WHERE Role_Utilisateur IS NOT NULL";
                DataTable rolesTable = outils.GetDataTable(query);

              
                txtRole.DataSource = rolesTable;
                txtRole.DisplayMember = "Role_Utilisateur";
                txtRole.ValueMember = "Role_Utilisateur";

                if (!string.IsNullOrEmpty(roleActuel))
                {
                    txtRole.SelectedValue = roleActuel;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des rôles : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnenregistrer_Click(object sender, EventArgs e)
        {
            try
            {
              
                if (string.IsNullOrWhiteSpace(txtNom.Text))
                {
                    MessageBox.Show("Le champ Nom Utilisateur est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (txtRole.SelectedValue == null)
                {
                    MessageBox.Show("Veuillez sélectionner un rôle.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    MessageBox.Show("Le champ Email est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMotDePasse.Text))
                {
                    MessageBox.Show("Le champ Mot de Passe est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                //éviter les erreurs SQL
                string nomUtilisateur = txtNom.Text.Replace("'", "''");
                string roleUtilisateur = txtRole.SelectedValue.ToString().Replace("'", "''");
                string email = txtEmail.Text.Replace("'", "''");
                string motDePasse = txtMotDePasse.Text.Replace("'", "''");

                // Construire la requête SQL
                string query = "UPDATE Utilisateur SET Nom_Utilisateur = '" + nomUtilisateur + "', Role_Utilisateur = '" + roleUtilisateur + "', Email = '" + email + "', Mot_De_Passe_Hash = '" + motDePasse + "' WHERE Code_Utilisateur = " + codeutilisateur;

                outils.RequtteMiseAjour(query);

                MessageBox.Show("Utilisateur modifié avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la modification de l'utilisateur : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnannuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void modifierutilisateur_Load(object sender, EventArgs e)
        {

        }
    }
}
