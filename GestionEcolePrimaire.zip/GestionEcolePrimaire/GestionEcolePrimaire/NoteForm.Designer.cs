﻿namespace GestionEcolePrimaire
{
    partial class NoteForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NoteForm));
            this.lblAnneeScolaire = new System.Windows.Forms.Label();
            this.cmbAnneeScolaire = new System.Windows.Forms.ComboBox();
            this.lblNiveau = new System.Windows.Forms.Label();
            this.cmbNiveau = new System.Windows.Forms.ComboBox();
            this.lblClasse = new System.Windows.Forms.Label();
            this.cmbClasse = new System.Windows.Forms.ComboBox();
            this.lblTrimestre = new System.Windows.Forms.Label();
            this.cmbTrimestre = new System.Windows.Forms.ComboBox();
            this.lblMatiere = new System.Windows.Forms.Label();
            this.cmbMatiere = new System.Windows.Forms.ComboBox();
            this.lblTypeEvaluation = new System.Windows.Forms.Label();
            this.cmbTypeEvaluation = new System.Windows.Forms.ComboBox();
            this.dgvEleves = new System.Windows.Forms.DataGridView();
            this.btnValider = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEleves)).BeginInit();
            this.SuspendLayout();
            // 
            // lblAnneeScolaire
            // 
            this.lblAnneeScolaire.AutoSize = true;
            this.lblAnneeScolaire.Location = new System.Drawing.Point(27, 25);
            this.lblAnneeScolaire.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAnneeScolaire.Name = "lblAnneeScolaire";
            this.lblAnneeScolaire.Size = new System.Drawing.Size(103, 16);
            this.lblAnneeScolaire.TabIndex = 0;
            this.lblAnneeScolaire.Text = "Année scolaire :";
            // 
            // cmbAnneeScolaire
            // 
            this.cmbAnneeScolaire.DisplayMember = "Libelle_Annee";
            this.cmbAnneeScolaire.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAnneeScolaire.Location = new System.Drawing.Point(160, 25);
            this.cmbAnneeScolaire.Margin = new System.Windows.Forms.Padding(4);
            this.cmbAnneeScolaire.Name = "cmbAnneeScolaire";
            this.cmbAnneeScolaire.Size = new System.Drawing.Size(265, 24);
            this.cmbAnneeScolaire.TabIndex = 1;
            this.cmbAnneeScolaire.ValueMember = "Code_Annee";
            this.cmbAnneeScolaire.SelectedIndexChanged += new System.EventHandler(this.cmbAnneeScolaire_SelectedIndexChanged);
            // 
            // lblNiveau
            // 
            this.lblNiveau.AutoSize = true;
            this.lblNiveau.Location = new System.Drawing.Point(27, 62);
            this.lblNiveau.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNiveau.Name = "lblNiveau";
            this.lblNiveau.Size = new System.Drawing.Size(56, 16);
            this.lblNiveau.TabIndex = 2;
            this.lblNiveau.Text = "Niveau :";
            // 
            // cmbNiveau
            // 
            this.cmbNiveau.DisplayMember = "Libelle_Niveau";
            this.cmbNiveau.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNiveau.Location = new System.Drawing.Point(160, 62);
            this.cmbNiveau.Margin = new System.Windows.Forms.Padding(4);
            this.cmbNiveau.Name = "cmbNiveau";
            this.cmbNiveau.Size = new System.Drawing.Size(265, 24);
            this.cmbNiveau.TabIndex = 3;
            this.cmbNiveau.ValueMember = "Code_Niveau";
            this.cmbNiveau.SelectedIndexChanged += new System.EventHandler(this.cmbNiveau_SelectedIndexChanged);
            // 
            // lblClasse
            // 
            this.lblClasse.AutoSize = true;
            this.lblClasse.Location = new System.Drawing.Point(27, 98);
            this.lblClasse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblClasse.Name = "lblClasse";
            this.lblClasse.Size = new System.Drawing.Size(55, 16);
            this.lblClasse.TabIndex = 4;
            this.lblClasse.Text = "Classe :";
            // 
            // cmbClasse
            // 
            this.cmbClasse.DisplayMember = "Libelle_Classe";
            this.cmbClasse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClasse.Location = new System.Drawing.Point(160, 98);
            this.cmbClasse.Margin = new System.Windows.Forms.Padding(4);
            this.cmbClasse.Name = "cmbClasse";
            this.cmbClasse.Size = new System.Drawing.Size(265, 24);
            this.cmbClasse.TabIndex = 5;
            this.cmbClasse.ValueMember = "Code_Classe";
            this.cmbClasse.SelectedIndexChanged += new System.EventHandler(this.cmbClasse_SelectedIndexChanged);
            // 
            // lblTrimestre
            // 
            this.lblTrimestre.AutoSize = true;
            this.lblTrimestre.Location = new System.Drawing.Point(27, 135);
            this.lblTrimestre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTrimestre.Name = "lblTrimestre";
            this.lblTrimestre.Size = new System.Drawing.Size(70, 16);
            this.lblTrimestre.TabIndex = 6;
            this.lblTrimestre.Text = "Trimestre :";
            // 
            // cmbTrimestre
            // 
            this.cmbTrimestre.DisplayMember = "Libelle_Trimestre";
            this.cmbTrimestre.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTrimestre.Location = new System.Drawing.Point(160, 135);
            this.cmbTrimestre.Margin = new System.Windows.Forms.Padding(4);
            this.cmbTrimestre.Name = "cmbTrimestre";
            this.cmbTrimestre.Size = new System.Drawing.Size(265, 24);
            this.cmbTrimestre.TabIndex = 7;
            this.cmbTrimestre.ValueMember = "Code_Trimestre";
            this.cmbTrimestre.SelectedIndexChanged += new System.EventHandler(this.cmbTrimestre_SelectedIndexChanged);
            // 
            // lblMatiere
            // 
            this.lblMatiere.AutoSize = true;
            this.lblMatiere.Location = new System.Drawing.Point(27, 172);
            this.lblMatiere.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatiere.Name = "lblMatiere";
            this.lblMatiere.Size = new System.Drawing.Size(58, 16);
            this.lblMatiere.TabIndex = 8;
            this.lblMatiere.Text = "Matière :";
            // 
            // cmbMatiere
            // 
            this.cmbMatiere.DisplayMember = "Libelle_Matiere";
            this.cmbMatiere.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMatiere.Location = new System.Drawing.Point(160, 172);
            this.cmbMatiere.Margin = new System.Windows.Forms.Padding(4);
            this.cmbMatiere.Name = "cmbMatiere";
            this.cmbMatiere.Size = new System.Drawing.Size(265, 24);
            this.cmbMatiere.TabIndex = 9;
            this.cmbMatiere.ValueMember = "Code_Matiere";
            this.cmbMatiere.SelectedIndexChanged += new System.EventHandler(this.cmbMatiere_SelectedIndexChanged);
            // 
            // lblTypeEvaluation
            // 
            this.lblTypeEvaluation.AutoSize = true;
            this.lblTypeEvaluation.Location = new System.Drawing.Point(27, 209);
            this.lblTypeEvaluation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTypeEvaluation.Name = "lblTypeEvaluation";
            this.lblTypeEvaluation.Size = new System.Drawing.Size(121, 16);
            this.lblTypeEvaluation.TabIndex = 10;
            this.lblTypeEvaluation.Text = "Type d\'évaluation :";
            // 
            // cmbTypeEvaluation
            // 
            this.cmbTypeEvaluation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTypeEvaluation.Location = new System.Drawing.Point(160, 209);
            this.cmbTypeEvaluation.Margin = new System.Windows.Forms.Padding(4);
            this.cmbTypeEvaluation.Name = "cmbTypeEvaluation";
            this.cmbTypeEvaluation.Size = new System.Drawing.Size(265, 24);
            this.cmbTypeEvaluation.TabIndex = 11;
            // 
            // dgvEleves
            // 
            this.dgvEleves.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEleves.Location = new System.Drawing.Point(27, 246);
            this.dgvEleves.Margin = new System.Windows.Forms.Padding(4);
            this.dgvEleves.Name = "dgvEleves";
            this.dgvEleves.RowHeadersWidth = 51;
            this.dgvEleves.Size = new System.Drawing.Size(747, 369);
            this.dgvEleves.TabIndex = 12;
            // 
            // btnValider
            // 
            this.btnValider.Location = new System.Drawing.Point(247, 635);
            this.btnValider.Margin = new System.Windows.Forms.Padding(4);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(142, 29);
            this.btnValider.TabIndex = 13;
            this.btnValider.Text = "Valider";
            this.btnValider.Click += new System.EventHandler(this.btnValider_Click);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(409, 635);
            this.btnAnnuler.Margin = new System.Windows.Forms.Padding(4);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(142, 29);
            this.btnAnnuler.TabIndex = 14;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // NoteForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 677);
            this.Controls.Add(this.lblAnneeScolaire);
            this.Controls.Add(this.cmbAnneeScolaire);
            this.Controls.Add(this.lblNiveau);
            this.Controls.Add(this.cmbNiveau);
            this.Controls.Add(this.lblClasse);
            this.Controls.Add(this.cmbClasse);
            this.Controls.Add(this.lblTrimestre);
            this.Controls.Add(this.cmbTrimestre);
            this.Controls.Add(this.lblMatiere);
            this.Controls.Add(this.cmbMatiere);
            this.Controls.Add(this.lblTypeEvaluation);
            this.Controls.Add(this.cmbTypeEvaluation);
            this.Controls.Add(this.dgvEleves);
            this.Controls.Add(this.btnValider);
            this.Controls.Add(this.btnAnnuler);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "NoteForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gestion des Notes";
            this.Load += new System.EventHandler(this.NoteForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEleves)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAnneeScolaire;
        private System.Windows.Forms.ComboBox cmbAnneeScolaire;
        private System.Windows.Forms.Label lblNiveau;
        private System.Windows.Forms.ComboBox cmbNiveau;
        private System.Windows.Forms.Label lblClasse;
        private System.Windows.Forms.ComboBox cmbClasse;
        private System.Windows.Forms.Label lblTrimestre;
        private System.Windows.Forms.ComboBox cmbTrimestre;
        private System.Windows.Forms.Label lblMatiere;
        private System.Windows.Forms.ComboBox cmbMatiere;
        private System.Windows.Forms.Label lblTypeEvaluation;
        private System.Windows.Forms.ComboBox cmbTypeEvaluation;
        private System.Windows.Forms.DataGridView dgvEleves;
        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.Button btnAnnuler;
    }
}