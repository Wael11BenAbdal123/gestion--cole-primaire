﻿namespace GestionEcolePrimaire
{
    partial class Gestiondesutilisateurs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.filtrer = new System.Windows.Forms.ComboBox();
            this.dgv_enreg = new System.Windows.Forms.DataGridView();
            this.nb_tot = new System.Windows.Forms.Label();
            this.bt_ajouter = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRechercher = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_enreg)).BeginInit();
            this.SuspendLayout();
            // 
            // filtrer
            // 
            this.filtrer.FormattingEnabled = true;
            this.filtrer.Location = new System.Drawing.Point(12, 115);
            this.filtrer.Name = "filtrer";
            this.filtrer.Size = new System.Drawing.Size(121, 21);
            this.filtrer.TabIndex = 0;
            this.filtrer.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dgv_enreg
            // 
            this.dgv_enreg.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgv_enreg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_enreg.Location = new System.Drawing.Point(0, 154);
            this.dgv_enreg.Name = "dgv_enreg";
            this.dgv_enreg.Size = new System.Drawing.Size(802, 190);
            this.dgv_enreg.TabIndex = 1;
            this.dgv_enreg.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // nb_tot
            // 
            this.nb_tot.AutoSize = true;
            this.nb_tot.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nb_tot.Location = new System.Drawing.Point(9, 360);
            this.nb_tot.Name = "nb_tot";
            this.nb_tot.Size = new System.Drawing.Size(148, 14);
            this.nb_tot.TabIndex = 2;
            this.nb_tot.Text = "Nombres tota lutilisateurs :0";
            this.nb_tot.Click += new System.EventHandler(this.label1_Click);
            // 
            // bt_ajouter
            // 
            this.bt_ajouter.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_ajouter.Location = new System.Drawing.Point(594, 375);
            this.bt_ajouter.Name = "bt_ajouter";
            this.bt_ajouter.Size = new System.Drawing.Size(157, 23);
            this.bt_ajouter.TabIndex = 4;
            this.bt_ajouter.Text = "Ajouter utilisateur";
            this.bt_ajouter.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(301, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "Gestion des utilisateurs";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 14);
            this.label1.TabIndex = 6;
            this.label1.Text = "Filtrer :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(383, 118);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 14);
            this.label2.TabIndex = 7;
            this.label2.Text = "Rechercher :";
            // 
            // txtRechercher
            // 
            this.txtRechercher.Location = new System.Drawing.Point(480, 115);
            this.txtRechercher.Name = "txtRechercher";
            this.txtRechercher.Size = new System.Drawing.Size(154, 20);
            this.txtRechercher.TabIndex = 8;
            // 
            // Gestiondesutilisateurs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtRechercher);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.bt_ajouter);
            this.Controls.Add(this.nb_tot);
            this.Controls.Add(this.dgv_enreg);
            this.Controls.Add(this.filtrer);
            this.Name = "Gestiondesutilisateurs";
            this.Text = "Gestiondesutilisateurs";
            this.Load += new System.EventHandler(this.Gestiondesutilisateurs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_enreg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox filtrer;
        private System.Windows.Forms.DataGridView dgv_enreg;
        private System.Windows.Forms.Label nb_tot;
        private System.Windows.Forms.Button bt_ajouter;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRechercher;
    }
}