﻿using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    partial class affectationEleve
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbClasse = new System.Windows.Forms.ComboBox();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.btnEnregistrer = new System.Windows.Forms.Button();
            this.dgvElevesAffectes = new System.Windows.Forms.DataGridView();
            this.lblElevesAffectes = new System.Windows.Forms.Label();
            this.dgvElevesEnAttente = new System.Windows.Forms.DataGridView();
            this.btnRetirer = new System.Windows.Forms.Button();
            this.btnAffecter = new System.Windows.Forms.Button();
            this.btnChargerDonnees = new System.Windows.Forms.Button();
            this.cmbAnneeScolaire = new System.Windows.Forms.ComboBox();
            this.lblAnneeScolaire = new System.Windows.Forms.Label();
            this.cmbNiveau = new System.Windows.Forms.ComboBox();
            this.lblNiveau = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvElevesAffectes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvElevesEnAttente)).BeginInit();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel.Controls.Add(this.label4);
            this.panel.Controls.Add(this.label3);
            this.panel.Controls.Add(this.label2);
            this.panel.Controls.Add(this.label1);
            this.panel.Controls.Add(this.cmbClasse);
            this.panel.Controls.Add(this.btnAnnuler);
            this.panel.Controls.Add(this.btnEnregistrer);
            this.panel.Controls.Add(this.dgvElevesAffectes);
            this.panel.Controls.Add(this.lblElevesAffectes);
            this.panel.Controls.Add(this.dgvElevesEnAttente);
            this.panel.Controls.Add(this.btnRetirer);
            this.panel.Controls.Add(this.btnAffecter);
            this.panel.Controls.Add(this.btnChargerDonnees);
            this.panel.Controls.Add(this.cmbAnneeScolaire);
            this.panel.Controls.Add(this.lblAnneeScolaire);
            this.panel.Controls.Add(this.cmbNiveau);
            this.panel.Controls.Add(this.lblNiveau);
            this.panel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel.Location = new System.Drawing.Point(0, 0);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(800, 450);
            this.panel.TabIndex = 0;
            this.panel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(295, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 18);
            this.label2.TabIndex = 16;
            this.label2.Text = "Affectations des éleves";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 14);
            this.label1.TabIndex = 15;
            this.label1.Text = "Classe";
            // 
            // cmbClasse
            // 
            this.cmbClasse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClasse.FormattingEnabled = true;
            this.cmbClasse.Location = new System.Drawing.Point(53, 109);
            this.cmbClasse.Name = "cmbClasse";
            this.cmbClasse.Size = new System.Drawing.Size(150, 21);
            this.cmbClasse.TabIndex = 14;
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnnuler.Location = new System.Drawing.Point(170, 408);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(100, 30);
            this.btnAnnuler.TabIndex = 13;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            // 
            // btnEnregistrer
            // 
            this.btnEnregistrer.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnregistrer.Location = new System.Drawing.Point(40, 408);
            this.btnEnregistrer.Name = "btnEnregistrer";
            this.btnEnregistrer.Size = new System.Drawing.Size(100, 30);
            this.btnEnregistrer.TabIndex = 12;
            this.btnEnregistrer.Text = "Sauvegarder";
            this.btnEnregistrer.UseVisualStyleBackColor = true;
            // 
            // dgvElevesAffectes
            // 
            this.dgvElevesAffectes.BackgroundColor = System.Drawing.Color.White;
            this.dgvElevesAffectes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvElevesAffectes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvElevesAffectes.Location = new System.Drawing.Point(438, 184);
            this.dgvElevesAffectes.Name = "dgvElevesAffectes";
            this.dgvElevesAffectes.Size = new System.Drawing.Size(350, 200);
            this.dgvElevesAffectes.TabIndex = 11;
            this.dgvElevesAffectes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvElevesAffectes_CellContentClick);
            // 
            // lblElevesAffectes
            // 
            this.lblElevesAffectes.AutoSize = true;
            this.lblElevesAffectes.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElevesAffectes.Location = new System.Drawing.Point(657, 160);
            this.lblElevesAffectes.Name = "lblElevesAffectes";
            this.lblElevesAffectes.Size = new System.Drawing.Size(113, 14);
            this.lblElevesAffectes.TabIndex = 10;
            this.lblElevesAffectes.Text = "Élèves affectés : 0 / 0";
            // 
            // dgvElevesEnAttente
            // 
            this.dgvElevesEnAttente.BackgroundColor = System.Drawing.Color.White;
            this.dgvElevesEnAttente.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvElevesEnAttente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvElevesEnAttente.Location = new System.Drawing.Point(20, 184);
            this.dgvElevesEnAttente.Name = "dgvElevesEnAttente";
            this.dgvElevesEnAttente.Size = new System.Drawing.Size(350, 200);
            this.dgvElevesEnAttente.TabIndex = 9;
            // 
            // btnRetirer
            // 
            this.btnRetirer.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetirer.Location = new System.Drawing.Point(376, 296);
            this.btnRetirer.Name = "btnRetirer";
            this.btnRetirer.Size = new System.Drawing.Size(40, 30);
            this.btnRetirer.TabIndex = 8;
            this.btnRetirer.Text = "←";
            this.btnRetirer.UseVisualStyleBackColor = true;
            // 
            // btnAffecter
            // 
            this.btnAffecter.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAffecter.Location = new System.Drawing.Point(376, 217);
            this.btnAffecter.Name = "btnAffecter";
            this.btnAffecter.Size = new System.Drawing.Size(40, 30);
            this.btnAffecter.TabIndex = 7;
            this.btnAffecter.Text = "→";
            this.btnAffecter.UseVisualStyleBackColor = true;
            // 
            // btnChargerDonnees
            // 
            this.btnChargerDonnees.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChargerDonnees.Location = new System.Drawing.Point(660, 53);
            this.btnChargerDonnees.Name = "btnChargerDonnees";
            this.btnChargerDonnees.Size = new System.Drawing.Size(100, 30);
            this.btnChargerDonnees.TabIndex = 6;
            this.btnChargerDonnees.Text = "Charger";
            this.btnChargerDonnees.UseVisualStyleBackColor = true;
            // 
            // cmbAnneeScolaire
            // 
            this.cmbAnneeScolaire.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAnneeScolaire.FormattingEnabled = true;
            this.cmbAnneeScolaire.Location = new System.Drawing.Point(257, 109);
            this.cmbAnneeScolaire.Name = "cmbAnneeScolaire";
            this.cmbAnneeScolaire.Size = new System.Drawing.Size(150, 21);
            this.cmbAnneeScolaire.TabIndex = 4;
            // 
            // lblAnneeScolaire
            // 
            this.lblAnneeScolaire.AutoSize = true;
            this.lblAnneeScolaire.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAnneeScolaire.Location = new System.Drawing.Point(254, 82);
            this.lblAnneeScolaire.Name = "lblAnneeScolaire";
            this.lblAnneeScolaire.Size = new System.Drawing.Size(80, 14);
            this.lblAnneeScolaire.TabIndex = 3;
            this.lblAnneeScolaire.Text = "Année Scolaire";
            // 
            // cmbNiveau
            // 
            this.cmbNiveau.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNiveau.FormattingEnabled = true;
            this.cmbNiveau.Location = new System.Drawing.Point(50, 50);
            this.cmbNiveau.Name = "cmbNiveau";
            this.cmbNiveau.Size = new System.Drawing.Size(150, 21);
            this.cmbNiveau.TabIndex = 2;
            this.cmbNiveau.SelectedIndexChanged += new System.EventHandler(this.cmbNiveau_SelectedIndexChanged);
            // 
            // lblNiveau
            // 
            this.lblNiveau.AutoSize = true;
            this.lblNiveau.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNiveau.Location = new System.Drawing.Point(50, 30);
            this.lblNiveau.Name = "lblNiveau";
            this.lblNiveau.Size = new System.Drawing.Size(42, 14);
            this.lblNiveau.TabIndex = 1;
            this.lblNiveau.Text = "Niveau";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 14);
            this.label3.TabIndex = 17;
            this.label3.Text = "Eleves non affectés";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(453, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 14);
            this.label4.TabIndex = 18;
            this.label4.Text = "Eleves affectés";
            // 
            // affectationEleve
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel);
            this.Name = "affectationEleve";
            this.Text = "Affectation des Élèves";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.affectationEleve_Resize);
            this.panel.ResumeLayout(false);
            this.panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvElevesAffectes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvElevesEnAttente)).EndInit();
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.ComboBox cmbNiveau;
        private System.Windows.Forms.ComboBox cmbAnneeScolaire;
        private System.Windows.Forms.ComboBox cmbClasse;
        private System.Windows.Forms.Button btnChargerDonnees;
        private System.Windows.Forms.DataGridView dgvElevesEnAttente;
        private System.Windows.Forms.DataGridView dgvElevesAffectes;
        private System.Windows.Forms.Button btnAffecter;
        private System.Windows.Forms.Button btnRetirer;
        private System.Windows.Forms.Label lblElevesAffectes;
        private System.Windows.Forms.Button btnEnregistrer;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Label lblNiveau;
        private System.Windows.Forms.Label lblAnneeScolaire;
        private Label label2;
        private Label label1;
        private Label label4;
        private Label label3;
    }
}