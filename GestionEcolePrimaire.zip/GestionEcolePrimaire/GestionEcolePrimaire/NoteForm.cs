﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class NoteForm : Form
    {
        private Otulis otulis = new Otulis();
        private string codeEnseignant;
        private DataTable dtEleves = new DataTable();
        public NoteForm(string codeEnseignant)
        {
            this.codeEnseignant = codeEnseignant;
            string Nom = otulis.Selection("select Nom_Utilisateur from Utilisateur where Code_Utilisateur="+ this.codeEnseignant + ";");
            InitializeComponent();
            
            this.Text ="Gestion des Notes - Enseignant "+Nom;
        }

        private void NoteForm_Load(object sender, EventArgs e)
        {
            InitialiserGrille();
            otulis.ChargementCBM("SELECT Code_Annee, Libelle_Annee FROM AnneeScolaire", cmbAnneeScolaire);
            cmbNiveau.Enabled = false;
            cmbClasse.Enabled = false;
            cmbTrimestre.Enabled = false;
            cmbMatiere.Enabled = false;
            cmbTypeEvaluation.Items.AddRange(new string[] { "Examen", "Oral" });
            if (cmbAnneeScolaire.Items.Count > 0) cmbAnneeScolaire.SelectedIndex = 0;
            if (cmbTypeEvaluation.Items.Count > 0) cmbTypeEvaluation.SelectedIndex = 0;
        }
        private void InitialiserGrille()
        {
            dtEleves.Columns.Add("EleveID", typeof(int));
            dtEleves.Columns.Add("NomEleve", typeof(string));
            dtEleves.Columns.Add("Note", typeof(decimal));
            dtEleves.Columns.Add("Commentaire", typeof(string));
            dgvEleves.DataSource = dtEleves;
            dgvEleves.Columns["NomEleve"].HeaderText = "Nom Élève";
            dgvEleves.Columns["NomEleve"].ReadOnly = true;
            dgvEleves.Columns["NomEleve"].Width = 200;
            dgvEleves.Columns["Note"].HeaderText = "Note (0-20)";
            dgvEleves.Columns["Note"].Width = 100;
            dgvEleves.Columns["Commentaire"].HeaderText = "Commentaire";
            dgvEleves.Columns["Commentaire"].Width = 200;
        }

        private void cmbAnneeScolaire_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbAnneeScolaire.SelectedValue != null)
            {
                try
                {
                    otulis.ChargementCBM("SELECT Code_Niveau, Libelle_Niveau FROM Niveaux WHERE Code_Niveau IN " + "(SELECT DISTINCT NiveauID FROM Inscription WHERE AnneeID = " + cmbAnneeScolaire.SelectedValue.ToString() + ")", cmbNiveau);
                    cmbNiveau.Enabled = true;
                    cmbClasse.Enabled = false;
                    cmbTrimestre.Enabled = false;
                    cmbMatiere.Enabled = false;
                    dtEleves.Rows.Clear(); 
                }
                catch (Exception ex)
                {
                    //MessageBox.Show($"Erreur lors du chargement des niveaux : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void cmbNiveau_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbNiveau.SelectedValue != null)
            {
                otulis.ChargementCBM("SELECT Code_Classe, Libelle_Classe FROM Classe WHERE Code_Niveau = " + cmbNiveau.SelectedValue + " AND Code_Classe IN (SELECT Code_Classe FROM Affectations_Classe WHERE Code_Enseignant = " + codeEnseignant + ")", cmbClasse);
                cmbClasse.Enabled = true;
                cmbTrimestre.Enabled = false;
                cmbMatiere.Enabled = false;
                dtEleves.Rows.Clear();
            }
        }
        private void cmbClasse_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbClasse.SelectedValue != null)
            {
                otulis.ChargementCBM("SELECT Code_Trimestre, Libelle_Trimestre FROM Trimestre", cmbTrimestre);
                cmbTrimestre.Enabled = true;
                cmbMatiere.Enabled = false;
                dtEleves.Rows.Clear();
            }
        }
        private void cmbTrimestre_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbTrimestre.SelectedValue != null)
            {
                otulis.ChargementCBM("SELECT Code_Matiere, Libelle_Matiere FROM Matiere WHERE Code_Matiere IN " + "(SELECT Code_Matiere FROM Responsabilites_Enseignant WHERE Code_Enseignant = " + codeEnseignant + ")", cmbMatiere);
                cmbMatiere.Enabled = true;
                dtEleves.Rows.Clear();
            }
        }
        private void cmbMatiere_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMatiere.SelectedValue != null)
            {
                ChargerEleves();
            }
        }

        private void ChargerEleves()
        {
            dtEleves.Rows.Clear();
            try
            {
                if (cmbAnneeScolaire.SelectedValue == null || cmbNiveau.SelectedValue == null || cmbClasse.SelectedValue == null)
                {
                    MessageBox.Show("Veuillez sélectionner tous les filtres.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string anneeId = cmbAnneeScolaire.SelectedValue.ToString();
                string niveauId = cmbNiveau.SelectedValue.ToString();
                string classeId = cmbClasse.SelectedValue.ToString();
                string sql = "SELECT e.Num_Ins_Eleve, e.Nom_Eleve + ' ' + e.Prenom_Eleve AS NomEleve " +
                       "FROM Eleve e, Inscription i, Classe c " +
                       "WHERE e.Num_Ins_Eleve = i.EleveID " +
                       "AND i.ClasseID = c.Code_Classe " +
                       "AND i.AnneeID = " + anneeId +
                       " AND i.NiveauID = " + niveauId +
                       " AND i.ClasseID = " + classeId +
                       " AND c.Code_Classe IN (SELECT Code_Classe FROM Affectations_Classe WHERE Code_Enseignant = " + codeEnseignant + ")";
                DataTable dt = otulis.GetDataTable(sql);
                foreach (DataRow row in dt.Rows)
                {
                    dtEleves.Rows.Add(row["Num_Ins_Eleve"], row["NomEleve"], null, null);
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show($"Erreur lors du chargement des élèves : {ex.Message}\nRequête :", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnValider_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataRow row in dtEleves.Rows)
                {
                    if (row["Note"] != DBNull.Value)
                    {
                        string noteString = row["Note"].ToString().Replace(",", ".");
                        decimal note = Convert.ToDecimal(noteString, CultureInfo.InvariantCulture);
                        if (note < 0 || note > 20)
                        {
                            MessageBox.Show($"La note pour {row["NomEleve"]} doit être entre 0 et 20.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                        string checkSql = "SELECT COUNT(*) FROM Note WHERE EleveID = " + row["EleveID"] +
                   " AND AnneeScolaireID = " + cmbAnneeScolaire.SelectedValue +
                   " AND NiveauID = " + cmbNiveau.SelectedValue +
                   " AND MatiereID = " + cmbMatiere.SelectedValue +
                   " AND SeanceExamenID = " + cmbTrimestre.SelectedValue +
                   " AND TypeEvaluation = '" + cmbTypeEvaluation.SelectedItem + "'";

                        int existingNoteCount = Convert.ToInt32(otulis.Selection(checkSql));
                        if (existingNoteCount > 0)
                        {
                            MessageBox.Show($"Une note existe déjà pour {row["NomEleve"]} avec ces critères. Elle ne sera pas réinsérée.",
                                "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            continue; 
                        }
                        string commentaire = row["Commentaire"]?.ToString() ?? "";
                        string sql = "INSERT INTO Note (EleveID, MatiereID, SeanceExamenID, AnneeScolaireID, NiveauID, TypeEvaluation, ValeurNote, Code_Enseignant, Commentaire) " +
             "VALUES (" + row["EleveID"] + ", " + cmbMatiere.SelectedValue + ", " + cmbTrimestre.SelectedValue + ", " +
             cmbAnneeScolaire.SelectedValue + ", " + cmbNiveau.SelectedValue + ", '" + cmbTypeEvaluation.SelectedItem + "', " +
             noteString + ", " + codeEnseignant + ", '" + commentaire + "')";

                        otulis.RequtteMiseAjour(sql);
                    }
                }
                MessageBox.Show("Notes enregistrées avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cmbAnneeScolaire.SelectedIndex = -1; 
                cmbNiveau.SelectedIndex = -1;        
                cmbClasse.SelectedIndex = -1;        
                cmbTrimestre.SelectedIndex = -1;   
                cmbMatiere.SelectedIndex = -1; 
                cmbTypeEvaluation.SelectedIndex = 0;
                cmbNiveau.Enabled = false;
                cmbClasse.Enabled = false;
                cmbTrimestre.Enabled = false;
                cmbMatiere.Enabled = false;
                dtEleves.Rows.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'enregistrement : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}