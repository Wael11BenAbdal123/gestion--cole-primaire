﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class GestionInscription : Form
    {
        Otulis otulis = new Otulis();

        public GestionInscription()
        {
            InitializeComponent();
        }
        private void GestionInscription_Load(object sender, EventArgs e)
        {
            string sqlAnnees = "SELECT Code_Annee, Libelle_Annee FROM AnneeScolaire";
            otulis.ChargementCBM(sqlAnnees, cmbAnneeScolaire);
            string sqlNiveaux = "SELECT Code_Niveau, Libelle_Niveau FROM Niveaux";
            otulis.ChargementCBM(sqlNiveaux, cmbNiveau);
            cmbAnneeScolaire.SelectedIndexChanged -= cmbAnneeScolaire_SelectedIndexChanged;
            cmbNiveau.SelectedIndexChanged -= cmbNiveau_SelectedIndexChanged;
            if (cmbAnneeScolaire.Items.Count > 0)
            {
                cmbAnneeScolaire.SelectedIndex = 0;
            }
            if (cmbNiveau.Items.Count > 0)
            {
                cmbNiveau.SelectedIndex = 0;
            }
            ChargerInscriptions();
            dgvInscriptions.Columns.Add(new DataGridViewButtonColumn
            {
                Name = "Modifier",
                HeaderText = "Modification",
                Text = "Modifier",
                UseColumnTextForButtonValue = true
            });
            dgvInscriptions.Columns.Add(new DataGridViewButtonColumn
            {
                Name = "Supprimer",
                HeaderText = "Suppression",
                Text = "Supprimer",
                UseColumnTextForButtonValue = true
            });
            cmbAnneeScolaire.SelectedIndexChanged += cmbAnneeScolaire_SelectedIndexChanged;
            cmbNiveau.SelectedIndexChanged += cmbNiveau_SelectedIndexChanged;
        }
        private void ChargerInscriptions()
        {
            try
            {
                int parsedAnneeId = (cmbAnneeScolaire.SelectedValue != null) ? int.Parse(cmbAnneeScolaire.SelectedValue.ToString()) : 1;
                int parsedNiveauId = (cmbNiveau.SelectedValue != null) ? int.Parse(cmbNiveau.SelectedValue.ToString()) : 1;

                string sql = "SELECT i.EleveID AS 'N° Insc', " +
                             "e.Nom_Eleve AS 'Nom', " +
                             "e.Prenom_Eleve AS 'Prénom', " +
                             "n.Libelle_Niveau AS 'Niveau', " +
                             "i.Statut " +
                             "FROM Inscription i, Eleve e, Niveaux n " +
                             "WHERE i.EleveID = e.Num_Ins_Eleve " +
                             "AND i.NiveauID = n.Code_Niveau " +
                             "AND i.AnneeID = " + parsedAnneeId +
                             " AND i.NiveauID = " + parsedNiveauId + ";";

                otulis.ChargementDVG(sql, dgvInscriptions, txtNombre);
            }
            catch (FormatException)
            {
                //MessageBox.Show("Erreur : Les valeurs sélectionnées ne sont pas valides.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des inscriptions : " + ex.Message);
            }
        }
        private void cmbAnneeScolaire_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChargerInscriptions();
        }
        private void cmbNiveau_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChargerInscriptions();
        }

        private void btnNouvelleInscription_Click(object sender, EventArgs e)
        {
            NouvelleInscriptionForm inscriptionForm = new NouvelleInscriptionForm();
            inscriptionForm.ShowDialog();
            ChargerInscriptions();
        }
        private void dgvInscriptions_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int eleveId = int.Parse(dgvInscriptions.Rows[e.RowIndex].Cells["N° Insc"].Value.ToString());
                int anneeId = int.Parse(cmbAnneeScolaire.SelectedValue.ToString());

                if (e.ColumnIndex == dgvInscriptions.Columns["Modifier"].Index)
                {
                    ModifierInscriptionForm modifierForm = new ModifierInscriptionForm(eleveId);
                    modifierForm.ShowDialog();
                    ChargerInscriptions();
                }
                else if (e.ColumnIndex == dgvInscriptions.Columns["Supprimer"].Index)
                {
                    if (MessageBox.Show("Voulez-vous vraiment supprimer cette inscription ?", "Confirmation",MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        string sql = "DELETE FROM Inscription WHERE EleveID = " + eleveId + " AND AnneeID = " + anneeId + ";";
                        otulis.RequtteMiseAjour(sql);
                        ChargerInscriptions();
                        MessageBox.Show("Inscription supprimée avec succès.");
                    }
                }
            }
        }
    }
}