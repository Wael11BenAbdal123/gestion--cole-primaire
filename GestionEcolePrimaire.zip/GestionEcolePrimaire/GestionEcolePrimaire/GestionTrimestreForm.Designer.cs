﻿namespace GestionEcolePrimaire
{
    partial class GestionTrimestreForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dvgTrimestres = new System.Windows.Forms.DataGridView();
            this.txtRecherche = new System.Windows.Forms.TextBox();
            this.txtTotalTrimestres = new System.Windows.Forms.TextBox();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.lblRecherche = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dvgTrimestres)).BeginInit();
            this.SuspendLayout();
            // 
            // dvgTrimestres
            // 
            this.dvgTrimestres.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgTrimestres.Location = new System.Drawing.Point(14, 53);
            this.dvgTrimestres.Name = "dvgTrimestres";
            this.dvgTrimestres.RowHeadersWidth = 51;
            this.dvgTrimestres.Size = new System.Drawing.Size(640, 320);
            this.dvgTrimestres.TabIndex = 0;
            this.dvgTrimestres.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvgTrimestres_CellContentClick);
            // 
            // txtRecherche
            // 
            this.txtRecherche.Location = new System.Drawing.Point(114, 13);
            this.txtRecherche.Name = "txtRecherche";
            this.txtRecherche.Size = new System.Drawing.Size(228, 22);
            this.txtRecherche.TabIndex = 1;
            this.txtRecherche.TextChanged += new System.EventHandler(this.txtRecherche_TextChanged);
            // 
            // txtTotalTrimestres
            // 
            this.txtTotalTrimestres.Location = new System.Drawing.Point(125, 387);
            this.txtTotalTrimestres.Name = "txtTotalTrimestres";
            this.txtTotalTrimestres.ReadOnly = true;
            this.txtTotalTrimestres.Size = new System.Drawing.Size(134, 22);
            this.txtTotalTrimestres.TabIndex = 2;
            this.txtTotalTrimestres.TextChanged += new System.EventHandler(this.txtTotalTrimestres_TextChanged);
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(457, 384);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(171, 32);
            this.btnAjouter.TabIndex = 3;
            this.btnAjouter.Text = "Ajouter un trimestre";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // lblRecherche
            // 
            this.lblRecherche.AutoSize = true;
            this.lblRecherche.Location = new System.Drawing.Point(14, 16);
            this.lblRecherche.Name = "lblRecherche";
            this.lblRecherche.Size = new System.Drawing.Size(83, 16);
            this.lblRecherche.TabIndex = 4;
            this.lblRecherche.Text = "Rechercher :";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(14, 387);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(105, 16);
            this.lblTotal.TabIndex = 5;
            this.lblTotal.Text = "Total trimestres :";
            // 
            // GestionTrimestreForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(667, 438);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblRecherche);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.txtTotalTrimestres);
            this.Controls.Add(this.txtRecherche);
            this.Controls.Add(this.dvgTrimestres);
            this.Name = "GestionTrimestreForm";
            this.Text = "Gestion des Trimestres";
            ((System.ComponentModel.ISupportInitialize)(this.dvgTrimestres)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.DataGridView dvgTrimestres;
        private System.Windows.Forms.TextBox txtRecherche;
        private System.Windows.Forms.TextBox txtTotalTrimestres;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Label lblRecherche;
        private System.Windows.Forms.Label lblTotal;
    }
}