﻿namespace GestionEcolePrimaire
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gestionDesInscptionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saisirDesNotesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.affectationsDesElevesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionPersonneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionUtlisateursToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enseignatsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionNivauxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionMatieresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionClassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionPeriodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionTrimstreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestionAnneeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionDesInscptionsToolStripMenuItem,
            this.saisirDesNotesToolStripMenuItem,
            this.affectationsDesElevesToolStripMenuItem,
            this.gestionPersonneToolStripMenuItem,
            this.gestionNivauxToolStripMenuItem,
            this.gestionMatieresToolStripMenuItem,
            this.gestionClassToolStripMenuItem,
            this.gestionPeriodeToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1178, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gestionDesInscptionsToolStripMenuItem
            // 
            this.gestionDesInscptionsToolStripMenuItem.Name = "gestionDesInscptionsToolStripMenuItem";
            this.gestionDesInscptionsToolStripMenuItem.Size = new System.Drawing.Size(170, 24);
            this.gestionDesInscptionsToolStripMenuItem.Text = "Gestion des inscptions";
            this.gestionDesInscptionsToolStripMenuItem.Click += new System.EventHandler(this.gestionDesInscptionsToolStripMenuItem_Click);
            // 
            // saisirDesNotesToolStripMenuItem
            // 
            this.saisirDesNotesToolStripMenuItem.Name = "saisirDesNotesToolStripMenuItem";
            this.saisirDesNotesToolStripMenuItem.Size = new System.Drawing.Size(125, 24);
            this.saisirDesNotesToolStripMenuItem.Text = "Saisir des notes";
            this.saisirDesNotesToolStripMenuItem.Click += new System.EventHandler(this.saisirDesNotesToolStripMenuItem_Click);
            // 
            // affectationsDesElevesToolStripMenuItem
            // 
            this.affectationsDesElevesToolStripMenuItem.Name = "affectationsDesElevesToolStripMenuItem";
            this.affectationsDesElevesToolStripMenuItem.Size = new System.Drawing.Size(175, 24);
            this.affectationsDesElevesToolStripMenuItem.Text = "Affectations des eleves";
            this.affectationsDesElevesToolStripMenuItem.Click += new System.EventHandler(this.affectationsDesElevesToolStripMenuItem_Click);
            // 
            // gestionPersonneToolStripMenuItem
            // 
            this.gestionPersonneToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionUtlisateursToolStripMenuItem,
            this.enseignatsToolStripMenuItem});
            this.gestionPersonneToolStripMenuItem.Name = "gestionPersonneToolStripMenuItem";
            this.gestionPersonneToolStripMenuItem.Size = new System.Drawing.Size(136, 24);
            this.gestionPersonneToolStripMenuItem.Text = "Gestion Personne";
            // 
            // gestionUtlisateursToolStripMenuItem
            // 
            this.gestionUtlisateursToolStripMenuItem.Name = "gestionUtlisateursToolStripMenuItem";
            this.gestionUtlisateursToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.gestionUtlisateursToolStripMenuItem.Text = "Gestion Utlisateurs";
            this.gestionUtlisateursToolStripMenuItem.Click += new System.EventHandler(this.gestionUtlisateursToolStripMenuItem_Click);
            // 
            // enseignatsToolStripMenuItem
            // 
            this.enseignatsToolStripMenuItem.Name = "enseignatsToolStripMenuItem";
            this.enseignatsToolStripMenuItem.Size = new System.Drawing.Size(215, 26);
            this.enseignatsToolStripMenuItem.Text = "Enseignats";
            this.enseignatsToolStripMenuItem.Click += new System.EventHandler(this.enseignatsToolStripMenuItem_Click);
            // 
            // gestionNivauxToolStripMenuItem
            // 
            this.gestionNivauxToolStripMenuItem.Name = "gestionNivauxToolStripMenuItem";
            this.gestionNivauxToolStripMenuItem.Size = new System.Drawing.Size(122, 24);
            this.gestionNivauxToolStripMenuItem.Text = "Gestion Nivaux";
            this.gestionNivauxToolStripMenuItem.Click += new System.EventHandler(this.gestionNivauxToolStripMenuItem_Click);
            // 
            // gestionMatieresToolStripMenuItem
            // 
            this.gestionMatieresToolStripMenuItem.Name = "gestionMatieresToolStripMenuItem";
            this.gestionMatieresToolStripMenuItem.Size = new System.Drawing.Size(134, 24);
            this.gestionMatieresToolStripMenuItem.Text = "Gestion Matieres";
            this.gestionMatieresToolStripMenuItem.Click += new System.EventHandler(this.gestionMatieresToolStripMenuItem_Click);
            // 
            // gestionClassToolStripMenuItem
            // 
            this.gestionClassToolStripMenuItem.Name = "gestionClassToolStripMenuItem";
            this.gestionClassToolStripMenuItem.Size = new System.Drawing.Size(110, 24);
            this.gestionClassToolStripMenuItem.Text = "Gestion Class";
            this.gestionClassToolStripMenuItem.Click += new System.EventHandler(this.gestionClassToolStripMenuItem_Click);
            // 
            // gestionPeriodeToolStripMenuItem
            // 
            this.gestionPeriodeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestionTrimstreToolStripMenuItem,
            this.gestionAnneeToolStripMenuItem});
            this.gestionPeriodeToolStripMenuItem.Name = "gestionPeriodeToolStripMenuItem";
            this.gestionPeriodeToolStripMenuItem.Size = new System.Drawing.Size(127, 24);
            this.gestionPeriodeToolStripMenuItem.Text = "Gestion Periode";
            // 
            // gestionTrimstreToolStripMenuItem
            // 
            this.gestionTrimstreToolStripMenuItem.Name = "gestionTrimstreToolStripMenuItem";
            this.gestionTrimstreToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.gestionTrimstreToolStripMenuItem.Text = "Gestion Trimstre";
            this.gestionTrimstreToolStripMenuItem.Click += new System.EventHandler(this.gestionTrimstreToolStripMenuItem_Click);
            // 
            // gestionAnneeToolStripMenuItem
            // 
            this.gestionAnneeToolStripMenuItem.Name = "gestionAnneeToolStripMenuItem";
            this.gestionAnneeToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.gestionAnneeToolStripMenuItem.Text = "Gestion Annee";
            this.gestionAnneeToolStripMenuItem.Click += new System.EventHandler(this.gestionAnneeToolStripMenuItem_Click);
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1178, 482);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gestionDesInscptionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saisirDesNotesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem affectationsDesElevesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionPersonneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionUtlisateursToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionNivauxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enseignatsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionMatieresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionClassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionPeriodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionTrimstreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestionAnneeToolStripMenuItem;
    }
}