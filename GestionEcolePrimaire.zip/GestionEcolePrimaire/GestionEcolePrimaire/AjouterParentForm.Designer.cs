﻿namespace GestionEcolePrimaire
{
    partial class AjouterParentForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblNom = new System.Windows.Forms.Label();
            this.txtNomParent = new System.Windows.Forms.TextBox();
            this.lblPrenom = new System.Windows.Forms.Label();
            this.txtPrenomParent = new System.Windows.Forms.TextBox();
            this.lblProfession = new System.Windows.Forms.Label();
            this.txtProfessionParent = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmailParent = new System.Windows.Forms.TextBox();
            this.lblTelephone = new System.Windows.Forms.Label();
            this.txtTelephoneParent = new System.Windows.Forms.TextBox();
            this.lblTelephoneSec = new System.Windows.Forms.Label();
            this.txtTelephoneSecondaire = new System.Windows.Forms.TextBox();
            this.lblAdresse = new System.Windows.Forms.Label();
            this.txtAdresseParent = new System.Windows.Forms.TextBox();
            this.lblVille = new System.Windows.Forms.Label();
            this.txtVilleParent = new System.Windows.Forms.TextBox();
            this.lblCodePostal = new System.Windows.Forms.Label();
            this.txtCodePostal = new System.Windows.Forms.TextBox();
            this.lblTuteur = new System.Windows.Forms.Label();
            this.chkTuteurPrincipal = new System.Windows.Forms.CheckBox();
            this.lblLien = new System.Windows.Forms.Label();
            this.cmbLienParent = new System.Windows.Forms.ComboBox();
            this.btnValider = new System.Windows.Forms.Button();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblNom
            // 
            this.lblNom.Location = new System.Drawing.Point(12, 61);
            this.lblNom.Name = "lblNom";
            this.lblNom.Size = new System.Drawing.Size(80, 20);
            this.lblNom.TabIndex = 22;
            this.lblNom.Text = "Nom *:";
            // 
            // txtNomParent
            // 
            this.txtNomParent.Location = new System.Drawing.Point(98, 61);
            this.txtNomParent.Name = "txtNomParent";
            this.txtNomParent.Size = new System.Drawing.Size(200, 22);
            this.txtNomParent.TabIndex = 21;
            // 
            // lblPrenom
            // 
            this.lblPrenom.Location = new System.Drawing.Point(12, 91);
            this.lblPrenom.Name = "lblPrenom";
            this.lblPrenom.Size = new System.Drawing.Size(80, 20);
            this.lblPrenom.TabIndex = 20;
            this.lblPrenom.Text = "Prénom *:";
            // 
            // txtPrenomParent
            // 
            this.txtPrenomParent.Location = new System.Drawing.Point(98, 91);
            this.txtPrenomParent.Name = "txtPrenomParent";
            this.txtPrenomParent.Size = new System.Drawing.Size(200, 22);
            this.txtPrenomParent.TabIndex = 19;
            // 
            // lblProfession
            // 
            this.lblProfession.Location = new System.Drawing.Point(12, 121);
            this.lblProfession.Name = "lblProfession";
            this.lblProfession.Size = new System.Drawing.Size(80, 20);
            this.lblProfession.TabIndex = 18;
            this.lblProfession.Text = "Profession :";
            // 
            // txtProfessionParent
            // 
            this.txtProfessionParent.Location = new System.Drawing.Point(98, 121);
            this.txtProfessionParent.Name = "txtProfessionParent";
            this.txtProfessionParent.Size = new System.Drawing.Size(200, 22);
            this.txtProfessionParent.TabIndex = 17;
            // 
            // lblEmail
            // 
            this.lblEmail.Location = new System.Drawing.Point(12, 151);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(80, 20);
            this.lblEmail.TabIndex = 16;
            this.lblEmail.Text = "Email :";
            // 
            // txtEmailParent
            // 
            this.txtEmailParent.Location = new System.Drawing.Point(98, 151);
            this.txtEmailParent.Name = "txtEmailParent";
            this.txtEmailParent.Size = new System.Drawing.Size(200, 22);
            this.txtEmailParent.TabIndex = 15;
            // 
            // lblTelephone
            // 
            this.lblTelephone.Location = new System.Drawing.Point(12, 181);
            this.lblTelephone.Name = "lblTelephone";
            this.lblTelephone.Size = new System.Drawing.Size(100, 20);
            this.lblTelephone.TabIndex = 14;
            this.lblTelephone.Text = "Téléphone *:";
            // 
            // txtTelephoneParent
            // 
            this.txtTelephoneParent.Location = new System.Drawing.Point(98, 181);
            this.txtTelephoneParent.Name = "txtTelephoneParent";
            this.txtTelephoneParent.Size = new System.Drawing.Size(200, 22);
            this.txtTelephoneParent.TabIndex = 13;
            // 
            // lblTelephoneSec
            // 
            this.lblTelephoneSec.Location = new System.Drawing.Point(12, 211);
            this.lblTelephoneSec.Name = "lblTelephoneSec";
            this.lblTelephoneSec.Size = new System.Drawing.Size(80, 20);
            this.lblTelephoneSec.TabIndex = 12;
            this.lblTelephoneSec.Text = "Tel. Secondaire :";
            // 
            // txtTelephoneSecondaire
            // 
            this.txtTelephoneSecondaire.Location = new System.Drawing.Point(98, 211);
            this.txtTelephoneSecondaire.Name = "txtTelephoneSecondaire";
            this.txtTelephoneSecondaire.Size = new System.Drawing.Size(200, 22);
            this.txtTelephoneSecondaire.TabIndex = 11;
            // 
            // lblAdresse
            // 
            this.lblAdresse.Location = new System.Drawing.Point(12, 241);
            this.lblAdresse.Name = "lblAdresse";
            this.lblAdresse.Size = new System.Drawing.Size(80, 20);
            this.lblAdresse.TabIndex = 10;
            this.lblAdresse.Text = "Adresse :";
            // 
            // txtAdresseParent
            // 
            this.txtAdresseParent.Location = new System.Drawing.Point(98, 241);
            this.txtAdresseParent.Name = "txtAdresseParent";
            this.txtAdresseParent.Size = new System.Drawing.Size(200, 22);
            this.txtAdresseParent.TabIndex = 9;
            // 
            // lblVille
            // 
            this.lblVille.Location = new System.Drawing.Point(12, 271);
            this.lblVille.Name = "lblVille";
            this.lblVille.Size = new System.Drawing.Size(80, 20);
            this.lblVille.TabIndex = 8;
            this.lblVille.Text = "Ville :";
            // 
            // txtVilleParent
            // 
            this.txtVilleParent.Location = new System.Drawing.Point(98, 271);
            this.txtVilleParent.Name = "txtVilleParent";
            this.txtVilleParent.Size = new System.Drawing.Size(200, 22);
            this.txtVilleParent.TabIndex = 7;
            // 
            // lblCodePostal
            // 
            this.lblCodePostal.Location = new System.Drawing.Point(12, 301);
            this.lblCodePostal.Name = "lblCodePostal";
            this.lblCodePostal.Size = new System.Drawing.Size(80, 20);
            this.lblCodePostal.TabIndex = 6;
            this.lblCodePostal.Text = "Code Postal :";
            // 
            // txtCodePostal
            // 
            this.txtCodePostal.Location = new System.Drawing.Point(98, 301);
            this.txtCodePostal.Name = "txtCodePostal";
            this.txtCodePostal.Size = new System.Drawing.Size(200, 22);
            this.txtCodePostal.TabIndex = 5;
            // 
            // lblTuteur
            // 
            this.lblTuteur.Location = new System.Drawing.Point(12, 331);
            this.lblTuteur.Name = "lblTuteur";
            this.lblTuteur.Size = new System.Drawing.Size(80, 20);
            this.lblTuteur.TabIndex = 4;
            this.lblTuteur.Text = "Tuteur Principal :";
            // 
            // chkTuteurPrincipal
            // 
            this.chkTuteurPrincipal.Checked = true;
            this.chkTuteurPrincipal.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkTuteurPrincipal.Location = new System.Drawing.Point(92, 331);
            this.chkTuteurPrincipal.Name = "chkTuteurPrincipal";
            this.chkTuteurPrincipal.Size = new System.Drawing.Size(20, 20);
            this.chkTuteurPrincipal.TabIndex = 3;
            // 
            // lblLien
            // 
            this.lblLien.Location = new System.Drawing.Point(12, 361);
            this.lblLien.Name = "lblLien";
            this.lblLien.Size = new System.Drawing.Size(80, 20);
            this.lblLien.TabIndex = 2;
            this.lblLien.Text = "Lien *:";
            // 
            // cmbLienParent
            // 
            this.cmbLienParent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLienParent.Items.AddRange(new object[] {
            "Père",
            "Mère",
            "Tuteur légal"});
            this.cmbLienParent.Location = new System.Drawing.Point(92, 361);
            this.cmbLienParent.Name = "cmbLienParent";
            this.cmbLienParent.Size = new System.Drawing.Size(200, 24);
            this.cmbLienParent.TabIndex = 1;
            // 
            // btnValider
            // 
            this.btnValider.Location = new System.Drawing.Point(59, 401);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(80, 30);
            this.btnValider.TabIndex = 0;
            this.btnValider.Text = "Valider";
            this.btnValider.Click += new System.EventHandler(this.btnValider_Click);
            // 
            // txtCode
            // 
            this.txtCode.Location = new System.Drawing.Point(98, 33);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(200, 22);
            this.txtCode.TabIndex = 23;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 24;
            this.label1.Text = "Code *:";
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(167, 401);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(80, 30);
            this.btnAnnuler.TabIndex = 25;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // AjouterParentForm
            // 
            this.ClientSize = new System.Drawing.Size(350, 467);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.txtCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnValider);
            this.Controls.Add(this.cmbLienParent);
            this.Controls.Add(this.lblLien);
            this.Controls.Add(this.chkTuteurPrincipal);
            this.Controls.Add(this.lblTuteur);
            this.Controls.Add(this.txtCodePostal);
            this.Controls.Add(this.lblCodePostal);
            this.Controls.Add(this.txtVilleParent);
            this.Controls.Add(this.lblVille);
            this.Controls.Add(this.txtAdresseParent);
            this.Controls.Add(this.lblAdresse);
            this.Controls.Add(this.txtTelephoneSecondaire);
            this.Controls.Add(this.lblTelephoneSec);
            this.Controls.Add(this.txtTelephoneParent);
            this.Controls.Add(this.lblTelephone);
            this.Controls.Add(this.txtEmailParent);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.txtProfessionParent);
            this.Controls.Add(this.lblProfession);
            this.Controls.Add(this.txtPrenomParent);
            this.Controls.Add(this.lblPrenom);
            this.Controls.Add(this.txtNomParent);
            this.Controls.Add(this.lblNom);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AjouterParentForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Ajouter un parent/tuteur";
            this.Load += new System.EventHandler(this.AjouterParentForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label lblNom;
        private System.Windows.Forms.TextBox txtNomParent;
        private System.Windows.Forms.Label lblPrenom;
        private System.Windows.Forms.TextBox txtPrenomParent;
        private System.Windows.Forms.Label lblProfession;
        private System.Windows.Forms.TextBox txtProfessionParent;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmailParent;
        private System.Windows.Forms.Label lblTelephone;
        private System.Windows.Forms.TextBox txtTelephoneParent;
        private System.Windows.Forms.Label lblTelephoneSec;
        private System.Windows.Forms.TextBox txtTelephoneSecondaire;
        private System.Windows.Forms.Label lblAdresse;
        private System.Windows.Forms.TextBox txtAdresseParent;
        private System.Windows.Forms.Label lblVille;
        private System.Windows.Forms.TextBox txtVilleParent;
        private System.Windows.Forms.Label lblCodePostal;
        private System.Windows.Forms.TextBox txtCodePostal;
        private System.Windows.Forms.Label lblTuteur;
        private System.Windows.Forms.CheckBox chkTuteurPrincipal;
        private System.Windows.Forms.Label lblLien;
        private System.Windows.Forms.ComboBox cmbLienParent;
        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAnnuler;
    }
}