﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class Gestiondesutilisateurs : Form
    {
        private Outils outils = new Outils();
        private DataTable utilisateursTable;
        public Gestiondesutilisateurs()
        {
            InitializeComponent();
            ConfigurerDataGridView();
            ChargerRoles();
            ChargerUtilisateurs();
            filtrer.SelectedIndexChanged += new EventHandler(filtrer_SelectedIndexChanged);
            bt_ajouter.Click += new EventHandler(bt_ajouter_Click);
        }
        private void ConfigurerDataGridView()
        {
            dgv_enreg.AutoGenerateColumns = false;
            dgv_enreg.Columns.Clear();

            // Ajout des colonnes de données
            dgv_enreg.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Code_Utilisateur",
                HeaderText = "Code",
                Name = "Code",
                ReadOnly = true
            });
            dgv_enreg.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Nom_Utilisateur",
                HeaderText = "Nom Utilisateur",
                Name = "NomUtilisateur",
                ReadOnly = true
            });
            dgv_enreg.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Role_Utilisateur",
                HeaderText = "Rôle",
                Name = "Role",
                ReadOnly = true
            });
            dgv_enreg.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Email",
                HeaderText = "Email",
                Name = "Email",
                ReadOnly = true
            });
            // Ajout le mot de passe (affiché sous forme masquée)
            dgv_enreg.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Mot_De_Passe_Hash",
                HeaderText = "Mot de Passe",
                Name = "MotDePasse",
                ReadOnly = true
            });
            
            dgv_enreg.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Date_Creation",
                HeaderText = "Date Création",
                Name = "DateCreation",
                ReadOnly = true
            });

           
            DataGridViewButtonColumn btnModifierColumn = new DataGridViewButtonColumn
            {
                HeaderText = "Modifier",
                Text = "Modifier",
                Name = "Modifier",
                UseColumnTextForButtonValue = true
            };
            dgv_enreg.Columns.Add(btnModifierColumn);

            DataGridViewButtonColumn btnSupprimerColumn = new DataGridViewButtonColumn
            {
                HeaderText = "Supprimer",
                Text = "Supprimer",
                Name = "Supprimer",
                UseColumnTextForButtonValue = true
            };
            dgv_enreg.Columns.Add(btnSupprimerColumn);

            // Définir la largeur des colonnes
            dgv_enreg.Columns["Code"].Width = 50;
            dgv_enreg.Columns["NomUtilisateur"].Width = 150;
            dgv_enreg.Columns["Role"].Width = 100;
            dgv_enreg.Columns["Email"].Width = 200;
            dgv_enreg.Columns["MotDePasse"].Width = 100;
            dgv_enreg.Columns["DateCreation"].Width = 120;
            dgv_enreg.Columns["Modifier"].Width = 80;
            dgv_enreg.Columns["Supprimer"].Width = 80;

            
            dgv_enreg.CellClick += new DataGridViewCellEventHandler(dgv_enreg_CellClick);
            dgv_enreg.CellFormatting += new DataGridViewCellFormattingEventHandler(dgv_enreg_CellFormatting);
        }

        private void dgv_enreg_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgv_enreg.Columns[e.ColumnIndex].Name == "MotDePasse" && e.Value != null)
            {
                e.Value = new string('*', 4);
                e.FormattingApplied = true;
            }
        }

        private void ChargerRoles()
        {
            try
            {
                
                string query = "SELECT 0 AS Ordre, 'Tous' AS Role_Utilisateur, 'Tous' AS Display UNION " +
                              "SELECT 1 AS Ordre, Role_Utilisateur, Role_Utilisateur FROM Utilisateur WHERE Role_Utilisateur IS NOT NULL " +
                              "ORDER BY Ordre, Role_Utilisateur";
                DataTable rolesTable = outils.GetDataTable(query);
                filtrer.DataSource = rolesTable;
                filtrer.DisplayMember = "Display";
                filtrer.ValueMember = "Role_Utilisateur";
                filtrer.SelectedIndex = 0; 
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des rôles : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ChargerUtilisateurs()
        {
            try
            {
                string query = "SELECT Code_Utilisateur, Nom_Utilisateur, Role_Utilisateur, Email, Mot_De_Passe_Hash, Date_Creation FROM Utilisateur";
                outils.ChargementDVG(query, dgv_enreg, null);
                MettreAJourCompteurs();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des utilisateurs : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MettreAJourCompteurs()
        {
            try
            {
                int rowCount = dgv_enreg.Rows.Count;
                if (dgv_enreg.AllowUserToAddRows && rowCount > 0)
                {
                    rowCount--; 
                }
                nb_tot.Text = $"Nombre total utilisateurs : {rowCount}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la mise à jour des compteurs : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FiltrerUtilisateurs()
        {
            try
            {
                string selectedRole = filtrer.SelectedValue?.ToString();
                //string searchText = txtRechercher.Text.Trim();
                string query = "SELECT Code_Utilisateur, Nom_Utilisateur, Role_Utilisateur, Email, Mot_De_Passe_Hash, Date_Creation FROM Utilisateur WHERE 1=1";

                if (selectedRole != "Tous" && !string.IsNullOrEmpty(selectedRole))
                {
                    query += " AND Role_Utilisateur = '" + selectedRole.Replace("'", "''") + "'";
                }

                //if (!string.IsNullOrEmpty(searchText))
               // {
                   // query += " AND Nom_Utilisateur LIKE '%" + searchText.Replace("'", "''") + "%'";
                //}

                outils.ChargementDVG(query, dgv_enreg, null);
                MettreAJourCompteurs();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la filtration : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void filtrer_SelectedIndexChanged(object sender, EventArgs e)
        {
            FiltrerUtilisateurs();
        }

        private void txtRechercher_TextChanged(object sender, EventArgs e)
        {
            //FiltrerUtilisateurs();
            outils.ChargementDVG("select * from FROM Utilisateur WHERE Nom_Utilisateur like '%" + txtRechercher.Text + "%'", dgv_enreg, null);
        }

        private void dgv_enreg_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                if (dgv_enreg.Columns[e.ColumnIndex].Name == "Modifier")
                {
                    try
                    {
                        int codeUtilisateur = Convert.ToInt32(dgv_enreg.Rows[e.RowIndex].Cells["Code"].Value);
                        string nomUtilisateur = dgv_enreg.Rows[e.RowIndex].Cells["NomUtilisateur"].Value?.ToString() ?? "";
                        string roleUtilisateur = dgv_enreg.Rows[e.RowIndex].Cells["Role"].Value?.ToString() ?? "";
                        string email = dgv_enreg.Rows[e.RowIndex].Cells["Email"].Value?.ToString() ?? "";
                        string motDePasseQuery = "SELECT Mot_De_Passe_Hash FROM Utilisateur WHERE Code_Utilisateur = " + codeUtilisateur;
                        string motDePasse = outils.Selection(motDePasseQuery) ?? "";

                        modifierutilisateur form = new modifierutilisateur(codeUtilisateur, nomUtilisateur, roleUtilisateur, email, motDePasse);
                        if (form.ShowDialog() == DialogResult.OK)
                        {
                            ChargerUtilisateurs();
                            ChargerRoles();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Erreur lors de l'ouverture de la modification : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else if (dgv_enreg.Columns[e.ColumnIndex].Name == "Supprimer")
                {
                    try
                    {
                        int codeUtilisateur = Convert.ToInt32(dgv_enreg.Rows[e.RowIndex].Cells["Code"].Value);
                        if (MessageBox.Show($"Voulez-vous vraiment supprimer l'utilisateur avec Code : {codeUtilisateur} ?", "Confirmer Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        {
                            string query = "DELETE FROM Utilisateur WHERE Code_Utilisateur = " + codeUtilisateur;
                            outils.RequtteMiseAjour(query);
                            ChargerUtilisateurs();
                            ChargerRoles();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Erreur lors de la suppression : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void bt_ajouter_Click(object sender, EventArgs e)
        {
            try
            {
                Ajouterutilisateur form = new Ajouterutilisateur();
                if (form.ShowDialog() == DialogResult.OK)
                {
                    ChargerUtilisateurs();
                    ChargerRoles();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de l'ouverture de l'ajout : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Gestiondesutilisateurs_Load(object sender, EventArgs e)
        {
            FiltrerUtilisateurs();
        }
    }
}
