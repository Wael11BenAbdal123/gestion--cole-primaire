﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestionEcolePrimaire;

namespace GestionEcolePrimaire
{
    public partial class Form1 : Form
    {
        private Otulis otulis = new Otulis();
        private int? ancienCodeNiveau = null;
        public Form1()
        {
            InitializeComponent();
            txtCodeNiveau.Enabled = true;
            LoadNiveaux();
        }

        private void LoadNiveaux()
        {
            try
            {
                string query = "SELECT Code_Niveau, Libelle_Niveau, Nb_Horaire_Niveau FROM Niveaux";
                otulis.ChargementDVG(query, dataGridViewNiveaux, txtCount);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des niveaux : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadMatieresByNiveau(int codeNiveau)
        {
            try
            {
                // Charger tous les champs de la table Matiere
                string query = "SELECT Code_Matiere, Libelle_Matiere, Coefficient_Matiere, Code_Niveau FROM Matiere WHERE Code_Niveau = " + codeNiveau;
                DataTable matieresTable = otulis.GetDataTable(query);

                // Clear the DataGridView completely (including columns)
                dataGridViewMatieres.DataSource = null;
                dataGridViewMatieres.Columns.Clear();
                dataGridViewMatieres.Rows.Clear();

                if (matieresTable.Rows.Count == 0)
                {
                    // Add a single column for the message
                    dataGridViewMatieres.Columns.Add("Message", "Message");
                    dataGridViewMatieres.Rows.Add("Aucune matière associée");
                }
                else
                {
                    dataGridViewMatieres.DataSource = matieresTable;
                    // Renommer les colonnes pour plus de clarté
                    dataGridViewMatieres.Columns["Code_Matiere"].HeaderText = "Code Matière";
                    dataGridViewMatieres.Columns["Libelle_Matiere"].HeaderText = "Matière";
                    dataGridViewMatieres.Columns["Coefficient_Matiere"].HeaderText = "Coefficient";
                    dataGridViewMatieres.Columns["Code_Niveau"].HeaderText = "Code Niveau";
                }

                // Forcer un rafraîchissement
                dataGridViewMatieres.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des matières : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadClassesByNiveau(int codeNiveau)
        {
            try
            {
                // Charger tous les champs de la table Classe
                string query = "SELECT Code_Classe, Libelle_Classe, Capacite_Max_Eleve, Nb_Actuel_Eleve, Code_Niveau FROM Classe WHERE Code_Niveau = " + codeNiveau;
                DataTable classesTable = otulis.GetDataTable(query);

                // Clear the DataGridView completely (including columns)
                dataGridViewClasses.DataSource = null;
                dataGridViewClasses.Columns.Clear();
                dataGridViewClasses.Rows.Clear();

                if (classesTable.Rows.Count == 0)
                {
                    // Add a single column for the message
                    dataGridViewClasses.Columns.Add("Message", "Message");
                    dataGridViewClasses.Rows.Add("Aucune classe associée");
                }
                else
                {
                    dataGridViewClasses.DataSource = classesTable;
                    // Renommer les colonnes pour plus de clarté
                    dataGridViewClasses.Columns["Code_Classe"].HeaderText = "Code Classe";
                    dataGridViewClasses.Columns["Libelle_Classe"].HeaderText = "Classe";
                    dataGridViewClasses.Columns["Capacite_Max_Eleve"].HeaderText = "Capacité Max";
                    dataGridViewClasses.Columns["Nb_Actuel_Eleve"].HeaderText = "Élèves Actuels";
                    dataGridViewClasses.Columns["Code_Niveau"].HeaderText = "Code Niveau";
                }

                // Forcer un rafraîchissement
                dataGridViewClasses.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des classes : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnAjouter_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCodeNiveau.Text) || string.IsNullOrWhiteSpace(txtLibelle.Text) || string.IsNullOrWhiteSpace(txtHoraire.Text))
                {
                    MessageBox.Show("Veuillez remplir tous les champs.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Vérifier si Code_Niveau est un nombre valide
                if (!int.TryParse(txtCodeNiveau.Text, out int codeNiveau))
                {
                    MessageBox.Show("Le Code Niveau doit être un nombre valide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Vérifier si Nb_Horaire_Niveau est un nombre valide
                if (!int.TryParse(txtHoraire.Text, out int horaire))
                {
                    MessageBox.Show("Le nombre d'heures doit être un nombre valide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
         
                    return;
                }

                // Vérifier si le Code_Niveau existe déjà
                string checkQuery = "SELECT Code_Niveau FROM Niveaux WHERE Code_Niveau = " + codeNiveau;
                if (otulis.RequttedeRecherche(checkQuery))
                {
                    MessageBox.Show("Impossible d'ajouter le niveau : ce Code Niveau existe déjà.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Échapper les chaînes pour éviter les injections SQL
                string libelleSafe = txtLibelle.Text.Replace("'", "''");

                // Insérer le nouveau niveau
                string query = "INSERT INTO Niveaux (Code_Niveau, Libelle_Niveau, Nb_Horaire_Niveau) VALUES (" + codeNiveau + ", '" + libelleSafe + "', " + horaire + ")";
                otulis.RequtteMiseAjour(query);
                MessageBox.Show("Niveau ajouté avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadNiveaux();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout du niveau : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModifier_Click(object sender, EventArgs e)
        {
            
            try
            {
                if (string.IsNullOrWhiteSpace(txtCodeNiveau.Text))
                {
                    MessageBox.Show("Veuillez sélectionner un niveau à modifier.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string query = "UPDATE Niveaux SET Libelle_Niveau = '" + txtLibelle.Text + "', Nb_Horaire_Niveau = " + txtHoraire.Text + " WHERE Code_Niveau = " + txtCodeNiveau.Text;
                otulis.RequtteMiseAjour(query);
                MessageBox.Show("Niveau modifié avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadNiveaux();
                ClearFields();
                txtCodeNiveau.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la modification du niveau : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
        }

        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCodeNiveau.Text))
                {
                    MessageBox.Show("Veuillez sélectionner un niveau à supprimer.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("Voulez-vous vraiment supprimer ce niveau ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string query = "DELETE FROM Niveaux WHERE Code_Niveau = " + txtCodeNiveau.Text;
                    otulis.RequtteMiseAjour(query);
                    MessageBox.Show("Niveau supprimé avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadNiveaux();
                    ClearFields();
                    txtCodeNiveau.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la suppression du niveau : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridViewNiveaux_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewNiveaux.Rows[e.RowIndex];
                txtCodeNiveau.Text = row.Cells["Code_Niveau"].Value.ToString();
                txtLibelle.Text = row.Cells["Libelle_Niveau"].Value.ToString();
                txtHoraire.Text = row.Cells["Nb_Horaire_Niveau"].Value.ToString();
                txtCodeNiveau.Enabled = false;
                int codeNiveau = Convert.ToInt32(row.Cells["Code_Niveau"].Value);
                LoadMatieresByNiveau(codeNiveau);
                LoadClassesByNiveau(codeNiveau);
            }
        }

        private void ClearFields()
        {
            txtCodeNiveau.Clear();
            txtLibelle.Clear();
            txtHoraire.Clear();
            txtRechercher.Clear();
            dataGridViewMatieres.DataSource = null;
            dataGridViewMatieres.Rows.Clear();
            dataGridViewMatieres.Columns.Clear();
            dataGridViewClasses.DataSource = null;
            dataGridViewClasses.Rows.Clear();
            dataGridViewClasses.Columns.Clear();
        }

        private void txtRechercher_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT Code_Niveau, Libelle_Niveau, Nb_Horaire_Niveau FROM Niveaux WHERE Libelle_Niveau LIKE '%" + txtRechercher.Text + "%'";
                otulis.ChargementDVG(query, dataGridViewNiveaux, txtCount);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la recherche : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnReinitialiser_Click(object sender, EventArgs e)
        {
            txtCodeNiveau.Enabled = true;
            ClearFields();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtCount_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridViewNiveaux_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblClasses_Click(object sender, EventArgs e)
        {

        }
    }
}
