﻿namespace GestionEcolePrimaire
{
    partial class GestionAnneeScolaireForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dvgAnneesScolaires = new System.Windows.Forms.DataGridView();
            this.txtRecherche = new System.Windows.Forms.TextBox();
            this.txtTotalAnnees = new System.Windows.Forms.TextBox();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.lblRecherche = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dvgAnneesScolaires)).BeginInit();
            this.SuspendLayout();
            // 
            // dvgAnneesScolaires
            // 
            this.dvgAnneesScolaires.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvgAnneesScolaires.Location = new System.Drawing.Point(12, 50);
            this.dvgAnneesScolaires.Name = "dvgAnneesScolaires";
            this.dvgAnneesScolaires.Size = new System.Drawing.Size(560, 300);
            this.dvgAnneesScolaires.TabIndex = 0;
            this.dvgAnneesScolaires.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dvgAnneesScolaires_CellContentClick);
            // 
            // txtRecherche
            // 
            this.txtRecherche.Location = new System.Drawing.Point(100, 12);
            this.txtRecherche.Name = "txtRecherche";
            this.txtRecherche.Size = new System.Drawing.Size(200, 23);
            this.txtRecherche.TabIndex = 1;
            this.txtRecherche.TextChanged += new System.EventHandler(this.txtRecherche_TextChanged);
            // 
            // txtTotalAnnees
            // 
            this.txtTotalAnnees.Location = new System.Drawing.Point(100, 360);
            this.txtTotalAnnees.Name = "txtTotalAnnees";
            this.txtTotalAnnees.ReadOnly = true;
            this.txtTotalAnnees.Size = new System.Drawing.Size(100, 23);
            this.txtTotalAnnees.TabIndex = 2;
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(400, 360);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(150, 30);
            this.btnAjouter.TabIndex = 3;
            this.btnAjouter.Text = "Ajouter une année scolaire";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // lblRecherche
            // 
            this.lblRecherche.AutoSize = true;
            this.lblRecherche.Location = new System.Drawing.Point(12, 15);
            this.lblRecherche.Name = "lblRecherche";
            this.lblRecherche.Size = new System.Drawing.Size(82, 15);
            this.lblRecherche.TabIndex = 4;
            this.lblRecherche.Text = "Rechercher :";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(12, 363);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(86, 15);
            this.lblTotal.TabIndex = 5;
            this.lblTotal.Text = "Total années :";
            // 
            // GestionAnneeScolaireForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 411);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblRecherche);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.txtTotalAnnees);
            this.Controls.Add(this.txtRecherche);
            this.Controls.Add(this.dvgAnneesScolaires);
            this.Name = "GestionAnneeScolaireForm";
            this.Text = "Gestion des Années Scolaires";
            ((System.ComponentModel.ISupportInitialize)(this.dvgAnneesScolaires)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DataGridView dvgAnneesScolaires;
        private System.Windows.Forms.TextBox txtRecherche;
        private System.Windows.Forms.TextBox txtTotalAnnees;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Label lblRecherche;
        private System.Windows.Forms.Label lblTotal;
    }
}