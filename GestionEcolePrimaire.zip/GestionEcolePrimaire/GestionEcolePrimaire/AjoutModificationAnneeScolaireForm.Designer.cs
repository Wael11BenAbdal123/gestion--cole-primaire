﻿namespace GestionEcolePrimaire
{
    partial class AjoutModificationAnneeScolaireForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblCodeAnnee = new System.Windows.Forms.Label();
            this.txtCodeAnnee = new System.Windows.Forms.TextBox();
            this.lblLibelleAnnee = new System.Windows.Forms.Label();
            this.txtLibelleAnnee = new System.Windows.Forms.TextBox();
            this.btnEnregistrer = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCodeAnnee
            // 
            this.lblCodeAnnee.AutoSize = true;
            this.lblCodeAnnee.Location = new System.Drawing.Point(12, 20);
            this.lblCodeAnnee.Name = "lblCodeAnnee";
            this.lblCodeAnnee.Size = new System.Drawing.Size(86, 15);
            this.lblCodeAnnee.TabIndex = 0;
            this.lblCodeAnnee.Text = "Code Année :";
            // 
            // txtCodeAnnee
            // 
            this.txtCodeAnnee.Location = new System.Drawing.Point(120, 17);
            this.txtCodeAnnee.Name = "txtCodeAnnee";
            this.txtCodeAnnee.Size = new System.Drawing.Size(150, 23);
            this.txtCodeAnnee.TabIndex = 1;
            // 
            // lblLibelleAnnee
            // 
            this.lblLibelleAnnee.AutoSize = true;
            this.lblLibelleAnnee.Location = new System.Drawing.Point(12, 50);
            this.lblLibelleAnnee.Name = "lblLibelleAnnee";
            this.lblLibelleAnnee.Size = new System.Drawing.Size(101, 15);
            this.lblLibelleAnnee.TabIndex = 2;
            this.lblLibelleAnnee.Text = "Libellé Année :";
            // 
            // txtLibelleAnnee
            // 
            this.txtLibelleAnnee.Location = new System.Drawing.Point(120, 47);
            this.txtLibelleAnnee.Name = "txtLibelleAnnee";
            this.txtLibelleAnnee.Size = new System.Drawing.Size(150, 23);
            this.txtLibelleAnnee.TabIndex = 3;
            // 
            // btnEnregistrer
            // 
            this.btnEnregistrer.Location = new System.Drawing.Point(50, 90);
            this.btnEnregistrer.Name = "btnEnregistrer";
            this.btnEnregistrer.Size = new System.Drawing.Size(100, 30);
            this.btnEnregistrer.TabIndex = 4;
            this.btnEnregistrer.Text = "Enregistrer";
            this.btnEnregistrer.UseVisualStyleBackColor = true;
            this.btnEnregistrer.Click += new System.EventHandler(this.btnEnregistrer_Click);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(170, 90);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(100, 30);
            this.btnAnnuler.TabIndex = 5;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // AjoutModificationAnneeScolaireForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 141);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnEnregistrer);
            this.Controls.Add(this.txtLibelleAnnee);
            this.Controls.Add(this.lblLibelleAnnee);
            this.Controls.Add(this.txtCodeAnnee);
            this.Controls.Add(this.lblCodeAnnee);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "AjoutModificationAnneeScolaireForm";
            this.Text = "Ajouter/Modifier Année Scolaire";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblCodeAnnee;
        private System.Windows.Forms.TextBox txtCodeAnnee;
        private System.Windows.Forms.Label lblLibelleAnnee;
        private System.Windows.Forms.TextBox txtLibelleAnnee;
        private System.Windows.Forms.Button btnEnregistrer;
        private System.Windows.Forms.Button btnAnnuler;
    }
}