﻿using System;
using System.Data;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class GestionAnneeScolaireForm : Form
    {
        private Otulis otulis = new Otulis();
        private bool columnsInitialized = false;

        public GestionAnneeScolaireForm()
        {
            InitializeComponent();
            LoadAnneesScolaires();
        }

        private void LoadAnneesScolaires(string searchText = "")
        {
            try
            {
                string query = "SELECT Code_Annee, Libelle_Annee FROM AnneeScolaire";
                if (!string.IsNullOrEmpty(searchText))
                {
                    query += $" WHERE Libelle_Annee LIKE '%{searchText}%'";
                }
                otulis.ChargementDVG(query, dvgAnneesScolaires, txtTotalAnnees);

                // Ajouter les colonnes de boutons si elles n'existent pas
                if (!columnsInitialized)
                {
                    if (!dvgAnneesScolaires.Columns.Contains("Modifier"))
                    {
                        DataGridViewButtonColumn btnModifier = new DataGridViewButtonColumn();
                        btnModifier.Name = "Modifier";
                        btnModifier.HeaderText = "";
                        btnModifier.Text = "Modifier";
                        btnModifier.UseColumnTextForButtonValue = true;
                        dvgAnneesScolaires.Columns.Add(btnModifier);
                    }

                    if (!dvgAnneesScolaires.Columns.Contains("Supprimer"))
                    {
                        DataGridViewButtonColumn btnSupprimer = new DataGridViewButtonColumn();
                        btnSupprimer.Name = "Supprimer";
                        btnSupprimer.HeaderText = "";
                        btnSupprimer.Text = "Supprimer";
                        btnSupprimer.UseColumnTextForButtonValue = true;
                        dvgAnneesScolaires.Columns.Add(btnSupprimer);
                    }

                    columnsInitialized = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des années scolaires : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            AjoutModificationAnneeScolaireForm ajoutForm = new AjoutModificationAnneeScolaireForm(null);
            if (ajoutForm.ShowDialog() == DialogResult.OK)
            {
                LoadAnneesScolaires(txtRecherche.Text);
            }
        }

        private void txtRecherche_TextChanged(object sender, EventArgs e)
        {
            LoadAnneesScolaires(txtRecherche.Text);
        }

        private void dvgAnneesScolaires_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int codeAnnee = Convert.ToInt32(dvgAnneesScolaires.Rows[e.RowIndex].Cells["Code_Annee"].Value);

                if (e.ColumnIndex == dvgAnneesScolaires.Columns["Modifier"].Index)
                {
                    // Ouvrir l'interface de modification
                    AjoutModificationAnneeScolaireForm modifForm = new AjoutModificationAnneeScolaireForm(codeAnnee);
                    if (modifForm.ShowDialog() == DialogResult.OK)
                    {
                        LoadAnneesScolaires(txtRecherche.Text);
                    }
                }
                else if (e.ColumnIndex == dvgAnneesScolaires.Columns["Supprimer"].Index)
                {
                    // Vérifier si l'année scolaire est référencée dans la table Inscription ou Note
                    string checkQuery = $"SELECT COUNT(*) FROM Inscription WHERE AnneeID = {codeAnnee} " +
                                       $"UNION SELECT COUNT(*) FROM Note WHERE AnneeScolaireID = {codeAnnee}";
                    DataTable result = otulis.GetDataTable(checkQuery);
                    bool isReferenced = false;
                    foreach (DataRow row in result.Rows)
                    {
                        if (Convert.ToInt32(row[0]) > 0)
                        {
                            isReferenced = true;
                            break;
                        }
                    }

                    if (isReferenced)
                    {
                        MessageBox.Show("Cette année scolaire est référencée dans des inscriptions ou des notes et ne peut pas être supprimée.",
                                        "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Confirmer la suppression
                    if (MessageBox.Show("Voulez-vous vraiment supprimer cette année scolaire ?", "Confirmation",
                                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        try
                        {
                            string query = $"DELETE FROM AnneeScolaire WHERE Code_Annee = {codeAnnee}";
                            otulis.RequtteMiseAjour(query);
                            LoadAnneesScolaires(txtRecherche.Text);
                            MessageBox.Show("Année scolaire supprimée avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Erreur lors de la suppression : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }
    }
}