﻿namespace GestionEcolePrimaire
{
    partial class ClasseForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.labelTitle = new System.Windows.Forms.Label();
            this.labelCodeClasse = new System.Windows.Forms.Label();
            this.txtCodeClasse = new System.Windows.Forms.TextBox();
            this.labelCodeNiveauText = new System.Windows.Forms.Label();
            this.txtCodeNiveau = new System.Windows.Forms.TextBox();
            this.labelCodeNiveau = new System.Windows.Forms.Label();
            this.comboBoxNiveau = new System.Windows.Forms.ComboBox();
            this.labelLibelleClasse = new System.Windows.Forms.Label();
            this.txtLibelleClasse = new System.Windows.Forms.TextBox();
            this.labelCapaciteMaximale = new System.Windows.Forms.Label();
            this.txtCapaciteMaximale = new System.Windows.Forms.TextBox();
            this.labelNbElevesActuel = new System.Windows.Forms.Label();
            this.txtNbElevesActuel = new System.Windows.Forms.TextBox();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.btnModifier = new System.Windows.Forms.Button();
            this.btnSupprimer = new System.Windows.Forms.Button();
            this.labelRechercher = new System.Windows.Forms.Label();
            this.txtRechercher = new System.Windows.Forms.TextBox();
            this.btnRechercher = new System.Windows.Forms.Button();
            this.dataGridViewClasses = new System.Windows.Forms.DataGridView();
            this.btn_voirEleves = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClasses)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTitle
            // 
            this.labelTitle.AutoSize = true;
            this.labelTitle.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTitle.Location = new System.Drawing.Point(358, 9);
            this.labelTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(157, 19);
            this.labelTitle.TabIndex = 0;
            this.labelTitle.Text = "Gestion des Classes";
            // 
            // labelCodeClasse
            // 
            this.labelCodeClasse.AutoSize = true;
            this.labelCodeClasse.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCodeClasse.Location = new System.Drawing.Point(16, 49);
            this.labelCodeClasse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCodeClasse.Name = "labelCodeClasse";
            this.labelCodeClasse.Size = new System.Drawing.Size(97, 17);
            this.labelCodeClasse.TabIndex = 1;
            this.labelCodeClasse.Text = "Code Classe:";
            // 
            // txtCodeClasse
            // 
            this.txtCodeClasse.Location = new System.Drawing.Point(160, 46);
            this.txtCodeClasse.Margin = new System.Windows.Forms.Padding(4);
            this.txtCodeClasse.Name = "txtCodeClasse";
            this.txtCodeClasse.Size = new System.Drawing.Size(265, 22);
            this.txtCodeClasse.TabIndex = 2;
            // 
            // labelCodeNiveauText
            // 
            this.labelCodeNiveauText.AutoSize = true;
            this.labelCodeNiveauText.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCodeNiveauText.Location = new System.Drawing.Point(16, 86);
            this.labelCodeNiveauText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCodeNiveauText.Name = "labelCodeNiveauText";
            this.labelCodeNiveauText.Size = new System.Drawing.Size(95, 17);
            this.labelCodeNiveauText.TabIndex = 3;
            this.labelCodeNiveauText.Text = "Code Niveau:";
            // 
            // txtCodeNiveau
            // 
            this.txtCodeNiveau.Location = new System.Drawing.Point(160, 82);
            this.txtCodeNiveau.Margin = new System.Windows.Forms.Padding(4);
            this.txtCodeNiveau.Name = "txtCodeNiveau";
            this.txtCodeNiveau.Size = new System.Drawing.Size(265, 22);
            this.txtCodeNiveau.TabIndex = 4;
            // 
            // labelCodeNiveau
            // 
            this.labelCodeNiveau.AutoSize = true;
            this.labelCodeNiveau.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCodeNiveau.Location = new System.Drawing.Point(16, 123);
            this.labelCodeNiveau.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCodeNiveau.Name = "labelCodeNiveau";
            this.labelCodeNiveau.Size = new System.Drawing.Size(56, 17);
            this.labelCodeNiveau.TabIndex = 5;
            this.labelCodeNiveau.Text = "Niveau:";
            // 
            // comboBoxNiveau
            // 
            this.comboBoxNiveau.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxNiveau.FormattingEnabled = true;
            this.comboBoxNiveau.Location = new System.Drawing.Point(160, 119);
            this.comboBoxNiveau.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxNiveau.Name = "comboBoxNiveau";
            this.comboBoxNiveau.Size = new System.Drawing.Size(265, 24);
            this.comboBoxNiveau.TabIndex = 6;
            // 
            // labelLibelleClasse
            // 
            this.labelLibelleClasse.AutoSize = true;
            this.labelLibelleClasse.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLibelleClasse.Location = new System.Drawing.Point(16, 160);
            this.labelLibelleClasse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelLibelleClasse.Name = "labelLibelleClasse";
            this.labelLibelleClasse.Size = new System.Drawing.Size(93, 17);
            this.labelLibelleClasse.TabIndex = 7;
            this.labelLibelleClasse.Text = "Nom Classe:";
            // 
            // txtLibelleClasse
            // 
            this.txtLibelleClasse.Location = new System.Drawing.Point(160, 156);
            this.txtLibelleClasse.Margin = new System.Windows.Forms.Padding(4);
            this.txtLibelleClasse.Name = "txtLibelleClasse";
            this.txtLibelleClasse.Size = new System.Drawing.Size(265, 22);
            this.txtLibelleClasse.TabIndex = 8;
            // 
            // labelCapaciteMaximale
            // 
            this.labelCapaciteMaximale.AutoSize = true;
            this.labelCapaciteMaximale.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCapaciteMaximale.Location = new System.Drawing.Point(16, 197);
            this.labelCapaciteMaximale.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCapaciteMaximale.Name = "labelCapaciteMaximale";
            this.labelCapaciteMaximale.Size = new System.Drawing.Size(135, 17);
            this.labelCapaciteMaximale.TabIndex = 9;
            this.labelCapaciteMaximale.Text = "Capacité Maximale:";
            // 
            // txtCapaciteMaximale
            // 
            this.txtCapaciteMaximale.Location = new System.Drawing.Point(160, 193);
            this.txtCapaciteMaximale.Margin = new System.Windows.Forms.Padding(4);
            this.txtCapaciteMaximale.Name = "txtCapaciteMaximale";
            this.txtCapaciteMaximale.Size = new System.Drawing.Size(265, 22);
            this.txtCapaciteMaximale.TabIndex = 10;
            // 
            // labelNbElevesActuel
            // 
            this.labelNbElevesActuel.AutoSize = true;
            this.labelNbElevesActuel.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNbElevesActuel.Location = new System.Drawing.Point(16, 234);
            this.labelNbElevesActuel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelNbElevesActuel.Name = "labelNbElevesActuel";
            this.labelNbElevesActuel.Size = new System.Drawing.Size(121, 17);
            this.labelNbElevesActuel.TabIndex = 11;
            this.labelNbElevesActuel.Text = "Nb Élèves Actuel:";
            // 
            // txtNbElevesActuel
            // 
            this.txtNbElevesActuel.Location = new System.Drawing.Point(160, 230);
            this.txtNbElevesActuel.Margin = new System.Windows.Forms.Padding(4);
            this.txtNbElevesActuel.Name = "txtNbElevesActuel";
            this.txtNbElevesActuel.Size = new System.Drawing.Size(265, 22);
            this.txtNbElevesActuel.TabIndex = 12;
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(467, 46);
            this.btnAjouter.Margin = new System.Windows.Forms.Padding(4);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(133, 37);
            this.btnAjouter.TabIndex = 13;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // btnModifier
            // 
            this.btnModifier.Location = new System.Drawing.Point(467, 95);
            this.btnModifier.Margin = new System.Windows.Forms.Padding(4);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(133, 37);
            this.btnModifier.TabIndex = 14;
            this.btnModifier.Text = "Modifier";
            this.btnModifier.UseVisualStyleBackColor = true;
            this.btnModifier.Click += new System.EventHandler(this.btnModifier_Click);
            // 
            // btnSupprimer
            // 
            this.btnSupprimer.Location = new System.Drawing.Point(467, 144);
            this.btnSupprimer.Margin = new System.Windows.Forms.Padding(4);
            this.btnSupprimer.Name = "btnSupprimer";
            this.btnSupprimer.Size = new System.Drawing.Size(133, 37);
            this.btnSupprimer.TabIndex = 15;
            this.btnSupprimer.Text = "Supprimer";
            this.btnSupprimer.UseVisualStyleBackColor = true;
            this.btnSupprimer.Click += new System.EventHandler(this.btnSupprimer_Click);
            // 
            // labelRechercher
            // 
            this.labelRechercher.AutoSize = true;
            this.labelRechercher.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRechercher.Location = new System.Drawing.Point(654, 55);
            this.labelRechercher.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRechercher.Name = "labelRechercher";
            this.labelRechercher.Size = new System.Drawing.Size(196, 17);
            this.labelRechercher.TabIndex = 16;
            this.labelRechercher.Text = "Rechercher par code niveau:";
            // 
            // txtRechercher
            // 
            this.txtRechercher.Location = new System.Drawing.Point(657, 81);
            this.txtRechercher.Margin = new System.Windows.Forms.Padding(4);
            this.txtRechercher.Name = "txtRechercher";
            this.txtRechercher.Size = new System.Drawing.Size(199, 22);
            this.txtRechercher.TabIndex = 17;
            // 
            // btnRechercher
            // 
            this.btnRechercher.Location = new System.Drawing.Point(690, 119);
            this.btnRechercher.Margin = new System.Windows.Forms.Padding(4);
            this.btnRechercher.Name = "btnRechercher";
            this.btnRechercher.Size = new System.Drawing.Size(133, 37);
            this.btnRechercher.TabIndex = 18;
            this.btnRechercher.Text = "Rechercher";
            this.btnRechercher.UseVisualStyleBackColor = true;
            this.btnRechercher.Click += new System.EventHandler(this.btnRechercher_Click);
            // 
            // dataGridViewClasses
            // 
            this.dataGridViewClasses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClasses.Location = new System.Drawing.Point(16, 283);
            this.dataGridViewClasses.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewClasses.Name = "dataGridViewClasses";
            this.dataGridViewClasses.RowHeadersWidth = 51;
            this.dataGridViewClasses.Size = new System.Drawing.Size(891, 185);
            this.dataGridViewClasses.TabIndex = 19;
            this.dataGridViewClasses.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewClasses_CellClick);
            this.dataGridViewClasses.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewClasses_CellContentClick);
            // 
            // btn_voirEleves
            // 
            this.btn_voirEleves.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_voirEleves.Location = new System.Drawing.Point(467, 197);
            this.btn_voirEleves.Margin = new System.Windows.Forms.Padding(4);
            this.btn_voirEleves.Name = "btn_voirEleves";
            this.btn_voirEleves.Size = new System.Drawing.Size(133, 37);
            this.btn_voirEleves.TabIndex = 20;
            this.btn_voirEleves.Text = "Voir Élèves";
            this.btn_voirEleves.UseVisualStyleBackColor = false;
            this.btn_voirEleves.Click += new System.EventHandler(this.btn_voirEleves_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 492);
            this.Controls.Add(this.btn_voirEleves);
            this.Controls.Add(this.dataGridViewClasses);
            this.Controls.Add(this.btnRechercher);
            this.Controls.Add(this.txtRechercher);
            this.Controls.Add(this.labelRechercher);
            this.Controls.Add(this.btnSupprimer);
            this.Controls.Add(this.btnModifier);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.txtNbElevesActuel);
            this.Controls.Add(this.labelNbElevesActuel);
            this.Controls.Add(this.txtCapaciteMaximale);
            this.Controls.Add(this.labelCapaciteMaximale);
            this.Controls.Add(this.txtLibelleClasse);
            this.Controls.Add(this.labelLibelleClasse);
            this.Controls.Add(this.comboBoxNiveau);
            this.Controls.Add(this.labelCodeNiveau);
            this.Controls.Add(this.txtCodeNiveau);
            this.Controls.Add(this.labelCodeNiveauText);
            this.Controls.Add(this.txtCodeClasse);
            this.Controls.Add(this.labelCodeClasse);
            this.Controls.Add(this.labelTitle);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ClasseForm";
            this.Text = "Gestion des Classes";
            this.Load += new System.EventHandler(this.ClasseForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClasses)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label labelTitle;
        private System.Windows.Forms.Label labelCodeClasse;
        private System.Windows.Forms.TextBox txtCodeClasse;
        private System.Windows.Forms.Label labelCodeNiveauText;  
        private System.Windows.Forms.TextBox txtCodeNiveau;     
        private System.Windows.Forms.Label labelCodeNiveau;
        private System.Windows.Forms.ComboBox comboBoxNiveau;
        private System.Windows.Forms.Label labelLibelleClasse;
        private System.Windows.Forms.TextBox txtLibelleClasse;
        private System.Windows.Forms.Label labelCapaciteMaximale;
        private System.Windows.Forms.TextBox txtCapaciteMaximale;
        private System.Windows.Forms.Label labelNbElevesActuel;
        private System.Windows.Forms.TextBox txtNbElevesActuel;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Button btnModifier;
        private System.Windows.Forms.Button btnSupprimer;
        private System.Windows.Forms.Label labelRechercher;
        private System.Windows.Forms.TextBox txtRechercher;
        private System.Windows.Forms.Button btnRechercher;
        private System.Windows.Forms.DataGridView dataGridViewClasses;
        private System.Windows.Forms.Button btn_voirEleves;
    }
}
