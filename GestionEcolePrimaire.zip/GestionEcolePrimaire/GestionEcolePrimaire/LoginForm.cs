﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class LoginForm : Form
    {
        Otulis o=new Otulis();
        public string b=null;
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnConnexion_Click(object sender, EventArgs e)
        {
            b = o.Selection("select Code_Utilisateur from Utilisateur where Nom_Utilisateur = '"+this.txtNomUtilisateur.Text+ "' and Mot_De_Passe_Hash = '"+this.txtMotDePasse.Text+"';");

            if (b == null)
            {
                MessageBox.Show("Nom d'utilisateur ou mot de passe incorrect.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                MessageBox.Show("Connexion réussie !", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }
        private void LoginForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }
        private void btnConnexion_MouseEnter(object sender, EventArgs e)
        {
            btnConnexion.BackColor = Color.FromArgb(0, 180, 0); 
            btnConnexion.ForeColor = Color.White;
        }
        private void btnConnexion_MouseLeave(object sender, EventArgs e)
        {
            btnConnexion.BackColor = Color.FromArgb(0, 200, 0);
            btnConnexion.ForeColor = Color.White;
        }
        private void btnConnexion_MouseDown(object sender, MouseEventArgs e)
        {
            btnConnexion.Size = new Size(95, 32); 
        }
        private void btnConnexion_MouseUp(object sender, MouseEventArgs e)
        {
            btnConnexion.Size = new Size(100, 35); 
        }
        private void btnQuitter_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblTitre_Click(object sender, EventArgs e)
        {

        }
    }
}