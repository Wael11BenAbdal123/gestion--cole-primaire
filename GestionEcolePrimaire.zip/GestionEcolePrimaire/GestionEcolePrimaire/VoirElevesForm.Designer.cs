﻿namespace GestionEcolePrimaire
{
    partial class VoirElevesForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dataGridViewEleves = new System.Windows.Forms.DataGridView();
            this.cbAnneeScolaire = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEleves)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewEleves
            // 
            this.dataGridViewEleves.ColumnHeadersHeight = 29;
            this.dataGridViewEleves.Location = new System.Drawing.Point(33, 100);
            this.dataGridViewEleves.Name = "dataGridViewEleves";
            this.dataGridViewEleves.RowHeadersWidth = 51;
            this.dataGridViewEleves.Size = new System.Drawing.Size(747, 419);
            this.dataGridViewEleves.TabIndex = 0;
            // 
            // cbAnneeScolaire
            // 
            this.cbAnneeScolaire.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAnneeScolaire.FormattingEnabled = true;
            this.cbAnneeScolaire.Location = new System.Drawing.Point(33, 30);
            this.cbAnneeScolaire.Name = "cbAnneeScolaire";
            this.cbAnneeScolaire.Size = new System.Drawing.Size(200, 24);
            this.cbAnneeScolaire.TabIndex = 1;
            this.cbAnneeScolaire.SelectedIndexChanged += new System.EventHandler(this.cbAnneeScolaire_SelectedIndexChanged);
            // 
            // VoirElevesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 554);
            this.Controls.Add(this.cbAnneeScolaire);
            this.Controls.Add(this.dataGridViewEleves);
            this.Name = "VoirElevesForm";
            this.Text = "Liste des Élèves";
            this.Load += new System.EventHandler(this.VoirElevesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEleves)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.DataGridView dataGridViewEleves;
        private System.Windows.Forms.ComboBox cbAnneeScolaire;
    }
}
