﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    internal class Outils
    {
        private string connectionString = "Data Source=WAEL\\SQLEXPRESS;Initial Catalog=GestionEcolePrimaire;Integrated Security=True";

        public DataTable GetDataTable(string query)
        {
            DataTable dataTable = new DataTable();

            try
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
                connection.Close();
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de l'exécution de la requête SQL : " + ex.Message);
            }

            return dataTable;
        }
        public void RequtteMiseAjour(String req)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=WAEL\\SQLEXPRESS;Initial Catalog=GestionEcolePrimaire;Integrated Security=True";
            cn.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(req, cn);
            cmd.ExecuteNonQuery();
            cn.Close();
        }
        public bool RequttedeRecherche(String req)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=WAEL\\SQLEXPRESS;Initial Catalog=GestionEcolePrimaire;Integrated Security=True";
            cn.Open();
            SqlCommand cmd;
            cmd = new SqlCommand(req, cn);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                return true;
            }
            else
            {
                return false;
            }
            cn.Close();
        }

        public void ChargementDVG(String req, DataGridView dvg, TextBox txt)
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=WAEL\\SQLEXPRESS;Initial Catalog=GestionEcolePrimaire;Integrated Security=True";
            cn.Open();
            SqlDataAdapter cmd_exe;
            cmd_exe = new SqlDataAdapter(req, cn);
            DataTable tab;
            tab = new DataTable();
            cmd_exe.Fill(tab);
            dvg.DataSource = tab;
            if (txt != null)
                txt.Text = tab.Rows.Count.ToString();
            cn.Close();
        }
        public void ChargementCBM(String req, ComboBox cbm)
        {
            try
            {
                SqlConnection cn = new SqlConnection();
                cn.ConnectionString = "Data Source=WAEL\\SQLEXPRESS;Initial Catalog=GestionEcolePrimaire;Integrated Security=True";
                cn.Open();
                SqlDataAdapter cmd_exe;
                cmd_exe = new SqlDataAdapter(req, cn);
                DataTable tab;
                tab = new DataTable();
                cmd_exe.Fill(tab);
                List<element> E = new List<element>();
                for (int i = 0; i < tab.Rows.Count; i++)
                {
                    element e = new element();
                    e.Identifiant = tab.Rows[i][0].ToString();
                    e.NomElement = tab.Rows[i][1].ToString();
                    E.Add(e);
                }
                cbm.DataSource = E.Count > 0 ? E : null;
                cbm.DisplayMember = "NomElement";
                cbm.ValueMember = "Identifiant";
                cn.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Erreur SQL : {ex.Message}\nRequête : {req}", "Erreur SQL", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur : {ex.Message}\nRequête : {req}", "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public string Selection(String req)

        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = "Data Source=WAEL\\SQLEXPRESS;Initial Catalog=GestionEcolePrimaire;Integrated Security=True";
            cn.Open();
            SqlDataAdapter cmd_exe;
            cmd_exe = new SqlDataAdapter(req, cn);
            DataTable tab;
            tab = new DataTable();
            cmd_exe.Fill(tab);
            if (tab.Rows.Count > 0)
            {
                return tab.Rows[0][0].ToString();
            }
            else
                return null;
            cn.Close();
        }
        public class element
        {
            public string Identifiant { get; set; }
            public string NomElement { get; set; }
        }
    }
}
