﻿using GestionEcolePrimaire;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace GestionEcolePrimaire
{
    public partial class MatiereForm : Form
    {
        private readonly Otulis otulis;

        public MatiereForm()
        {
            InitializeComponent();
            otulis = new Otulis();
            LoadNiveaux();
            LoadMatieres();
            LoadEnseignants();
        }

     
        private void LoadNiveaux()
        {
            string query = "SELECT Code_Niveau, Libelle_Niveau FROM Niveaux";
            cbNiveau.DataSource = null; 
            otulis.ChargementCBM(query, cbNiveau);
        }

     
        private void LoadEnseignants()
        {
            string query = "SELECT Code_Utilisateur, CONCAT(Nom, ' ', Prenom) AS NomComplet FROM Enseignant";
            cbEnseignant.DataSource = null;
            otulis.ChargementCBM(query, cbEnseignant);
        }

      
        private void LoadMatieres()
        {
            string query =
                "SELECT m.Code_Matiere, m.Libelle_Matiere, m.Code_Niveau, n.Libelle_Niveau, m.Coefficient_Matiere " +
                "FROM Matiere m, Niveaux n " +
                "WHERE m.Code_Niveau = n.Code_Niveau";
            otulis.ChargementDVG(query, dgvMatieres, null);
        }
      
        private void LoadEnseignantsAffectes(int codeMatiere)
        {
            string query =
                "SELECT e.Code_Utilisateur, CONCAT(e.Nom, ' ', e.Prenom) AS NomComplet " +
                "FROM Responsabilites_Enseignant re, Enseignant e " +
                "WHERE re.Code_Enseignant = e.Code_Utilisateur AND re.Code_Matiere = " + codeMatiere;
            DataTable dt = otulis.GetDataTable(query);
            dgvEnseignantsAffectes.DataSource = dt;
        }


        private void btnAjouter_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodeMatiere.Text) ||
                string.IsNullOrWhiteSpace(txtLibelleMatiere.Text) ||
                cbNiveau.SelectedValue == null)
            {
                MessageBox.Show("Veuillez remplir tous les champs correctement.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int codeMatiere;
            decimal coefficient;
            try
            {
                codeMatiere = int.Parse(txtCodeMatiere.Text);
                coefficient = decimal.Parse(txtCoefficient.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez remplir tous les champs correctement.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query =
                "INSERT INTO Matiere (Code_Matiere, Code_Niveau, Libelle_Matiere, Coefficient_Matiere) " +
                "VALUES (" + codeMatiere + ", " + cbNiveau.SelectedValue + ", '" + txtLibelleMatiere.Text.Replace("'", "''") + "', " + coefficient + ")";

            try
            {
                otulis.RequtteMiseAjour(query);
                MessageBox.Show("Matière ajoutée avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearForm();
                LoadMatieres();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnModifier_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCodeMatiere.Text) ||
                string.IsNullOrWhiteSpace(txtLibelleMatiere.Text) ||
                cbNiveau.SelectedValue == null)
            {
                MessageBox.Show("Veuillez sélectionner une matière à modifier avec un Code Matière valide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int codeMatiere;
            decimal coefficient;
            try
            {
                codeMatiere = int.Parse(txtCodeMatiere.Text);
                coefficient = decimal.Parse(txtCoefficient.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez remplir tous les champs correctement.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query =
                "UPDATE Matiere SET " +
                "Code_Niveau = " + cbNiveau.SelectedValue + ", " +
                "Libelle_Matiere = '" + txtLibelleMatiere.Text.Replace("'", "''") + "', " +
                "Coefficient_Matiere = " + coefficient.ToString(System.Globalization.CultureInfo.InvariantCulture) + " " +
                "WHERE Code_Matiere = " + codeMatiere;

            try
            {
                otulis.RequtteMiseAjour(query);
                MessageBox.Show("Matière modifiée avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClearForm();
                LoadMatieres();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCodeMatiere.Text))
            {
                MessageBox.Show("Veuillez sélectionner une matière à supprimer.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (MessageBox.Show("Voulez-vous vraiment supprimer cette matière ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string query = $"DELETE FROM Matiere WHERE Code_Matiere = {txtCodeMatiere.Text}";
                try
                {
                    otulis.RequtteMiseAjour(query);
                    MessageBox.Show("Matière supprimée avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearForm();
                    LoadMatieres();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erreur : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void btnAffecter_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCodeMatiere.Text) || cbEnseignant.SelectedValue == null)
            {
                MessageBox.Show("Veuillez sélectionner une matière et un enseignant avec un Code Matière valide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int codeMatiere;
            try
            {
                codeMatiere = int.Parse(txtCodeMatiere.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Veuillez sélectionner une matière et un enseignant avec un Code Matière valide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query =
                "INSERT INTO Responsabilites_Enseignant (Code_Enseignant, Code_Matiere) " +
                "VALUES (" + cbEnseignant.SelectedValue + ", " + codeMatiere + ")";

            try
            {
                otulis.RequtteMiseAjour(query);
                MessageBox.Show("Enseignant affecté avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadEnseignantsAffectes(codeMatiere);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDesaffecter_Click(object sender, EventArgs e)
        {
            if (dgvEnseignantsAffectes.SelectedRows.Count == 0)
            {
                MessageBox.Show("Veuillez sélectionner un enseignant à désaffecter.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int codeEnseignant = int.Parse(dgvEnseignantsAffectes.SelectedRows[0].Cells["Code_Utilisateur"].Value.ToString());
            string query = $"DELETE FROM Responsabilites_Enseignant WHERE Code_Enseignant = {codeEnseignant} AND Code_Matiere = {txtCodeMatiere.Text}";

            try
            {
                otulis.RequtteMiseAjour(query);
                MessageBox.Show("Enseignant désaffecté avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadEnseignantsAffectes(int.Parse(txtCodeMatiere.Text));
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

     
        private void dgvMatieres_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvMatieres.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvMatieres.SelectedRows[0];
                txtCodeMatiere.Text = row.Cells["Code_Matiere"].Value.ToString();
                txtLibelleMatiere.Text = row.Cells["Libelle_Matiere"].Value.ToString();
                cbNiveau.SelectedValue = row.Cells["Code_Niveau"].Value.ToString();
                txtCoefficient.Text = row.Cells["Coefficient_Matiere"].Value.ToString();
                LoadEnseignantsAffectes(int.Parse(txtCodeMatiere.Text));
            }
        }

        private void btnNouveau_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            txtCodeMatiere.Clear();
            txtLibelleMatiere.Clear();
            txtCoefficient.Clear();
            cbNiveau.SelectedIndex = -1;
            dgvEnseignantsAffectes.DataSource = null;
        }

        private void txtCodeMatiere_TextChanged(object sender, EventArgs e)
        {
            
        }


    }
}