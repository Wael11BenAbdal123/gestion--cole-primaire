﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class NouvelleInscriptionForm : Form
    {
        private Otulis otulis = new Otulis();
        private GestionInscri gestion = new GestionInscri();
        private DataTable parentsTuteurs = new DataTable();
        public NouvelleInscriptionForm()
        {
            InitializeComponent();
        }

        private void NouvelleInscriptionForm_Load(object sender, EventArgs e)
        {
            otulis.ChargementCBM("SELECT Code_Annee, Libelle_Annee FROM AnneeScolaire", cmbAnneeScolaire);
            otulis.ChargementCBM("SELECT Code_Niveau, Libelle_Niveau FROM Niveaux", cmbNiveau);
            cmbSexe.Items.AddRange(new string[] { "M", "F" });
            if (cmbAnneeScolaire.Items.Count > 0) cmbAnneeScolaire.SelectedIndex = 0;
            if (cmbNiveau.Items.Count > 0) cmbNiveau.SelectedIndex = 0;
            if (cmbSexe.Items.Count > 0) cmbSexe.SelectedIndex = 0;
            parentsTuteurs.Columns.Add("Code_Par");
            parentsTuteurs.Columns.Add("Nom_Parent");
            parentsTuteurs.Columns.Add("Prenom_Parent");
            parentsTuteurs.Columns.Add("Profession_Parent");
            parentsTuteurs.Columns.Add("Email_Parent");
            parentsTuteurs.Columns.Add("Telephone_Parent");
            parentsTuteurs.Columns.Add("Telephone_Secondaire");
            parentsTuteurs.Columns.Add("Adresse_Parent");
            parentsTuteurs.Columns.Add("Ville_Parent");
            parentsTuteurs.Columns.Add("Code_Postal");
            parentsTuteurs.Columns.Add("Est_Tuteur_Principal", typeof(bool));
            parentsTuteurs.Columns.Add("Lien_Parente");
            dgvParents.DataSource = parentsTuteurs;
            dtpDateNaissance.Format = DateTimePickerFormat.Custom;
            dtpDateNaissance.CustomFormat = "yyyy-MM-dd";
            dtpDateNaissance.Value = DateTime.Now;
        }
        private void btnRechercher_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable result = gestion.RechercherEleve(txtNumInscriptionRecherche.Text, txtNomRecherche.Text);
                dgvResultats.DataSource = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la recherche : " + ex.Message);
            }
        }
        private void btnAjouterParent_Click(object sender, EventArgs e)
        {
            AjouterParentForm ajoutParentForm = new AjouterParentForm();
            if (ajoutParentForm.ShowDialog() == DialogResult.OK)
            {
                parentsTuteurs.Rows.Add(
                    ajoutParentForm.Code_Par,
                    ajoutParentForm.NomParent,
                    ajoutParentForm.PrenomParent,
                    ajoutParentForm.ProfessionParent,
                    ajoutParentForm.EmailParent,
                    ajoutParentForm.TelephoneParent,
                    ajoutParentForm.TelephoneSecondaire,
                    ajoutParentForm.AdresseParent,
                    ajoutParentForm.VilleParent,
                    ajoutParentForm.CodePostal,
                    ajoutParentForm.EstTuteurPrincipal,
                    ajoutParentForm.LienParente
                );
            }
        }
        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            try
            {
                int numInscription = string.IsNullOrEmpty(txtNumInscription.Text) ? 0 : int.Parse(txtNumInscription.Text);
                int niveauId = int.Parse(cmbNiveau.SelectedValue.ToString());
                int anneeId = int.Parse(cmbAnneeScolaire.SelectedValue.ToString());

                gestion.EnregistrerInscription(txtNom.Text, txtPrenom.Text, cmbSexe.Text, dtpDateNaissance.Value.ToString("yyyy-MM-dd"),
                                              txtLieuNaissance.Text, numInscription,
                                              parentsTuteurs, niveauId, anneeId);
                MessageBox.Show("Inscription enregistrée avec succès.");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'enregistrement : " + ex.Message);
            }
        }
        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvResultats_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && e.RowIndex < dgvResultats.Rows.Count)
                {
                    DataTable result = (DataTable)dgvResultats.DataSource;
                    DataRow row = result.Rows[e.RowIndex];

                    txtNumInscription.Text = row["Num_Ins_Eleve"].ToString();
                    txtNom.Text = row["Nom_Eleve"].ToString();
                    txtPrenom.Text = row["Prenom_Eleve"].ToString();
                    cmbSexe.SelectedItem = row["Sexe_Eleve"].ToString();
                    dtpDateNaissance.Value = Convert.ToDateTime(row["Date_Nais_Eleve"]);
                    txtLieuNaissance.Text = row["Lieu_Nais_Eleve"].ToString();

                    txtNumInscription.ReadOnly = true;
                    parentsTuteurs.Rows.Clear();

                    int numInsEleve = Convert.ToInt32(row["Num_Ins_Eleve"]);
                    List<int> parentsAjoutes = new List<int>(); // Remplacement du HashSet par une List

                    foreach (DataRow r in result.Rows)
                    {
                        if (!r.IsNull("Code_Par") && Convert.ToInt32(r["Num_Ins_Eleve"]) == numInsEleve)
                        {
                            int codePar = Convert.ToInt32(r["Code_Par"]);
                            if (!parentsAjoutes.Contains(codePar)) // Vérification manuelle des doublons
                            {
                                parentsTuteurs.Rows.Add(
                                    r["Code_Par"], r["Nom_Parent"], r["Prenom_Parent"], r["Profession_Parent"],
                                    r["Email_Parent"], r["Telephone_Parent"], r["Telephone_Secondaire"],
                                    r["Adresse_Parent"], r["Ville_Parent"], r["Code_Postal"],
                                    r["Est_Tuteur_Principal"], r["Lien_Parente"]
                                );

                                parentsAjoutes.Add(codePar); // Ajout à la liste
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la sélection de l'élève : " + ex.Message);
            }
        }
    }
}