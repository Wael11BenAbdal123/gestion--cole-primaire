﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class AjouterParentForm : Form
    {
        public string Code_Par { get; private set; }
        public string NomParent { get; private set; }
        public string PrenomParent { get; private set; }
        public string ProfessionParent { get; private set; }
        public string EmailParent { get; private set; }
        public string TelephoneParent { get; private set; }
        public string TelephoneSecondaire { get; private set; }
        public string AdresseParent { get; private set; }
        public string VilleParent { get; private set; }
        public string CodePostal { get; private set; }
        public bool EstTuteurPrincipal { get; private set; }
        public string LienParente { get; private set; }
        private bool ValiderChamps()
        {
            bool valide = true;

            
            txtNomParent.BackColor = SystemColors.Window;
            txtPrenomParent.BackColor = SystemColors.Window;
            cmbLienParent.BackColor = SystemColors.Window;
            txtEmailParent.BackColor = SystemColors.Window;
            txtTelephoneParent.BackColor = SystemColors.Window;
            txtCodePostal.BackColor = SystemColors.Window;

            
            if (string.IsNullOrEmpty(txtNomParent.Text))
            {
                txtNomParent.BackColor = Color.LightCoral;
                valide = false;
            }

            if (string.IsNullOrEmpty(txtPrenomParent.Text))
            {
                txtPrenomParent.BackColor = Color.LightCoral;
                valide = false;
            }

            if (string.IsNullOrEmpty(cmbLienParent.Text))
            {
                cmbLienParent.BackColor = Color.LightCoral;
                valide = false;
            }

            
            if (!txtEmailParent.Text.Contains("@") || !txtEmailParent.Text.Contains("."))
            {
                txtEmailParent.BackColor = Color.LightCoral;
                valide = false;
            }

            
            if (txtTelephoneParent.Text.Length != 8 || !long.TryParse(txtTelephoneParent.Text, out _))
            {
                txtTelephoneParent.BackColor = Color.LightCoral;
                valide = false;
            }

            
            if (!string.IsNullOrEmpty(txtCodePostal.Text) && txtCodePostal.Text.Length != 4)
            {
                txtCodePostal.BackColor = Color.LightCoral;
                valide = false;
            }

           
            return valide;
        }

        public AjouterParentForm(string cod = "",string nom = "", string prenom = "", string profession = "", string email = "",
                                 string telephone = "", string telephoneSec = "", string adresse = "",
                                 string ville = "", string codePostal = "", bool tuteurPrincipal = false,
                                 string lienParente = "")
        {
            InitializeComponent();
            txtCode.Text = cod;
            txtNomParent.Text = nom;
            txtPrenomParent.Text = prenom;
            txtProfessionParent.Text = profession;
            txtEmailParent.Text = email;
            txtTelephoneParent.Text = telephone;
            txtTelephoneSecondaire.Text = telephoneSec;
            txtAdresseParent.Text = adresse;
            txtVilleParent.Text = ville;
            txtCodePostal.Text = codePostal;
            chkTuteurPrincipal.Checked = tuteurPrincipal;    
            cmbLienParent.SelectedIndex = -1;
            
        }

        private void btnValider_Click(object sender, EventArgs e)
        {
            if (!ValiderChamps())
            {
                MessageBox.Show("Veuillez corriger les champs en rouge avant de valider.", "Erreur de validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Code_Par = txtCode.Text.Trim();
            NomParent = txtNomParent.Text.Trim();
            PrenomParent = txtPrenomParent.Text.Trim();
            ProfessionParent = txtProfessionParent.Text.Trim();
            EmailParent = txtEmailParent.Text.Trim();
            TelephoneParent = txtTelephoneParent.Text.Trim();
            TelephoneSecondaire = txtTelephoneSecondaire.Text.Trim();
            AdresseParent = txtAdresseParent.Text.Trim();
            VilleParent = txtVilleParent.Text.Trim();
            CodePostal = txtCodePostal.Text.Trim();
            EstTuteurPrincipal = chkTuteurPrincipal.Checked;
            LienParente = cmbLienParent.Text.Trim();

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
        private void AjouterParentForm_Load(object sender, EventArgs e)
        {

        }

       
    }
}