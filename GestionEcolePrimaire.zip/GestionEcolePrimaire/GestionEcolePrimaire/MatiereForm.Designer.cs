﻿namespace GestionEcolePrimaire
{
    partial class MatiereForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            // Form Controls (existing)
            this.lblCodeMatiere = new System.Windows.Forms.Label();
            this.txtCodeMatiere = new System.Windows.Forms.TextBox();
            this.lblLibelleMatiere = new System.Windows.Forms.Label();
            this.txtLibelleMatiere = new System.Windows.Forms.TextBox();
            this.lblNiveau = new System.Windows.Forms.Label();
            this.cbNiveau = new System.Windows.Forms.ComboBox();
            this.lblCoefficient = new System.Windows.Forms.Label();
            this.txtCoefficient = new System.Windows.Forms.TextBox();
            this.btnModifier = new System.Windows.Forms.Button();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.btnSupprimer = new System.Windows.Forms.Button();
            this.btnNouveau = new System.Windows.Forms.Button();
            this.dgvMatieres = new System.Windows.Forms.DataGridView();
            this.lblEnseignant = new System.Windows.Forms.Label();
            this.cbEnseignant = new System.Windows.Forms.ComboBox();
            this.btnAffecter = new System.Windows.Forms.Button();
            this.btnDesaffecter = new System.Windows.Forms.Button();
            this.dgvEnseignantsAffectes = new System.Windows.Forms.DataGridView();

            ((System.ComponentModel.ISupportInitialize)(this.dgvMatieres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEnseignantsAffectes)).EndInit();
            this.SuspendLayout();

            // dgvMatieres (Top Table)
            this.dgvMatieres.AllowUserToAddRows = false;
            this.dgvMatieres.AllowUserToDeleteRows = false;
            this.dgvMatieres.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMatieres.Location = new System.Drawing.Point(220, 20);
            this.dgvMatieres.Name = "dgvMatieres";
            this.dgvMatieres.ReadOnly = true;
            this.dgvMatieres.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMatieres.Size = new System.Drawing.Size(750, 200);
            this.dgvMatieres.TabIndex = 4;
            this.dgvMatieres.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.dgvMatieres.EnableHeadersVisualStyles = false;
            this.dgvMatieres.RowHeadersVisible = false;
            this.dgvMatieres.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dgvMatieres.SelectionChanged += new System.EventHandler(this.dgvMatieres_SelectionChanged);

            // Form Fields
            this.lblCodeMatiere.AutoSize = true;
            this.lblCodeMatiere.Location = new System.Drawing.Point(220, 240);
            this.lblCodeMatiere.Name = "lblCodeMatiere";
            this.lblCodeMatiere.Size = new System.Drawing.Size(80, 15);
            this.lblCodeMatiere.Text = "Code Matière :";
            this.lblCodeMatiere.Font = new System.Drawing.Font("Segoe UI", 9F);

            this.txtCodeMatiere.Location = new System.Drawing.Point(320, 237);
            this.txtCodeMatiere.Name = "txtCodeMatiere";
            this.txtCodeMatiere.Size = new System.Drawing.Size(180, 25);
            this.txtCodeMatiere.TabIndex = 0;
            this.txtCodeMatiere.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtCodeMatiere.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCodeMatiere.TextChanged += new System.EventHandler(this.txtCodeMatiere_TextChanged);

            this.lblLibelleMatiere.AutoSize = true;
            this.lblLibelleMatiere.Location = new System.Drawing.Point(220, 270);
            this.lblLibelleMatiere.Name = "lblLibelleMatiere";
            this.lblLibelleMatiere.Size = new System.Drawing.Size(90, 15);
            this.lblLibelleMatiere.Text = "Libellé Matière :";
            this.lblLibelleMatiere.Font = new System.Drawing.Font("Segoe UI", 9F);

            this.txtLibelleMatiere.Location = new System.Drawing.Point(320, 267);
            this.txtLibelleMatiere.Name = "txtLibelleMatiere";
            this.txtLibelleMatiere.Size = new System.Drawing.Size(180, 25);
            this.txtLibelleMatiere.TabIndex = 1;
            this.txtLibelleMatiere.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtLibelleMatiere.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            this.lblNiveau.AutoSize = true;
            this.lblNiveau.Location = new System.Drawing.Point(220, 300);
            this.lblNiveau.Name = "lblNiveau";
            this.lblNiveau.Size = new System.Drawing.Size(50, 15);
            this.lblNiveau.Text = "Niveau :";
            this.lblNiveau.Font = new System.Drawing.Font("Segoe UI", 9F);

            this.cbNiveau.Location = new System.Drawing.Point(320, 297);
            this.cbNiveau.Name = "cbNiveau";
            this.cbNiveau.Size = new System.Drawing.Size(180, 25);
            this.cbNiveau.TabIndex = 2;
            this.cbNiveau.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbNiveau.FlatStyle = System.Windows.Forms.FlatStyle.Flat;

            this.lblCoefficient.AutoSize = true;
            this.lblCoefficient.Location = new System.Drawing.Point(220, 330);
            this.lblCoefficient.Name = "lblCoefficient";
            this.lblCoefficient.Size = new System.Drawing.Size(70, 15);
            this.lblCoefficient.Text = "Coefficient :";
            this.lblCoefficient.Font = new System.Drawing.Font("Segoe UI", 9F);

            this.txtCoefficient.Location = new System.Drawing.Point(320, 327);
            this.txtCoefficient.Name = "txtCoefficient";
            this.txtCoefficient.Size = new System.Drawing.Size(180, 25);
            this.txtCoefficient.TabIndex = 3;
            this.txtCoefficient.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtCoefficient.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            // Buttons (Ajouter, Modifier, Supprimer, Nouveau)
            this.btnAjouter.Location = new System.Drawing.Point(220, 360);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(90, 35);
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnAjouter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAjouter.FlatAppearance.BorderSize = 0;
            this.btnAjouter.UseVisualStyleBackColor = false;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);

            this.btnModifier.Location = new System.Drawing.Point(320, 360);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(90, 35);
            this.btnModifier.Text = "Modifier";
            this.btnModifier.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnModifier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModifier.FlatAppearance.BorderSize = 0;
            this.btnModifier.UseVisualStyleBackColor = false;
            this.btnModifier.Click += new System.EventHandler(this.btnModifier_Click);

            this.btnSupprimer.Location = new System.Drawing.Point(420, 360);
            this.btnSupprimer.Name = "btnSupprimer";
            this.btnSupprimer.Size = new System.Drawing.Size(90, 35);
            this.btnSupprimer.Text = "Supprimer";
            this.btnSupprimer.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnSupprimer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSupprimer.FlatAppearance.BorderSize = 0;
            this.btnSupprimer.UseVisualStyleBackColor = false;
            this.btnSupprimer.Click += new System.EventHandler(this.btnSupprimer_Click);

            this.btnNouveau.Location = new System.Drawing.Point(520, 360);
            this.btnNouveau.Name = "btnNouveau";
            this.btnNouveau.Size = new System.Drawing.Size(90, 35);
            this.btnNouveau.Text = "Nouveau";
            this.btnNouveau.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnNouveau.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNouveau.FlatAppearance.BorderSize = 0;
            this.btnNouveau.UseVisualStyleBackColor = false;
            this.btnNouveau.Click += new System.EventHandler(this.btnNouveau_Click);

            // Affecter and Désaffecter Section
            this.lblEnseignant.AutoSize = true;
            this.lblEnseignant.Location = new System.Drawing.Point(220, 410);
            this.lblEnseignant.Name = "lblEnseignant";
            this.lblEnseignant.Size = new System.Drawing.Size(70, 15);
            this.lblEnseignant.Text = "Enseignant :";
            this.lblEnseignant.Font = new System.Drawing.Font("Segoe UI", 9F);

            this.cbEnseignant.Location = new System.Drawing.Point(320, 407);
            this.cbEnseignant.Name = "cbEnseignant";
            this.cbEnseignant.Size = new System.Drawing.Size(180, 25);
            this.cbEnseignant.TabIndex = 5;
            this.cbEnseignant.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbEnseignant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;

            this.btnAffecter.Location = new System.Drawing.Point(510, 407);
            this.btnAffecter.Name = "btnAffecter";
            this.btnAffecter.Size = new System.Drawing.Size(90, 35);
            this.btnAffecter.Text = "Affecter";
            this.btnAffecter.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnAffecter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAffecter.FlatAppearance.BorderSize = 0;
            this.btnAffecter.UseVisualStyleBackColor = false;
            this.btnAffecter.Click += new System.EventHandler(this.btnAffecter_Click);

            this.btnDesaffecter.Location = new System.Drawing.Point(610, 407);
            this.btnDesaffecter.Name = "btnDesaffecter";
            this.btnDesaffecter.Size = new System.Drawing.Size(90, 35);
            this.btnDesaffecter.Text = "Désaffecter";
            this.btnDesaffecter.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnDesaffecter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDesaffecter.FlatAppearance.BorderSize = 0;
            this.btnDesaffecter.UseVisualStyleBackColor = false;
            this.btnDesaffecter.Click += new System.EventHandler(this.btnDesaffecter_Click);

            // dgvEnseignantsAffectes
            this.dgvEnseignantsAffectes.AllowUserToAddRows = false;
            this.dgvEnseignantsAffectes.AllowUserToDeleteRows = false;
            this.dgvEnseignantsAffectes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEnseignantsAffectes.Location = new System.Drawing.Point(220, 450);
            this.dgvEnseignantsAffectes.Name = "dgvEnseignantsAffectes";
            this.dgvEnseignantsAffectes.ReadOnly = true;
            this.dgvEnseignantsAffectes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEnseignantsAffectes.Size = new System.Drawing.Size(750, 130);
            this.dgvEnseignantsAffectes.TabIndex = 6;
            this.dgvEnseignantsAffectes.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.dgvEnseignantsAffectes.EnableHeadersVisualStyles = false;
            this.dgvEnseignantsAffectes.RowHeadersVisible = false;
            this.dgvEnseignantsAffectes.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F);

            // MatiereForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 600);

            this.Controls.Add(this.dgvMatieres);
            this.Controls.Add(this.lblCodeMatiere);
            this.Controls.Add(this.txtCodeMatiere);
            this.Controls.Add(this.lblLibelleMatiere);
            this.Controls.Add(this.txtLibelleMatiere);
            this.Controls.Add(this.lblNiveau);
            this.Controls.Add(this.cbNiveau);
            this.Controls.Add(this.lblCoefficient);
            this.Controls.Add(this.txtCoefficient);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.btnModifier);
            this.Controls.Add(this.btnSupprimer);
            this.Controls.Add(this.btnNouveau);
            this.Controls.Add(this.lblEnseignant);
            this.Controls.Add(this.cbEnseignant);
            this.Controls.Add(this.btnAffecter);
            this.Controls.Add(this.btnDesaffecter);
            this.Controls.Add(this.dgvEnseignantsAffectes);

            this.Name = "MatiereForm";
            this.Text = "Gestion des Matières et Affectations";
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            ((System.ComponentModel.ISupportInitialize)(this.dgvMatieres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEnseignantsAffectes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblCodeMatiere;
        private System.Windows.Forms.TextBox txtCodeMatiere;
        private System.Windows.Forms.Label lblLibelleMatiere;
        private System.Windows.Forms.TextBox txtLibelleMatiere;
        private System.Windows.Forms.Label lblNiveau;
        private System.Windows.Forms.ComboBox cbNiveau;
        private System.Windows.Forms.Label lblCoefficient;
        private System.Windows.Forms.TextBox txtCoefficient;
        private System.Windows.Forms.Button btnModifier;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Button btnSupprimer;
        private System.Windows.Forms.Button btnNouveau;
        private System.Windows.Forms.DataGridView dgvMatieres;
        private System.Windows.Forms.Label lblEnseignant;
        private System.Windows.Forms.ComboBox cbEnseignant;
        private System.Windows.Forms.Button btnAffecter;
        private System.Windows.Forms.Button btnDesaffecter;
        private System.Windows.Forms.DataGridView dgvEnseignantsAffectes;
    }
}