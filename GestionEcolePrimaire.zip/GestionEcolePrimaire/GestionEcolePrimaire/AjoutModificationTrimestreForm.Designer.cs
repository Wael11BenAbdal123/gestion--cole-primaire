﻿namespace GestionEcolePrimaire
{
    partial class AjoutModificationTrimestreForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblCodeTrimestre = new System.Windows.Forms.Label();
            this.txtCodeTrimestre = new System.Windows.Forms.TextBox();
            this.lblLibelleTrimestre = new System.Windows.Forms.Label();
            this.txtLibelleTrimestre = new System.Windows.Forms.TextBox();
            this.btnEnregistrer = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCodeTrimestre
            // 
            this.lblCodeTrimestre.AutoSize = true;
            this.lblCodeTrimestre.Location = new System.Drawing.Point(12, 20);
            this.lblCodeTrimestre.Name = "lblCodeTrimestre";
            this.lblCodeTrimestre.Size = new System.Drawing.Size(86, 15);
            this.lblCodeTrimestre.TabIndex = 0;
            this.lblCodeTrimestre.Text = "Code Trimestre :";
            // 
            // txtCodeTrimestre
            // 
            this.txtCodeTrimestre.Location = new System.Drawing.Point(120, 17);
            this.txtCodeTrimestre.Name = "txtCodeTrimestre";
            this.txtCodeTrimestre.Size = new System.Drawing.Size(150, 23);
            this.txtCodeTrimestre.TabIndex = 1;
            // 
            // lblLibelleTrimestre
            // 
            this.lblLibelleTrimestre.AutoSize = true;
            this.lblLibelleTrimestre.Location = new System.Drawing.Point(12, 50);
            this.lblLibelleTrimestre.Name = "lblLibelleTrimestre";
            this.lblLibelleTrimestre.Size = new System.Drawing.Size(101, 15);
            this.lblLibelleTrimestre.TabIndex = 2;
            this.lblLibelleTrimestre.Text = "Libellé Trimestre :";
            // 
            // txtLibelleTrimestre
            // 
            this.txtLibelleTrimestre.Location = new System.Drawing.Point(120, 47);
            this.txtLibelleTrimestre.Name = "txtLibelleTrimestre";
            this.txtLibelleTrimestre.Size = new System.Drawing.Size(150, 23);
            this.txtLibelleTrimestre.TabIndex = 3;
            // 
            // btnEnregistrer
            // 
            this.btnEnregistrer.Location = new System.Drawing.Point(50, 90);
            this.btnEnregistrer.Name = "btnEnregistrer";
            this.btnEnregistrer.Size = new System.Drawing.Size(100, 30);
            this.btnEnregistrer.TabIndex = 4;
            this.btnEnregistrer.Text = "Enregistrer";
            this.btnEnregistrer.UseVisualStyleBackColor = true;
            this.btnEnregistrer.Click += new System.EventHandler(this.btnEnregistrer_Click);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(170, 90);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(100, 30);
            this.btnAnnuler.TabIndex = 5;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = true;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // AjoutModificationTrimestreForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 141);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnEnregistrer);
            this.Controls.Add(this.txtLibelleTrimestre);
            this.Controls.Add(this.lblLibelleTrimestre);
            this.Controls.Add(this.txtCodeTrimestre);
            this.Controls.Add(this.lblCodeTrimestre);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "AjoutModificationTrimestreForm";
            this.Text = "Ajouter/Modifier Trimestre";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblCodeTrimestre;
        private System.Windows.Forms.TextBox txtCodeTrimestre;
        private System.Windows.Forms.Label lblLibelleTrimestre;
        private System.Windows.Forms.TextBox txtLibelleTrimestre;
        private System.Windows.Forms.Button btnEnregistrer;
        private System.Windows.Forms.Button btnAnnuler;
    }
}