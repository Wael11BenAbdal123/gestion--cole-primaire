﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class ModifierInscriptionForm : Form
    {
        private Otulis otulis = new Otulis();
        private GestionInscri gestion = new GestionInscri();
        private DataTable parentsTuteurs = new DataTable();

        public ModifierInscriptionForm(int numInscriptionInitial = 0)
        {
            InitializeComponent();
            if (numInscriptionInitial != 0)
            {
                ChargerInscription(numInscriptionInitial);
            }
            else
            {
                MessageBox.Show("Aucun numéro d'inscription fourni.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void ModifierInscriptionForm_Load(object sender, EventArgs e)
        {
            otulis.ChargementCBM("SELECT Code_Annee, Libelle_Annee FROM AnneeScolaire", cmbAnneeScolaire);
            otulis.ChargementCBM("SELECT Code_Niveau, Libelle_Niveau FROM Niveaux", cmbNiveau);
            otulis.ChargementCBM("SELECT Code_Classe, Libelle_Classe FROM Classe", cmbClasse);
            cmbSexe.Items.AddRange(new string[] { "M", "F" });
            cmbStatut.Items.AddRange(new string[] { "En attente", "Affecté", "Rejeté" });
            if (cmbAnneeScolaire.Items.Count > 0) cmbAnneeScolaire.SelectedIndex = 0;
            if (cmbNiveau.Items.Count > 0) cmbNiveau.SelectedIndex = 0;
            if (cmbSexe.Items.Count > 0) cmbSexe.SelectedIndex = 0;
            if (cmbStatut.Items.Count > 0) cmbStatut.SelectedIndex = 0;
            cmbClasse.Enabled = false;
            dtpDateNaissance.Format = DateTimePickerFormat.Custom;
            dtpDateNaissance.CustomFormat = "yyyy-MM-dd";
            if (!parentsTuteurs.Columns.Contains("Code_Par")) parentsTuteurs.Columns.Add("Code_Par", typeof(int));
            if (!parentsTuteurs.Columns.Contains("Nom_Parent")) parentsTuteurs.Columns.Add("Nom_Parent", typeof(string));
            if (!parentsTuteurs.Columns.Contains("Prenom_Parent")) parentsTuteurs.Columns.Add("Prenom_Parent", typeof(string));
            if (!parentsTuteurs.Columns.Contains("Profession_Parent")) parentsTuteurs.Columns.Add("Profession_Parent", typeof(string));
            if (!parentsTuteurs.Columns.Contains("Email_Parent")) parentsTuteurs.Columns.Add("Email_Parent", typeof(string));
            if (!parentsTuteurs.Columns.Contains("Telephone_Parent")) parentsTuteurs.Columns.Add("Telephone_Parent", typeof(string));
            if (!parentsTuteurs.Columns.Contains("Telephone_Secondaire")) parentsTuteurs.Columns.Add("Telephone_Secondaire", typeof(string));
            if (!parentsTuteurs.Columns.Contains("Adresse_Parent")) parentsTuteurs.Columns.Add("Adresse_Parent", typeof(string));
            if (!parentsTuteurs.Columns.Contains("Ville_Parent")) parentsTuteurs.Columns.Add("Ville_Parent", typeof(string));
            if (!parentsTuteurs.Columns.Contains("Code_Postal")) parentsTuteurs.Columns.Add("Code_Postal", typeof(string));
            if (!parentsTuteurs.Columns.Contains("Est_Tuteur_Principal")) parentsTuteurs.Columns.Add("Est_Tuteur_Principal", typeof(bool));
            if (!parentsTuteurs.Columns.Contains("Lien_Parente")) parentsTuteurs.Columns.Add("Lien_Parente", typeof(string));
            dgvParents.DataSource = parentsTuteurs;
            dgvParents.AutoGenerateColumns = true;
            // champs élève en lecture seule
            //txtNumInscription.ReadOnly = true;
            //txtNom.ReadOnly = true;
            //txtPrenom.ReadOnly = true;
            //cmbSexe.Enabled = false;
            //dtpDateNaissance.Enabled = false;
            //txtLieuNaissance.ReadOnly = true;
        }
        private void ChargerInscription(int numInscription)
        {
            try
            {
                DataTable result = gestion.RechercherEleve(numInscription.ToString(), "");
                if (result.Rows.Count == 0)
                {
                    MessageBox.Show($"Aucune inscription trouvée pour le numéro {numInscription}.",
                                    "Inscription introuvable", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                DataRow row = result.Rows[0];
                txtNumInscription.Text = row["Num_Ins_Eleve"].ToString();
                txtNom.Text = row["Nom_Eleve"].ToString();
                txtPrenom.Text = row["Prenom_Eleve"].ToString();
                cmbSexe.SelectedItem = row["Sexe_Eleve"].ToString();
                dtpDateNaissance.Value = Convert.ToDateTime(row["Date_Nais_Eleve"]);
                txtLieuNaissance.Text = row["Lieu_Nais_Eleve"].ToString();
                DataTable inscription = otulis.GetDataTable($"SELECT * FROM Inscription WHERE EleveID = {numInscription}");
                if (inscription.Rows.Count > 0)
                {
                    cmbNiveau.SelectedValue = inscription.Rows[0]["NiveauID"];
                    cmbAnneeScolaire.SelectedValue = inscription.Rows[0]["AnneeID"];
                    cmbStatut.SelectedItem = inscription.Rows[0]["Statut"].ToString();
                    if (inscription.Rows[0]["Statut"].ToString() == "Confirmée" && !DBNull.Value.Equals(inscription.Rows[0]["ClasseID"]))
                    {
                        cmbClasse.Enabled = true;
                        cmbClasse.SelectedValue = inscription.Rows[0]["ClasseID"];
                    }
                }
                if (parentsTuteurs.Columns.Count == 0)
                {
                    parentsTuteurs.Columns.Add("Code_Par", typeof(string));
                    parentsTuteurs.Columns.Add("Nom_Parent", typeof(string));
                    parentsTuteurs.Columns.Add("Prenom_Parent", typeof(string));
                    parentsTuteurs.Columns.Add("Profession_Parent", typeof(string));
                    parentsTuteurs.Columns.Add("Email_Parent", typeof(string));
                    parentsTuteurs.Columns.Add("Telephone_Parent", typeof(string));
                    parentsTuteurs.Columns.Add("Telephone_Secondaire", typeof(string));
                    parentsTuteurs.Columns.Add("Adresse_Parent", typeof(string));
                    parentsTuteurs.Columns.Add("Ville_Parent", typeof(string));
                    parentsTuteurs.Columns.Add("Code_Postal", typeof(string));
                    parentsTuteurs.Columns.Add("Est_Tuteur_Principal", typeof(bool)); 
                    parentsTuteurs.Columns.Add("Lien_Parente", typeof(string));
                }
                parentsTuteurs.Rows.Clear();
                int parentCount = 0;
                foreach (DataRow r in result.Rows)
                {
                    if (!r.IsNull("Code_Par"))
                    {
                        try
                        {
                            parentsTuteurs.Rows.Add(
                                r["Code_Par"], r["Nom_Parent"], r["Prenom_Parent"], r["Profession_Parent"],
                                r["Email_Parent"], r["Telephone_Parent"], r["Telephone_Secondaire"],
                                r["Adresse_Parent"], r["Ville_Parent"], r["Code_Postal"],
                                r["Est_Tuteur_Principal"], r["Lien_Parente"]
                            );
                            parentCount++;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Erreur lors de l'ajout des données pour le parent : {ex.Message}",
                                            "Erreur critique", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                if (parentCount == 0)
                {
                    MessageBox.Show($"Aucun parent trouvé pour l'élève {numInscription}. Vérifiez les tables Tuteurs et Parent.",
                                    "Aucun parent", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    //MessageBox.Show($"{parentCount} parent(s) chargé(s) dans parentsTuteurs.",
                                   // "Parents chargés", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                dgvParents.DataSource = null;
                dgvParents.DataSource = parentsTuteurs;
                dgvParents.Refresh(); 
                if (dgvParents.Columns.Count == 0)
                {
                    MessageBox.Show("Aucune colonne générée dans dgvParents. Vérifiez AutoGenerateColumns.",
                                    "Problème d'affichage", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement de l'inscription : " + ex.Message);
            }
        }
        private void btnAjouterParent_Click(object sender, EventArgs e)
        {
            AjouterParentForm ajoutParentForm = new AjouterParentForm();
            if (ajoutParentForm.ShowDialog() == DialogResult.OK)
            {
                parentsTuteurs.Rows.Add(
                    ajoutParentForm.Code_Par != "" ? int.Parse(ajoutParentForm.Code_Par) : (object)DBNull.Value,
                    ajoutParentForm.NomParent, ajoutParentForm.PrenomParent, ajoutParentForm.ProfessionParent,
                    ajoutParentForm.EmailParent, ajoutParentForm.TelephoneParent, ajoutParentForm.TelephoneSecondaire,
                    ajoutParentForm.AdresseParent, ajoutParentForm.VilleParent, ajoutParentForm.CodePostal,
                    ajoutParentForm.EstTuteurPrincipal, ajoutParentForm.LienParente
                );
                dgvParents.Refresh(); 
            }
        }
        private void btnModifierParent_Click(object sender, EventArgs e)
        {
            if (dgvParents.SelectedRows.Count > 0)
            {
                DataRow row = parentsTuteurs.Rows[dgvParents.SelectedRows[0].Index];
                AjouterParentForm modifierParentForm = new AjouterParentForm(
                    row["Code_Par"].ToString(), row["Nom_Parent"].ToString(), row["Prenom_Parent"].ToString(),
                    row["Profession_Parent"].ToString(), row["Email_Parent"].ToString(), row["Telephone_Parent"].ToString(),
                    row["Telephone_Secondaire"].ToString(), row["Adresse_Parent"].ToString(), row["Ville_Parent"].ToString(),
                    row["Code_Postal"].ToString(), Convert.ToBoolean(row["Est_Tuteur_Principal"]), row["Lien_Parente"].ToString()
                );

                if (modifierParentForm.ShowDialog() == DialogResult.OK)
                {
                    row["Code_Par"] = modifierParentForm.Code_Par != "" ? int.Parse(modifierParentForm.Code_Par) : (object)DBNull.Value;
                    row["Nom_Parent"] = modifierParentForm.NomParent;
                    row["Prenom_Parent"] = modifierParentForm.PrenomParent;
                    row["Profession_Parent"] = modifierParentForm.ProfessionParent;
                    row["Email_Parent"] = modifierParentForm.EmailParent;
                    row["Telephone_Parent"] = modifierParentForm.TelephoneParent;
                    row["Telephone_Secondaire"] = modifierParentForm.TelephoneSecondaire;
                    row["Adresse_Parent"] = modifierParentForm.AdresseParent;
                    row["Ville_Parent"] = modifierParentForm.VilleParent;
                    row["Code_Postal"] = modifierParentForm.CodePostal;
                    row["Est_Tuteur_Principal"] = modifierParentForm.EstTuteurPrincipal;
                    row["Lien_Parente"] = modifierParentForm.LienParente;
                    dgvParents.Refresh(); 
                }
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un parent à modifier.", "Aucune sélection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnSupprimerParent_Click(object sender, EventArgs e)
        {
            if (dgvParents.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dgvParents.SelectedRows)
                {
                    parentsTuteurs.Rows.RemoveAt(row.Index);
                }
                dgvParents.Refresh(); 
            }
            else
            {
                MessageBox.Show("Veuillez sélectionner un parent à supprimer.", "Aucune sélection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtNumInscription.Text))
                {
                    MessageBox.Show("Aucune inscription sélectionnée.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int numInscription = int.Parse(txtNumInscription.Text);
                int niveauId = int.Parse(cmbNiveau.SelectedValue.ToString());
                int anneeId = int.Parse(cmbAnneeScolaire.SelectedValue.ToString());
                string classeId = cmbStatut.Text == "Confirmée" && cmbClasse.SelectedValue != null ? cmbClasse.SelectedValue.ToString() : null;

                gestion.ModifierInscription(txtNom.Text, txtPrenom.Text, cmbSexe.Text, dtpDateNaissance.Value.ToString("yyyy-MM-dd"),
                                            txtLieuNaissance.Text, numInscription, parentsTuteurs, niveauId, anneeId, cmbStatut.Text, classeId);
                MessageBox.Show("Modification enregistrée avec succès.");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la modification : " + ex.Message);
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cmbStatut_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbClasse.Enabled = cmbStatut.Text == "Affecté";
        }
    }
}