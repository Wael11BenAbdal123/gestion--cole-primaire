﻿using System;
using System.Data;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class GestionTrimestreForm : Form
    {
        private Otulis otulis = new Otulis();
        private bool columnsInitialized = false;

        public GestionTrimestreForm()
        {
            InitializeComponent();
            LoadTrimestres();
        }

        private void LoadTrimestres(string searchText = "")
        {
            try
            {
                string query = "SELECT Code_Trimestre, Libelle_Trimestre FROM Trimestre";
                if (!string.IsNullOrEmpty(searchText))
                {
                    query += $" WHERE Libelle_Trimestre LIKE '%{searchText}%'";
                }
                otulis.ChargementDVG(query, dvgTrimestres, txtTotalTrimestres);

                // Ajouter les colonnes de boutons si elles n'existent pas
                if (!columnsInitialized)
                {
                    // Vérifier si les colonnes existent déjà pour éviter les doublons
                    if (!dvgTrimestres.Columns.Contains("Modifier"))
                    {
                        DataGridViewButtonColumn btnModifier = new DataGridViewButtonColumn();
                        btnModifier.Name = "Modifier";
                        btnModifier.HeaderText = "";
                        btnModifier.Text = "Modifier";
                        btnModifier.UseColumnTextForButtonValue = true;
                        dvgTrimestres.Columns.Add(btnModifier);
                    }

                    if (!dvgTrimestres.Columns.Contains("Supprimer"))
                    {
                        DataGridViewButtonColumn btnSupprimer = new DataGridViewButtonColumn();
                        btnSupprimer.Name = "Supprimer";
                        btnSupprimer.HeaderText = "";
                        btnSupprimer.Text = "Supprimer";
                        btnSupprimer.UseColumnTextForButtonValue = true;
                        dvgTrimestres.Columns.Add(btnSupprimer);
                    }

                    columnsInitialized = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des trimestres : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            AjoutModificationTrimestreForm ajoutForm = new AjoutModificationTrimestreForm(null);
            if (ajoutForm.ShowDialog() == DialogResult.OK)
            {
                LoadTrimestres(txtRecherche.Text);
            }
        }

        private void txtRecherche_TextChanged(object sender, EventArgs e)
        {
            LoadTrimestres(txtRecherche.Text);
        }

        private void dvgTrimestres_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int codeTrimestre = Convert.ToInt32(dvgTrimestres.Rows[e.RowIndex].Cells["Code_Trimestre"].Value);

                if (e.ColumnIndex == dvgTrimestres.Columns["Modifier"].Index)
                {
                    // Ouvrir l'interface de modification
                    AjoutModificationTrimestreForm modifForm = new AjoutModificationTrimestreForm(codeTrimestre);
                    if (modifForm.ShowDialog() == DialogResult.OK)
                    {
                        LoadTrimestres(txtRecherche.Text);
                    }
                }
                else if (e.ColumnIndex == dvgTrimestres.Columns["Supprimer"].Index)
                {
                    // Vérifier si le trimestre est référencé dans la table Note
                    string checkQuery = $"SELECT COUNT(*) FROM Note WHERE SeanceExamenID = {codeTrimestre}";
                    string count = otulis.Selection(checkQuery);
                    if (Convert.ToInt32(count) > 0)
                    {
                        MessageBox.Show("Ce trimestre est référencé dans des notes et ne peut pas être supprimé.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Confirmer la suppression
                    if (MessageBox.Show("Voulez-vous vraiment supprimer ce trimestre ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        try
                        {
                            string query = $"DELETE FROM Trimestre WHERE Code_Trimestre = {codeTrimestre}";
                            otulis.RequtteMiseAjour(query);
                            LoadTrimestres(txtRecherche.Text);
                            MessageBox.Show("Trimestre supprimé avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Erreur lors de la suppression : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
        }

        private void txtTotalTrimestres_TextChanged(object sender, EventArgs e)
        {

        }
    }
}