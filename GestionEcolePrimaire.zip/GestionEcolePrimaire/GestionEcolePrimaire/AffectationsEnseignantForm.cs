﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestionEcolePrimaire;

namespace GestionEcolePrimaire
{
    public partial class AffectationsEnseignantForm : Form
    {
        private Otulis otulis = new Otulis();
        private int enseignantId;
        private DataTable niveauxTable;
        public AffectationsEnseignantForm(int enseignantId)
        {
            InitializeComponent();
            this.enseignantId = enseignantId;
            LoadComboBoxData();
            LoadAffectations();
            
        }
        private void LoadComboBoxData()
        {
            try
            {
                

                // Charger les niveaux
                string niveauQuery = "SELECT Code_Niveau, Libelle_Niveau FROM Niveaux";
                otulis.ChargementCBM(niveauQuery, cboNiveau);

                if (cboNiveau.Items.Count > 0)
                {
                    cboNiveau.SelectedIndex = 0;
                }

                // Charger le nom de l'enseignant
                string enseignantQuery = "SELECT Nom + ' ' + Prenom AS NomComplet FROM Enseignant WHERE Code_Utilisateur = " + enseignantId;
                txtEnseignant.Text = otulis.Selection(enseignantQuery);
                txtEnseignant.ReadOnly = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des données : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadClassesByNiveau(int codeNiveau)
        {
            try
            {
                string classeQuery = "SELECT Code_Classe, Libelle_Classe FROM Classe WHERE Code_Niveau = '" + codeNiveau + "';";
                otulis.ChargementCBM(classeQuery, cboClasse);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des classes : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadAffectations()
        {
            try
            {
                string query = "SELECT ac.Code_Enseignant, ac.Code_Classe, c.Libelle_Classe FROM Affectations_Classe ac, Classe c WHERE ac.Code_Classe = c.Code_Classe AND ac.Code_Enseignant = '" + enseignantId + "';";
                otulis.ChargementDVG(query, dataGridViewAffectations, txtCount);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des affectations : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void cboNiveau_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboNiveau.SelectedItem is element selectedNiveau)
            {
                int codeNiveau;
                if (int.TryParse(selectedNiveau.Identifiant, out codeNiveau))
                {
                    LoadClassesByNiveau(codeNiveau);
                }
            }
        }
        private void btnAjouter_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboClasse.SelectedValue == null)
                {
                    MessageBox.Show("Veuillez sélectionner une classe.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int classeId = Convert.ToInt32(cboClasse.SelectedValue);
                string checkQuery = "SELECT * FROM Affectations_Classe WHERE Code_Enseignant = '" + enseignantId + "' AND Code_Classe = '" + classeId + "';";
                if (otulis.RequttedeRecherche(checkQuery))
                {
                    MessageBox.Show("Cette affectation existe déjà.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string insertQuery = "INSERT INTO Affectations_Classe (Code_Enseignant, Code_Classe) VALUES ('" + enseignantId + "', '" + classeId + "');";
                otulis.RequtteMiseAjour(insertQuery);

                MessageBox.Show("Affectation ajoutée avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadAffectations();
                cboClasse.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout de l'affectation : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewAffectations.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Veuillez sélectionner une affectation à supprimer.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("Voulez-vous vraiment supprimer cette affectation ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int classeId = Convert.ToInt32(dataGridViewAffectations.SelectedRows[0].Cells["Code_Classe"].Value);
                    string deleteQuery = "DELETE FROM Affectations_Classe WHERE Code_Enseignant = '" + enseignantId + "' AND Code_Classe = '" + classeId + "';";
                    otulis.RequtteMiseAjour(deleteQuery);
                    MessageBox.Show("Affectation supprimée avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAffectations();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la suppression de l'affectation : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
        }

        private void AffectationsEnseignantForm_Load(object sender, EventArgs e)
        {

        }

        private void txtCount_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
