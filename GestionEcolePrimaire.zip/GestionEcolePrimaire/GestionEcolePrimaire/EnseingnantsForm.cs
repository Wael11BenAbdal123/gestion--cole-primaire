﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestionEcolePrimaire;

namespace GestionEcolePrimaire
{
    public partial class EnseingnantsForm : Form
    {
        private Otulis otulis = new Otulis();
        
        public EnseingnantsForm()
        {
            InitializeComponent();
            cboSexe.Items.Clear();
            cboSexe.Items.AddRange(new object[] { "M", "F" });

            cboStatut.Items.Clear();
            cboStatut.Items.AddRange(new object[] { "Actif", "Inactif" });


            LoadEnseignants();
            
           
        }
        private void LoadEnseignants()
        {
            try
            {
                string query = "SELECT e.Code_Utilisateur, e.Nom, e.Prenom, e.Sexe, e.Reside, e.Contact, e.Statut, u.Nom_Utilisateur, u.Role_Utilisateur, u.Email FROM Enseignant e, Utilisateur u WHERE e.Code_Utilisateur = u.Code_Utilisateur";
                otulis.ChargementDVG(query, dataGridViewEnseignants, txtCount);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des enseignants : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateInputs()
        {
            // Vérifier si le CodeUtilisateur est non vide et numérique
            if (string.IsNullOrEmpty(txtCodeUtilisateur.Text) || !int.TryParse(txtCodeUtilisateur.Text, out _))
            {
                MessageBox.Show("Le Code Utilisateur doit être un nombre valide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Vérifier si Nom et Prénom sont non vides
            if (string.IsNullOrEmpty(txtNom.Text) || string.IsNullOrEmpty(txtPrenom.Text))
            {
                MessageBox.Show("Le Nom et le Prénom sont obligatoires.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Vérifier si NomUtilisateur et Email sont non vides
            if (string.IsNullOrEmpty(txtNomUtilisateur.Text) || string.IsNullOrEmpty(txtEmail.Text))
            {
                MessageBox.Show("Le Nom d'Utilisateur et l'Email sont obligatoires.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Vérifier si l'Email contient un @
            if (!txtEmail.Text.Contains("@"))
            {
                MessageBox.Show("L'Email doit être valide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Vérifier si MotDePasse est non vide pour les nouveaux utilisateurs
            if (txtCodeUtilisateur.Enabled && string.IsNullOrEmpty(txtMotDePasse.Text))
            {
                MessageBox.Show("Le Mot de Passe est obligatoire pour un nouvel utilisateur.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Vérifier si Sexe est sélectionné
            if (cboSexe.SelectedItem == null)
            {
                MessageBox.Show("Veuillez sélectionner un sexe.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            // Vérifier si Statut est sélectionné
            if (cboStatut.SelectedItem == null)
            {
                MessageBox.Show("Veuillez sélectionner un statut.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInputs())
                {
                    MessageBox.Show("Veuillez remplir correctement tous les champs obligatoires.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Vérifier si le Code_Utilisateur existe déjà
                if (!int.TryParse(txtCodeUtilisateur.Text, out int codeUtilisateur))
                {
                    MessageBox.Show("Le Code Utilisateur doit être un nombre valide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string checkQuery = "SELECT Code_Utilisateur FROM Utilisateur WHERE Code_Utilisateur = " + codeUtilisateur;
                if (otulis.RequttedeRecherche(checkQuery))
                {
                    MessageBox.Show("Impossible d'ajouter l'enseignant : ce Code Utilisateur existe déjà.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                // Sécuriser les valeurs des ComboBox
                string sexe = cboSexe.SelectedItem?.ToString() ?? "M"; // Valeur par défaut si null (ne devrait pas arriver grâce à ValidateInputs)
                string statut = cboStatut.SelectedItem?.ToString() ?? "Actif"; // Valeur par défaut si null (ne devrait pas arriver grâce à ValidateInputs)

                // Insérer dans Utilisateur
                string queryUtilisateur = "INSERT INTO Utilisateur (Code_Utilisateur, Nom_Utilisateur, Mot_De_Passe_Hash, Role_Utilisateur, Email, Est_Actif) VALUES (" + codeUtilisateur + ", '" + txtNomUtilisateur.Text + "', '" + txtMotDePasse.Text + "', 'Enseignant', '" + txtEmail.Text + "', 1)";
                otulis.RequtteMiseAjour(queryUtilisateur);

                // Insérer dans Enseignant
                string queryEnseignant = "INSERT INTO Enseignant (Code_Utilisateur, Nom, Prenom, Sexe, Reside, Contact, Statut) VALUES (" + codeUtilisateur + ", '" + txtNom.Text + "', '" + txtPrenom.Text + "', '" + cboSexe.SelectedItem + "', '" + txtReside.Text + "', '" + txtContact.Text + "', '" + cboStatut.SelectedItem + "')";
                otulis.RequtteMiseAjour(queryEnseignant);

                MessageBox.Show("Enseignant ajouté avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadEnseignants();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'ajout de l'enseignant : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnModifier_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInputs())
                {
                    MessageBox.Show("Veuillez remplir correctement tous les champs obligatoires.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string queryUtilisateur = "UPDATE Utilisateur SET Nom_Utilisateur = '" + txtNomUtilisateur.Text + "', Role_Utilisateur = 'Enseignant', Email = '" + txtEmail.Text + "'";
                if (!string.IsNullOrWhiteSpace(txtMotDePasse.Text))
                    queryUtilisateur += $", Mot_De_Passe_Hash = '{txtMotDePasse.Text}'";
                queryUtilisateur += $" WHERE Code_Utilisateur = {txtCodeUtilisateur.Text}";
                otulis.RequtteMiseAjour(queryUtilisateur);

                string queryEnseignant = "UPDATE Enseignant SET Nom = '" + txtNom.Text + "', Prenom = '" + txtPrenom.Text + "', Sexe = '" + cboSexe.SelectedItem + "', Reside = '" + txtReside.Text + "', Contact = '" + txtContact.Text + "', Statut = '" + cboStatut.SelectedItem + "' WHERE Code_Utilisateur = " + txtCodeUtilisateur.Text;
                otulis.RequtteMiseAjour(queryEnseignant);

                MessageBox.Show("Enseignant modifié avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadEnseignants();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la modification de l'enseignant : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        private void btnSupprimer_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCodeUtilisateur.Text))
                {
                    MessageBox.Show("Veuillez sélectionner un enseignant à supprimer.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show("Voulez-vous vraiment supprimer cet enseignant ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string queryEnseignant = "DELETE FROM Enseignant WHERE Code_Utilisateur = " + txtCodeUtilisateur.Text;
                    otulis.RequtteMiseAjour(queryEnseignant);

                    string queryUtilisateur = "DELETE FROM Utilisateur WHERE Code_Utilisateur = " + txtCodeUtilisateur.Text;
                    otulis.RequtteMiseAjour(queryUtilisateur);

                    MessageBox.Show("Enseignant supprimé avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadEnseignants();
                    ClearFields();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la suppression de l'enseignant : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

            
        

        private void dataGridViewEnseignants_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewEnseignants.Rows[e.RowIndex];
                txtCodeUtilisateur.Text = row.Cells["Code_Utilisateur"].Value.ToString();
                txtCodeUtilisateur.Enabled = false; // Prevent editing ID
                txtNom.Text = row.Cells["Nom"].Value.ToString();
                txtPrenom.Text = row.Cells["Prenom"].Value.ToString();
                cboSexe.SelectedItem = row.Cells["Sexe"].Value.ToString();
                txtReside.Text = row.Cells["Reside"].Value.ToString();
                txtContact.Text = row.Cells["Contact"].Value.ToString();
                cboStatut.SelectedItem = row.Cells["Statut"].Value.ToString();
                txtNomUtilisateur.Text = row.Cells["Nom_Utilisateur"].Value.ToString();
                txtRole.Text= row.Cells["Role_Utilisateur"].Value.ToString();
                txtEmail.Text = row.Cells["Email"].Value.ToString();
                txtMotDePasse.Text = ""; // Password not retrieved

                int codeUtilisateur = Convert.ToInt32(row.Cells["Code_Utilisateur"].Value);

                try
                {
                    // Récupérer les matières enseignées par l'enseignant avec tous les champs de Matiere et le niveau
                    string queryMatieres = "SELECT DISTINCT m.Code_Matiere, m.Libelle_Matiere, m.Coefficient_Matiere, m.Code_Niveau, n.Libelle_Niveau FROM Responsabilites_Enseignant re, Matiere m, Niveaux n WHERE re.Code_Matiere = m.Code_Matiere AND m.Code_Niveau = n.Code_Niveau AND re.Code_Enseignant = '" + codeUtilisateur + "';";

                    DataTable matieresTable = otulis.GetDataTable(queryMatieres);

                    // Clear the DataGridView completely (including columns)
                    dataGridViewMatieres.DataSource = null;
                    dataGridViewMatieres.Columns.Clear();
                    dataGridViewMatieres.Rows.Clear();

                    if (matieresTable.Rows.Count == 0)
                    {
                        // Add a single column for the message
                        dataGridViewMatieres.Columns.Add("Message", "Message");
                        dataGridViewMatieres.Rows.Add("Aucune matière associée");
                    }
                    else
                    {
                        dataGridViewMatieres.DataSource = matieresTable;
                        // Renommer les colonnes pour plus de clarté
                        dataGridViewMatieres.Columns["Code_Matiere"].HeaderText = "Code Matière";
                        dataGridViewMatieres.Columns["Libelle_Matiere"].HeaderText = "Matière";
                        dataGridViewMatieres.Columns["Coefficient_Matiere"].HeaderText = "Coefficient";
                        dataGridViewMatieres.Columns["Code_Niveau"].HeaderText = "Code Niveau";
                        dataGridViewMatieres.Columns["Libelle_Niveau"].HeaderText = "Niveau";
                    }

                    // Récupérer les classes enseignées par l'enseignant avec tous les champs de Classe et le niveau
                    string queryClasses = "SELECT DISTINCT c.Code_Classe, c.Libelle_Classe, c.Capacite_Max_Eleve, c.Nb_Actuel_Eleve, c.Code_Niveau, n.Libelle_Niveau FROM Affectations_Classe ac, Classe c, Niveaux n WHERE ac.Code_Classe = c.Code_Classe AND c.Code_Niveau = n.Code_Niveau AND ac.Code_Enseignant = '" + codeUtilisateur + "';";

                    DataTable classesTable = otulis.GetDataTable(queryClasses);

                    // Clear the DataGridView completely (including columns)
                    dataGridViewClasses.DataSource = null;
                    dataGridViewClasses.Columns.Clear();
                    dataGridViewClasses.Rows.Clear();

                    if (classesTable.Rows.Count == 0)
                    {
                        // Add a single column for the message
                        dataGridViewClasses.Columns.Add("Message", "Message");
                        dataGridViewClasses.Rows.Add("Aucune classe associée");
                    }
                    else
                    {
                        dataGridViewClasses.DataSource = classesTable;
                        // Renommer les colonnes pour plus de clarté
                        dataGridViewClasses.Columns["Code_Classe"].HeaderText = "Code Classe";
                        dataGridViewClasses.Columns["Libelle_Classe"].HeaderText = "Classe";
                        dataGridViewClasses.Columns["Capacite_Max_Eleve"].HeaderText = "Capacité Max";
                        dataGridViewClasses.Columns["Nb_Actuel_Eleve"].HeaderText = "Élèves Actuels";
                        dataGridViewClasses.Columns["Code_Niveau"].HeaderText = "Code Niveau";
                        dataGridViewClasses.Columns["Libelle_Niveau"].HeaderText = "Niveau";
                    }

                    // Forcer un rafraîchissement
                    dataGridViewMatieres.Refresh();
                    dataGridViewClasses.Refresh();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erreur lors de la récupération des matières ou classes : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnAffectations_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodeUtilisateur.Text))
            {
                MessageBox.Show("Veuillez sélectionner un enseignant.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            new AffectationsEnseignantForm(int.Parse(txtCodeUtilisateur.Text)).ShowDialog();
        }

        private void ClearFields()
        {
            txtCodeUtilisateur.Clear();
            txtCodeUtilisateur.Enabled = true;
            txtNom.Clear();
            txtPrenom.Clear();
            cboSexe.SelectedIndex = -1;
            cboStatut.SelectedIndex = -1;
            txtReside.Clear();
            txtContact.Clear();
            cboStatut.SelectedIndex = -1;
            txtNomUtilisateur.Clear();
            txtRole.Text = "Enseignant"; // Toujours "Enseignant"
            txtEmail.Clear();
            txtMotDePasse.Clear();
            txtRechercher.Clear();
            dataGridViewMatieres.DataSource = null;
            dataGridViewMatieres.Rows.Clear();
            dataGridViewMatieres.Columns.Clear();
            dataGridViewClasses.DataSource = null;
            dataGridViewClasses.Rows.Clear();
            dataGridViewClasses.Columns.Clear();
        }

        private void txtRechercher_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT e.Code_Utilisateur, e.Nom, e.Prenom, e.Sexe, e.Reside, e.Contact, e.Statut, u.Nom_Utilisateur, u.Role_Utilisateur, u.Email " +
               "FROM Enseignant e, Utilisateur u " +
               "WHERE e.Code_Utilisateur = u.Code_Utilisateur " +
               "AND (e.Nom LIKE '%" + txtRechercher.Text + "%' OR e.Prenom LIKE '%" + txtRechercher.Text + "%')";
                otulis.ChargementDVG(query, dataGridViewEnseignants, txtCount);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la recherche : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnReinitialiser_Click_1(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void dataGridViewEnseignants_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void EnseingnantsForm_Load(object sender, EventArgs e)
        {

        }
    }
}
