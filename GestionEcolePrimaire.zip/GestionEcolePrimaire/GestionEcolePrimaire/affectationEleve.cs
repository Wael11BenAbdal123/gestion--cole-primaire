﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GestionEcolePrimaire;

namespace GestionEcolePrimaire
{
    public partial class affectationEleve : Form
    {
        private Outils otulis = new Outils();
        private DataTable elevesEnAttente = new DataTable();
        private DataTable elevesAffectes = new DataTable();
        private int capaciteMaxClasse;
        public affectationEleve()
        {
            InitializeComponent();
            panel.Dock = DockStyle.Fill;
            ConfigurerColonnesDgv();

            btnChargerDonnees.Enabled = true;
            btnAffecter.Enabled = true;
            btnRetirer.Enabled = true;
            btnEnregistrer.Enabled = true;
            btnAnnuler.Enabled = true;
            btnChargerDonnees.Click += btnChargerDonnees_Click;
            btnAffecter.Click += btnAffecter_Click;
            btnRetirer.Click += btnRetirer_Click;
            btnEnregistrer.Click += btnEnregistrer_Click;
            btnAnnuler.Click += btnAnnuler_Click;


        }
        private void affectationEleve_Resize(object sender, EventArgs e)
        {
            panel.Size = this.ClientSize;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // Charger les niveaux dans 
                otulis.ChargementCBM("SELECT Code_Niveau, Libelle_Niveau FROM Niveaux", cmbNiveau);
                if (cmbNiveau.Items.Count > 0)
                {
                    cmbNiveau.SelectedIndex = 0; // Sélectionner le premier niveau par défaut
                }

                // Charger les années scolaires
                otulis.ChargementCBM("SELECT Code_Annee, Libelle_Annee FROM AnneeScolaire", cmbAnneeScolaire);
                if (cmbAnneeScolaire.Items.Count > 0)
                {
                    // Rechercher l'index correspondant à Code_Annee = 2024
                    bool found = false;
                    for (int i = 0; i < cmbAnneeScolaire.Items.Count; i++)
                    {
                        Outils.element item = cmbAnneeScolaire.Items[i] as Outils.element;
                        if (item != null && int.TryParse(item.Identifiant, out int codeAnnee) && codeAnnee == 2024)
                        {
                            cmbAnneeScolaire.SelectedIndex = i;
                            found = true;
                            break;
                        }
                    }

                    // Si 2024 n'est pas trouvé, sélectionner la première année
                    if (!found)
                    {
                        cmbAnneeScolaire.SelectedIndex = 0;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement initial : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void panel_Paint(object sender, PaintEventArgs e)
        {

        }
        private void ConfigurerColonnesDgv()
        {
            dgvElevesEnAttente.AutoGenerateColumns = false;
            dgvElevesEnAttente.Columns.Clear();
            dgvElevesEnAttente.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Num_Ins_Eleve", HeaderText = "N° Insc" });
            dgvElevesEnAttente.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Nom_Eleve", HeaderText = "Nom" });
            dgvElevesEnAttente.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Prenom_Eleve", HeaderText = "Prénom" });
            dgvElevesEnAttente.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Sexe_Eleve", HeaderText = "Sexe" });

            dgvElevesAffectes.AutoGenerateColumns = false;
            dgvElevesAffectes.Columns.Clear();
            dgvElevesAffectes.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Num_Ins_Eleve", HeaderText = "N° Insc" });
            dgvElevesAffectes.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Nom_Eleve", HeaderText = "Nom" });
            dgvElevesAffectes.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Prenom_Eleve", HeaderText = "Prénom" });
            dgvElevesAffectes.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Sexe_Eleve", HeaderText = "Sexe" });
        }

        private void cmbNiveau_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (cmbNiveau.SelectedValue == null || !int.TryParse(cmbNiveau.SelectedValue.ToString(), out int niveauId))
                {
                    cmbClasse.DataSource = null;
                    cmbClasse.Items.Clear();
                    return;
                }

                string query = $"SELECT Code_Classe, Libelle_Classe FROM Classe WHERE Code_Niveau = {niveauId}";
                otulis.ChargementCBM(query, cmbClasse);

                if (cmbClasse.Items.Count > 0)
                {
                    cmbClasse.SelectedIndex = 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur dans cmbNiveau_SelectedIndexChanged : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnChargerDonnees_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbNiveau.SelectedValue == null || cmbAnneeScolaire.SelectedValue == null || cmbClasse.SelectedValue == null)
                {
                    MessageBox.Show("Veuillez sélectionner un niveau, une année scolaire et une classe.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int niveauId = int.Parse(cmbNiveau.SelectedValue.ToString());
                int anneeId = int.Parse(cmbAnneeScolaire.SelectedValue.ToString());
                int classeId = int.Parse(cmbClasse.SelectedValue.ToString());

                // S'assurer que les colonnes sont configurées
                ConfigurerColonnesDgv();

                // Charger les élèves en attente
                string sqlEnAttente = @"
                    SELECT e.Num_Ins_Eleve, e.Nom_Eleve, e.Prenom_Eleve, e.Sexe_Eleve
                    FROM Eleve e
                    INNER JOIN Inscription i ON e.Num_Ins_Eleve = i.EleveID
                    WHERE i.NiveauID = " + niveauId + " AND i.AnneeID = " + anneeId + " AND i.ClasseID IS NULL";
                elevesEnAttente = otulis.GetDataTable(sqlEnAttente);
                dgvElevesEnAttente.DataSource = elevesEnAttente;

                // Charger les élèves affectés
                string sqlAffectes = @"
                    SELECT e.Num_Ins_Eleve, e.Nom_Eleve, e.Prenom_Eleve, e.Sexe_Eleve
                    FROM Eleve e
                    INNER JOIN Inscription i ON e.Num_Ins_Eleve = i.EleveID
                    WHERE i.NiveauID = " + niveauId + " AND i.AnneeID = " + anneeId + " AND i.ClasseID = " + classeId;
                elevesAffectes = otulis.GetDataTable(sqlAffectes);
                dgvElevesAffectes.DataSource = elevesAffectes;

                // Recalculer Nb Actuel Eleve à partir de la table Inscription
                string sqlUpdateNbActuel = "UPDATE Classe SET Nb_Actuel_Eleve = (SELECT COUNT(*) FROM Inscription WHERE ClasseID = " + classeId + " AND NiveauID = " + niveauId + " AND AnneeID = " + anneeId + ") WHERE Code_Classe = " + classeId;
                otulis.RequtteMiseAjour(sqlUpdateNbActuel);

                // Mettre à jour le label avec le nombre d'élèves affectés
                string sqlClasse = "SELECT Capacite_Max_Eleve, Nb_Actuel_Eleve FROM Classe WHERE Code_Classe = " + classeId;
                DataTable classeData = otulis.GetDataTable(sqlClasse);
                if (classeData.Rows.Count > 0)
                {
                    capaciteMaxClasse = int.Parse(classeData.Rows[0]["Capacite_Max_Eleve"].ToString());
                    int nbActuel = int.Parse(classeData.Rows[0]["Nb_Actuel_Eleve"].ToString());
                    lblElevesAffectes.Text = $"Élèves affectés : {nbActuel} / {capaciteMaxClasse}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du chargement des données : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAffecter_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvElevesEnAttente.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Veuillez sélectionner au moins un élève à affecter.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int classeId = int.Parse(cmbClasse.SelectedValue.ToString());
                int nbActuel = elevesAffectes.Rows.Count;

                if (nbActuel + dgvElevesEnAttente.SelectedRows.Count > capaciteMaxClasse)
                {
                    MessageBox.Show("La capacité maximale de la classe serait dépassée.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                foreach (DataGridViewRow row in dgvElevesEnAttente.SelectedRows)
                {
                    if (row.DataBoundItem == null)
                    {
                        MessageBox.Show("Aucune donnée associée à la ligne sélectionnée.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        continue;
                    }

                    DataRow eleveRow = ((DataRowView)row.DataBoundItem).Row;
                    elevesAffectes.ImportRow(eleveRow);
                    elevesEnAttente.Rows.Remove(eleveRow);
                }

                lblElevesAffectes.Text = $"Élèves affectés : {elevesAffectes.Rows.Count} / {capaciteMaxClasse}";
                dgvElevesEnAttente.Refresh();
                dgvElevesAffectes.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'affectation : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRetirer_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvElevesAffectes.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Veuillez sélectionner au moins un élève à retirer.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                foreach (DataGridViewRow row in dgvElevesAffectes.SelectedRows)
                {
                    if (row.DataBoundItem == null)
                    {
                        MessageBox.Show("Aucune donnée associée à la ligne sélectionnée.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        continue;
                    }

                    DataRow eleveRow = ((DataRowView)row.DataBoundItem).Row;
                    elevesEnAttente.ImportRow(eleveRow);
                    elevesAffectes.Rows.Remove(eleveRow);
                }

                lblElevesAffectes.Text = $"Élèves affectés : {elevesAffectes.Rows.Count} / {capaciteMaxClasse}";
                dgvElevesEnAttente.Refresh();
                dgvElevesAffectes.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors du retrait : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            try
            {
                int niveauId = int.Parse(cmbNiveau.SelectedValue.ToString());
                int anneeId = int.Parse(cmbAnneeScolaire.SelectedValue.ToString());
                int classeId = int.Parse(cmbClasse.SelectedValue.ToString());

                if (elevesAffectes.Rows.Count > 0)
                {
                    string eleveIds = string.Join(",", elevesAffectes.Rows.Cast<DataRow>().Select(r => r["Num_Ins_Eleve"].ToString()));
                    otulis.RequtteMiseAjour($@"
                        UPDATE Inscription 
                        SET ClasseID = {classeId}, Statut = 'Affecté' 
                        WHERE EleveID IN ({eleveIds}) AND NiveauID = {niveauId} AND AnneeID = {anneeId}");
                }

                if (elevesEnAttente.Rows.Count > 0)
                {
                    string eleveIdsEnAttente = string.Join(",", elevesEnAttente.Rows.Cast<DataRow>().Select(r => r["Num_Ins_Eleve"].ToString()));
                    otulis.RequtteMiseAjour($@"
                        UPDATE Inscription 
                        SET ClasseID = NULL, Statut = 'En attente' 
                        WHERE EleveID IN ({eleveIdsEnAttente}) AND NiveauID = {niveauId} AND AnneeID = {anneeId}");
                }

                // Recalculer Nb_Actuel_Eleve pour la classe
                otulis.RequtteMiseAjour($@"
                    UPDATE Classe 
                    SET Nb_Actuel_Eleve = (SELECT COUNT(*) FROM Inscription WHERE ClasseID = {classeId} AND NiveauID = {niveauId} AND AnneeID = {anneeId})
                    WHERE Code_Classe = {classeId}");

                MessageBox.Show("Affectations enregistrées avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'enregistrement : " + ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvElevesAffectes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }

}
