﻿namespace GestionEcolePrimaire
{
    partial class GestionInscription
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GestionInscription));
            this.label1 = new System.Windows.Forms.Label();
            this.cmbAnneeScolaire = new System.Windows.Forms.ComboBox();
            this.btnNouvelleInscription = new System.Windows.Forms.Button();
            this.dgvInscriptions = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbNiveau = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInscriptions)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Année scolaire :";
            // 
            // cmbAnneeScolaire
            // 
            this.cmbAnneeScolaire.FormattingEnabled = true;
            this.cmbAnneeScolaire.Location = new System.Drawing.Point(210, 50);
            this.cmbAnneeScolaire.Name = "cmbAnneeScolaire";
            this.cmbAnneeScolaire.Size = new System.Drawing.Size(217, 24);
            this.cmbAnneeScolaire.TabIndex = 1;
            this.cmbAnneeScolaire.SelectedIndexChanged += new System.EventHandler(this.cmbAnneeScolaire_SelectedIndexChanged);
            // 
            // btnNouvelleInscription
            // 
            this.btnNouvelleInscription.Location = new System.Drawing.Point(864, 50);
            this.btnNouvelleInscription.Name = "btnNouvelleInscription";
            this.btnNouvelleInscription.Size = new System.Drawing.Size(153, 30);
            this.btnNouvelleInscription.TabIndex = 2;
            this.btnNouvelleInscription.Text = "Nouvelle inscription";
            this.btnNouvelleInscription.UseVisualStyleBackColor = true;
            this.btnNouvelleInscription.Click += new System.EventHandler(this.btnNouvelleInscription_Click);
            // 
            // dgvInscriptions
            // 
            this.dgvInscriptions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInscriptions.Location = new System.Drawing.Point(12, 96);
            this.dgvInscriptions.Name = "dgvInscriptions";
            this.dgvInscriptions.RowHeadersWidth = 51;
            this.dgvInscriptions.RowTemplate.Height = 24;
            this.dgvInscriptions.Size = new System.Drawing.Size(1005, 275);
            this.dgvInscriptions.TabIndex = 3;
            this.dgvInscriptions.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvInscriptions_CellClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 405);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Totale :";
            // 
            // txtNombre
            // 
            this.txtNombre.Enabled = false;
            this.txtNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.ForeColor = System.Drawing.Color.Red;
            this.txtNombre.Location = new System.Drawing.Point(104, 404);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(120, 28);
            this.txtNombre.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(463, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Niveau :";
            // 
            // cmbNiveau
            // 
            this.cmbNiveau.FormattingEnabled = true;
            this.cmbNiveau.Location = new System.Drawing.Point(559, 53);
            this.cmbNiveau.Name = "cmbNiveau";
            this.cmbNiveau.Size = new System.Drawing.Size(217, 24);
            this.cmbNiveau.TabIndex = 7;
            this.cmbNiveau.SelectedIndexChanged += new System.EventHandler(this.cmbNiveau_SelectedIndexChanged);
            // 
            // GestionInscription
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 450);
            this.Controls.Add(this.cmbNiveau);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvInscriptions);
            this.Controls.Add(this.btnNouvelleInscription);
            this.Controls.Add(this.cmbAnneeScolaire);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GestionInscription";
            this.Text = "Tableau de bord - Gestion des inscriptions";
            this.Load += new System.EventHandler(this.GestionInscription_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInscriptions)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbAnneeScolaire;
        private System.Windows.Forms.Button btnNouvelleInscription;
        private System.Windows.Forms.DataGridView dgvInscriptions;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbNiveau;
    }
}