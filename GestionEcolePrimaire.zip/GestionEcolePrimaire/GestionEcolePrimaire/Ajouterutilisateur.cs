﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class Ajouterutilisateur : Form
    {
        public Ajouterutilisateur()
        {
            InitializeComponent();
            txtCode.ReadOnly = true;
            ChargerRoles();
            ChargerProchainCode();
            btnAjouter.Click += new EventHandler(btnAjouter_Click);
            btnAnnuler.Click += new EventHandler(btnAnnuler_Click);
        }
        Outils o = new Outils();
      
        private void Ajouterutilisateur_Load(object sender, EventArgs e)
        {

        }
        private void ChargerProchainCode()
        {
            try
            {
               
                string query = "SELECT ISNULL(MAX(Code_Utilisateur), 0) + 1 FROM Utilisateur";
                string prochainCode = o.Selection(query);
                txtCode.Text = prochainCode ?? "1"; 
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la récupération du prochain code : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtCode.Text = "1"; // Valeur par défaut en cas d'erreur
            }
        }
        private void ChargerRoles()
        {
            try
            {
                // Récupérer les rôles distincts depuis la base de données
                string query = "SELECT DISTINCT Role_Utilisateur FROM Utilisateur WHERE Role_Utilisateur IS NOT NULL";
                DataTable rolesTable = o.GetDataTable(query);

                txtRole.DataSource = rolesTable;
                txtRole.DisplayMember = "Role_Utilisateur";
                txtRole.ValueMember = "Role_Utilisateur";

                if (txtRole.Items.Count > 0)
                {
                    txtRole.SelectedIndex = 0;
                }
                else
                {
                    MessageBox.Show("Aucun rôle trouvé dans la base de données. Veuillez ajouter des utilisateurs avec des rôles d'abord.", "Avertissement", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des rôles : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAjouter_Click(object sender, EventArgs e)
        {
            try
            {
                // Valider les champs
                if (string.IsNullOrWhiteSpace(txtNom.Text))
                {
                    MessageBox.Show("Le champ Nom Utilisateur est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (txtRole.SelectedValue == null)
                {
                    MessageBox.Show("Veuillez sélectionner un rôle.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    MessageBox.Show("Le champ Email est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtMotDePasse.Text))
                {
                    MessageBox.Show("Le champ Mot de Passe est requis.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Échapper les apostrophes dans les valeurs pour éviter les erreurs SQL
                string nomUtilisateur = txtNom.Text.Replace("'", "''");
                string roleUtilisateur = txtRole.SelectedValue.ToString().Replace("'", "''");
                string email = txtEmail.Text.Replace("'", "''");
                string motDePasse = txtMotDePasse.Text.Replace("'", "''");

                // Construire la requête SQL pour l'insertion
                string query = "INSERT INTO Utilisateur (Nom_Utilisateur, Mot_De_Passe_Hash, Role_Utilisateur, Email, Date_Creation) " +
                              "VALUES ('" + nomUtilisateur + "', '" + motDePasse + "', '" + roleUtilisateur + "', '" + email + "', GETDATE())";

              
                o.RequtteMiseAjour(query);

                MessageBox.Show("Utilisateur ajouté avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de l'ajout de l'utilisateur : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}

