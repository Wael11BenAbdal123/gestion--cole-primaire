﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    internal class GestionInscri
    {
        Otulis o =new Otulis();
        public DataTable RechercherEleve(string numInscription, string nom)
        {
            DataTable result = new DataTable();
            try
            {
                string sql =
    "SELECT " +
    "e.Num_Ins_Eleve, e.Nom_Eleve, e.Prenom_Eleve, e.Sexe_Eleve, " +
    "e.Date_Nais_Eleve, e.Lieu_Nais_Eleve, " +
    "p.Code_Par, p.Nom_Parent, p.Prenom_Parent, p.Profession_Parent, " +
    "p.Email_Parent, p.Telephone_Parent, p.Telephone_Secondaire, " +
    "p.Adresse_Parent, p.Ville_Parent, p.Code_Postal, p.Est_Tuteur_Principal, " +
    "t.Lien_Parente " +
    "FROM Eleve e, Tuteurs t, Parent p " +
    "WHERE e.Num_Ins_Eleve = t.Num_Ins_Eleve " +
    "AND t.Code_Par = p.Code_Par " +
    "AND 1=1";

                if (!string.IsNullOrEmpty(numInscription))
                    sql = sql + " AND e.Num_Ins_Eleve = '" + numInscription + "'";
                if (!string.IsNullOrEmpty(nom))
                    sql = sql + " AND e.Nom_Eleve LIKE '%" + nom + "%'";

                result = o.GetDataTable(sql);
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de la recherche de l'élève : " + ex.Message);
            }

            return result;
        }
        public void EnregistrerInscription(string nomEleve, string prenomEleve, string sexe, string dateNaissance,
                                  string lieuNaissance, int numInscription, DataTable parents,
                                  int niveauId, int anneeId)
        {
            try
            {             
                DateTime parsedDate = DateTime.Parse(dateNaissance); 
                if (!o.RequttedeRecherche("select * from Eleve where Num_Ins_Eleve= " + numInscription.ToString()))
                {
                    string sqlEleve = "INSERT INTO Eleve (Num_Ins_Eleve, Nom_Eleve, Prenom_Eleve, Sexe_Eleve, Date_Nais_Eleve, Lieu_Nais_Eleve) " +
                            "VALUES ('" + numInscription + "', '" + nomEleve + "', '" + prenomEleve + "', '" + sexe + "', '" + parsedDate.ToString("yyyy-MM-dd") + "', '" + lieuNaissance + "')";

                    o.RequtteMiseAjour(sqlEleve);
                }
                if (o.RequttedeRecherche("SELECT * FROM Inscription WHERE EleveID = " + numInscription +
             " AND AnneeID = " + anneeId +
             " AND NiveauID = " + niveauId+";"))
                {
                    MessageBox.Show("L'élève " + nomEleve + " " + prenomEleve + " est déjà inscrit pour l'année " + anneeId + " au niveau " + niveauId + ".",
                                   "Inscription existante", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                if (o.RequttedeRecherche("SELECT * FROM Inscription WHERE EleveID = " + numInscription +
             " AND AnneeID = " + anneeId +
             " AND NiveauID != " + niveauId+";"))
                {
                    MessageBox.Show("L'élève " + nomEleve + " " + prenomEleve + " est déjà inscrit dans un autre niveau pour l'année " + anneeId + ".",
                                   "Conflit de niveau", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                string sqlInscription = "INSERT INTO Inscription (EleveID, NiveauID, AnneeID, Statut) " +
                        "VALUES ('" + numInscription + "', '" + niveauId + "', '" + anneeId + "', 'En attente')";
                o.RequtteMiseAjour(sqlInscription);
                foreach (DataRow row in parents.Rows)
                {
                    if (!o.RequttedeRecherche("select * from Parent where Code_Par= " + row["Code_Par"].ToString()))
                    {
                        string sqlParent = "INSERT INTO Parent (Code_Par, Nom_Parent, Prenom_Parent, Profession_Parent, Email_Parent, Telephone_Parent, Telephone_Secondaire, Adresse_Parent, Ville_Parent, Code_Postal, Est_Tuteur_Principal) " +
                                           "VALUES ('" + row["Code_Par"] + "', '" + row["Nom_Parent"] + "', '" + row["Prenom_Parent"] + "', '" + row["Profession_Parent"] + "', '" + row["Email_Parent"] + "', '" + row["Telephone_Parent"] + "', '" + row["Telephone_Secondaire"] + "', '" + row["Adresse_Parent"] + "', '" + row["Ville_Parent"] + "', '" + row["Code_Postal"] + "', '" + Convert.ToBoolean(row["Est_Tuteur_Principal"]) + "')";
                        o.RequtteMiseAjour(sqlParent);
                    }
                    if (!o.RequttedeRecherche("select * from Tuteurs where Code_Par= " + row["Code_Par"].ToString()+ "and Num_Ins_Eleve= " + numInscription.ToString()))
                    {
                        string sqlTuteur = "INSERT INTO Tuteurs (Code_Par, Num_Ins_Eleve, Lien_Parente) " +
                   "VALUES ('" + row["Code_Par"] + "', '" + numInscription + "', '" + row["Lien_Parente"] + "')";
                        o.RequtteMiseAjour(sqlTuteur);

                    }        
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de l'enregistrement de l'inscription : " + ex.Message);
            }
        }
        public void ModifierInscription(string nomEleve, string prenomEleve, string sexe, string dateNaissance,
                                            string lieuNaissance, int numInscription, DataTable parents,
                                            int niveauId, int anneeId, string statut, string classeId)
        {
            try
            {
                DateTime parsedDate = DateTime.Parse(dateNaissance);
                string sqlEleve = "UPDATE Eleve " +
                  "SET Nom_Eleve = '" + nomEleve + "', " +
                  "Prenom_Eleve = '" + prenomEleve + "', " +
                  "Sexe_Eleve = '" + sexe + "', " +
                  "Date_Nais_Eleve = '" + parsedDate.ToString("yyyy-MM-dd") + "', " +
                  "Lieu_Nais_Eleve = '" + lieuNaissance + "' " +
                  "WHERE Num_Ins_Eleve = " + numInscription;
                o.RequtteMiseAjour(sqlEleve);
                if (o.RequttedeRecherche("SELECT * FROM Inscription WHERE EleveID = " + numInscription +" AND AnneeID = " + anneeId+";"))
                {
                    string sqlInscription = "UPDATE Inscription " +
                        "SET NiveauID = " + niveauId + ", " +
                        "Statut = '" + statut + "', " +
                        "ClasseID = " + (classeId != null ? "" + classeId + "" : "NULL") + " " +
                        "WHERE EleveID = " + numInscription + " AND AnneeID = " + anneeId;

                    o.RequtteMiseAjour(sqlInscription);
                }
                else
                {
                    string sqlInscription = "INSERT INTO Inscription (EleveID, NiveauID, AnneeID, Statut, ClasseID) " +
                          "VALUES ('" + numInscription + "', '" + niveauId + "', '" + anneeId + "', '" + statut + "', " +
                          (classeId != null ? "'" + classeId + "'" : "NULL") + ")";

                    o.RequtteMiseAjour(sqlInscription);
                }
                string sqlDeleteTuteurs = "DELETE FROM Tuteurs WHERE Num_Ins_Eleve = " + numInscription;

                o.RequtteMiseAjour(sqlDeleteTuteurs);
                foreach (DataRow row in parents.Rows)
                {
                    string codeParValue = row["Code_Par"].ToString();
                    int codePar;

                    if (string.IsNullOrEmpty(codeParValue))
                    {
                        string sqlParent = "INSERT INTO Parent (Nom_Parent, Prenom_Parent, Profession_Parent, Email_Parent, Telephone_Parent, " +
                   "Telephone_Secondaire, Adresse_Parent, Ville_Parent, Code_Postal, Est_Tuteur_Principal) " +
                   "VALUES ('" + row["Nom_Parent"] + "', '" + row["Prenom_Parent"] + "', '" + row["Profession_Parent"] + "', " +
                   "'" + row["Email_Parent"] + "', '" + row["Telephone_Parent"] + "', '" + row["Telephone_Secondaire"] + "', " +
                   "'" + row["Adresse_Parent"] + "', '" + row["Ville_Parent"] + "', '" + row["Code_Postal"] + "', " +
                   "'" + Convert.ToBoolean(row["Est_Tuteur_Principal"]) + "')";

                        o.RequtteMiseAjour(sqlParent);
                        codePar = int.Parse(o.RequttedeRecherche("SELECT MAX(Code_Par) FROM Parent") ?
                                           o.RequttedeRecherche("SELECT MAX(Code_Par) FROM Parent").ToString() : "0");
                    }
                    else
                    {
                        codePar = int.Parse(codeParValue);
                        if (o.RequttedeRecherche("SELECT * FROM Parent WHERE Code_Par = " + codePar))
                        {
                            string sqlParent = "UPDATE Parent " +
                   "SET Nom_Parent = '" + row["Nom_Parent"] + "', " +
                   "Prenom_Parent = '" + row["Prenom_Parent"] + "', " +
                   "Profession_Parent = '" + row["Profession_Parent"] + "', " +
                   "Email_Parent = '" + row["Email_Parent"] + "', " +
                   "Telephone_Parent = '" + row["Telephone_Parent"] + "', " +
                   "Telephone_Secondaire = '" + row["Telephone_Secondaire"] + "', " +
                   "Adresse_Parent = '" + row["Adresse_Parent"] + "', " +
                   "Ville_Parent = '" + row["Ville_Parent"] + "', " +
                   "Code_Postal = '" + row["Code_Postal"] + "', " +
                   "Est_Tuteur_Principal = '" + Convert.ToBoolean(row["Est_Tuteur_Principal"]) + "' " +
                   "WHERE Code_Par = " + codePar;

                            o.RequtteMiseAjour(sqlParent);
                        }
                        else
                        {
                            string sqlParent = "INSERT INTO Parent (Code_Par, Nom_Parent, Prenom_Parent, Profession_Parent, Email_Parent, " +
                   "Telephone_Parent, Telephone_Secondaire, Adresse_Parent, Ville_Parent, Code_Postal, Est_Tuteur_Principal) " +
                   "VALUES ('" + codePar + "', '" + row["Nom_Parent"] + "', '" + row["Prenom_Parent"] + "', '" + row["Profession_Parent"] + "', " +
                   "'" + row["Email_Parent"] + "', '" + row["Telephone_Parent"] + "', '" + row["Telephone_Secondaire"] + "', " +
                   "'" + row["Adresse_Parent"] + "', '" + row["Ville_Parent"] + "', '" + row["Code_Postal"] + "', " +
                   "'" + Convert.ToBoolean(row["Est_Tuteur_Principal"]) + "')";

                            o.RequtteMiseAjour(sqlParent);
                        }
                    }
                    string sqlTuteur = "INSERT INTO Tuteurs (Code_Par, Num_Ins_Eleve, Lien_Parente) " +
                   "VALUES ('" + codePar + "', '" + numInscription + "', '" + row["Lien_Parente"] + "')";

                    o.RequtteMiseAjour(sqlTuteur);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Erreur lors de la modification de l'inscription : " + ex.Message);
            }
        }
    }
}
