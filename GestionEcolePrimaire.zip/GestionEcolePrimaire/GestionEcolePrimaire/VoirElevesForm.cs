﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class VoirElevesForm : Form
    {
        private Otulis otulis;
        private int selectedClassCode;

        public VoirElevesForm(int codeClasse)
        {
            InitializeComponent();
            otulis = new Otulis();
            selectedClassCode = codeClasse;
            this.Text = $"Liste des Élèves - Classe {selectedClassCode}";
            LoadAcademicYears();
        }

        private void LoadAcademicYears()
        {
            try
            {
                string query = "SELECT Code_Annee, Libelle_Annee FROM AnneeScolaire ORDER BY Code_Annee DESC";
                DataTable dt = otulis.GetDataTable(query);
                cbAnneeScolaire.DataSource = dt;
                cbAnneeScolaire.DisplayMember = "Libelle_Annee";
                cbAnneeScolaire.ValueMember = "Code_Annee";
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Aucune année scolaire trouvée dans la table AnneeScolaire. Veuillez ajouter une année scolaire.",
                                    "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    cbAnneeScolaire.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des années scolaires : {ex.Message}\nStack Trace: {ex.StackTrace}",
                                "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadStudents()
        {
            if (cbAnneeScolaire.SelectedValue == null)
            {
                MessageBox.Show("Veuillez sélectionner une année scolaire.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int selectedAnnee;
            try
            {
                selectedAnnee = Convert.ToInt32(cbAnneeScolaire.SelectedValue);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur de conversion : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            MessageBox.Show($"Chargement des élèves pour la classe avec Code_Classe = {selectedClassCode} et Année = {selectedAnnee}",
                            "Debug", MessageBoxButtons.OK, MessageBoxIcon.Information);

            string queryStudents =
                "SELECT " +
                "e.Num_Ins_Eleve AS Num_Inscription, " +
                "e.Nom_Eleve AS Nom, " +
                "e.Prenom_Eleve AS Prenom, " +
                "e.Sexe_Eleve AS Sexe, " +
                "e.Date_Nais_Eleve AS Date_Naissance, " +
                "e.Lieu_Nais_Eleve AS Lieu_Naissance " +
                "FROM Eleve e, Inscription i " +
                "WHERE e.Num_Ins_Eleve = i.EleveID " +
                "AND i.ClasseID = " + selectedClassCode + " " +
                "AND i.AnneeID = " + selectedAnnee + " " +
                "AND i.Statut = 'Affecté'";

            otulis.ChargementDVG(queryStudents, dataGridViewEleves, null);

            if (dataGridViewEleves.Rows.Count == 1)
            {
                MessageBox.Show("Aucun élève trouvé pour cette classe et cette année scolaire. Vérifiez les données dans les tables Eleve et Inscription.\n" +
                                "Assurez-vous que :\n" +
                                "- Des élèves sont inscrits (table Eleve).\n" +
                                "- Les inscriptions existent dans la table Inscription avec Statut = 'Affecté'.\n" +
                                "- Les inscriptions correspondent à l'année scolaire sélectionnée (AnneeID = " + selectedAnnee + ") et à la classe sélectionnée (ClasseID = " + selectedClassCode + ").",
                                "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            if (dataGridViewEleves.Columns["Num_Inscription"] != null)
                dataGridViewEleves.Columns["Num_Inscription"].HeaderText = "Numéro Inscription";
            if (dataGridViewEleves.Columns["Nom"] != null)
                dataGridViewEleves.Columns["Nom"].HeaderText = "Nom Élève";
            if (dataGridViewEleves.Columns["Prenom"] != null)
                dataGridViewEleves.Columns["Prenom"].HeaderText = "Prénom Élève";
            if (dataGridViewEleves.Columns["Sexe"] != null)
                dataGridViewEleves.Columns["Sexe"].HeaderText = "Sexe";
            if (dataGridViewEleves.Columns["Date_Naissance"] != null)
                dataGridViewEleves.Columns["Date_Naissance"].HeaderText = "Date Naissance";
            if (dataGridViewEleves.Columns["Lieu_Naissance"] != null)
                dataGridViewEleves.Columns["Lieu_Naissance"].HeaderText = "Lieu Naissance";
        }

        private void cbAnneeScolaire_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbAnneeScolaire.SelectedValue != null)
            {
                LoadStudents();
            }
        }

        private void VoirElevesForm_Load(object sender, EventArgs e)
        {
            LoadStudents();
        }
    }
}