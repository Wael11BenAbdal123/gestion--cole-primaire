﻿namespace GestionEcolePrimaire
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

       

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewNiveaux = new System.Windows.Forms.DataGridView();
            this.txtCodeNiveau = new System.Windows.Forms.TextBox();
            this.txtLibelle = new System.Windows.Forms.TextBox();
            this.txtHoraire = new System.Windows.Forms.TextBox();
            this.txtRechercher = new System.Windows.Forms.TextBox();
            this.txtCount = new System.Windows.Forms.TextBox();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.btnModifier = new System.Windows.Forms.Button();
            this.btnSupprimer = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnReinitialiser = new System.Windows.Forms.Button();
            this.lblMatieres = new System.Windows.Forms.Label();
            this.lblClasses = new System.Windows.Forms.Label();
            this.dataGridViewMatieres = new System.Windows.Forms.DataGridView();
            this.dataGridViewClasses = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNiveaux)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMatieres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClasses)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewNiveaux
            // 
            this.dataGridViewNiveaux.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewNiveaux.Location = new System.Drawing.Point(-41, 165);
            this.dataGridViewNiveaux.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewNiveaux.Name = "dataGridViewNiveaux";
            this.dataGridViewNiveaux.RowHeadersWidth = 51;
            this.dataGridViewNiveaux.Size = new System.Drawing.Size(1013, 308);
            this.dataGridViewNiveaux.TabIndex = 0;
            this.dataGridViewNiveaux.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewNiveaux_CellClick);
            this.dataGridViewNiveaux.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewNiveaux_CellContentClick);
            // 
            // txtCodeNiveau
            // 
            this.txtCodeNiveau.Location = new System.Drawing.Point(200, 25);
            this.txtCodeNiveau.Margin = new System.Windows.Forms.Padding(4);
            this.txtCodeNiveau.Name = "txtCodeNiveau";
            this.txtCodeNiveau.Size = new System.Drawing.Size(265, 22);
            this.txtCodeNiveau.TabIndex = 1;
            // 
            // txtLibelle
            // 
            this.txtLibelle.Location = new System.Drawing.Point(200, 62);
            this.txtLibelle.Margin = new System.Windows.Forms.Padding(4);
            this.txtLibelle.Name = "txtLibelle";
            this.txtLibelle.Size = new System.Drawing.Size(265, 22);
            this.txtLibelle.TabIndex = 2;
            // 
            // txtHoraire
            // 
            this.txtHoraire.Location = new System.Drawing.Point(200, 98);
            this.txtHoraire.Margin = new System.Windows.Forms.Padding(4);
            this.txtHoraire.Name = "txtHoraire";
            this.txtHoraire.Size = new System.Drawing.Size(265, 22);
            this.txtHoraire.TabIndex = 3;
            // 
            // txtRechercher
            // 
            this.txtRechercher.Location = new System.Drawing.Point(200, 135);
            this.txtRechercher.Margin = new System.Windows.Forms.Padding(4);
            this.txtRechercher.Name = "txtRechercher";
            this.txtRechercher.Size = new System.Drawing.Size(265, 22);
            this.txtRechercher.TabIndex = 4;
            this.txtRechercher.TextChanged += new System.EventHandler(this.txtRechercher_TextChanged);
            // 
            // txtCount
            // 
            this.txtCount.Location = new System.Drawing.Point(854, 494);
            this.txtCount.Margin = new System.Windows.Forms.Padding(4);
            this.txtCount.Name = "txtCount";
            this.txtCount.ReadOnly = true;
            this.txtCount.Size = new System.Drawing.Size(92, 22);
            this.txtCount.TabIndex = 5;
            this.txtCount.TextChanged += new System.EventHandler(this.txtCount_TextChanged);
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(480, 25);
            this.btnAjouter.Margin = new System.Windows.Forms.Padding(4);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(100, 28);
            this.btnAjouter.TabIndex = 6;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // btnModifier
            // 
            this.btnModifier.Location = new System.Drawing.Point(480, 62);
            this.btnModifier.Margin = new System.Windows.Forms.Padding(4);
            this.btnModifier.Name = "btnModifier";
            this.btnModifier.Size = new System.Drawing.Size(100, 28);
            this.btnModifier.TabIndex = 7;
            this.btnModifier.Text = "Modifier";
            this.btnModifier.UseVisualStyleBackColor = true;
            this.btnModifier.Click += new System.EventHandler(this.btnModifier_Click);
            // 
            // btnSupprimer
            // 
            this.btnSupprimer.Location = new System.Drawing.Point(480, 98);
            this.btnSupprimer.Margin = new System.Windows.Forms.Padding(4);
            this.btnSupprimer.Name = "btnSupprimer";
            this.btnSupprimer.Size = new System.Drawing.Size(100, 28);
            this.btnSupprimer.TabIndex = 8;
            this.btnSupprimer.Text = "Supprimer";
            this.btnSupprimer.UseVisualStyleBackColor = true;
            this.btnSupprimer.Click += new System.EventHandler(this.btnSupprimer_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 16);
            this.label1.TabIndex = 10;
            this.label1.Text = "Code Niveau:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 62);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "Libellé:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 98);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.TabIndex = 12;
            this.label3.Text = "Horaire:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 135);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "Rechercher:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(792, 494);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "Total:";
            // 
            // btnReinitialiser
            // 
            this.btnReinitialiser.Location = new System.Drawing.Point(612, 98);
            this.btnReinitialiser.Margin = new System.Windows.Forms.Padding(4);
            this.btnReinitialiser.Name = "btnReinitialiser";
            this.btnReinitialiser.Size = new System.Drawing.Size(100, 28);
            this.btnReinitialiser.TabIndex = 8;
            this.btnReinitialiser.Text = "Reinitialiser";
            this.btnReinitialiser.UseVisualStyleBackColor = true;
            this.btnReinitialiser.Click += new System.EventHandler(this.btnReinitialiser_Click);
            // 
            // lblMatieres
            // 
            this.lblMatieres.AutoSize = true;
            this.lblMatieres.Location = new System.Drawing.Point(994, 291);
            this.lblMatieres.Name = "lblMatieres";
            this.lblMatieres.Size = new System.Drawing.Size(131, 16);
            this.lblMatieres.TabIndex = 15;
            this.lblMatieres.Text = "Matières associées :";
            // 
            // lblClasses
            // 
            this.lblClasses.AutoSize = true;
            this.lblClasses.Location = new System.Drawing.Point(994, 28);
            this.lblClasses.Name = "lblClasses";
            this.lblClasses.Size = new System.Drawing.Size(128, 16);
            this.lblClasses.TabIndex = 17;
            this.lblClasses.Text = "Classes associées :";
            this.lblClasses.Click += new System.EventHandler(this.lblClasses_Click);
            // 
            // dataGridViewMatieres
            // 
            this.dataGridViewMatieres.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMatieres.Location = new System.Drawing.Point(997, 309);
            this.dataGridViewMatieres.Name = "dataGridViewMatieres";
            this.dataGridViewMatieres.ReadOnly = true;
            this.dataGridViewMatieres.RowHeadersWidth = 51;
            this.dataGridViewMatieres.Size = new System.Drawing.Size(702, 303);
            this.dataGridViewMatieres.TabIndex = 16;
            // 
            // dataGridViewClasses
            // 
            this.dataGridViewClasses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClasses.Location = new System.Drawing.Point(997, 47);
            this.dataGridViewClasses.Name = "dataGridViewClasses";
            this.dataGridViewClasses.ReadOnly = true;
            this.dataGridViewClasses.RowHeadersWidth = 51;
            this.dataGridViewClasses.Size = new System.Drawing.Size(702, 241);
            this.dataGridViewClasses.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1711, 683);
            this.Controls.Add(this.btnReinitialiser);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSupprimer);
            this.Controls.Add(this.btnModifier);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.txtCount);
            this.Controls.Add(this.txtRechercher);
            this.Controls.Add(this.txtHoraire);
            this.Controls.Add(this.txtLibelle);
            this.Controls.Add(this.txtCodeNiveau);
            this.Controls.Add(this.dataGridViewNiveaux);
            this.Controls.Add(this.lblClasses);
            this.Controls.Add(this.lblMatieres);
            this.Controls.Add(this.dataGridViewClasses);
            this.Controls.Add(this.dataGridViewMatieres);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Gestion des Niveaux";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewNiveaux)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMatieres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClasses)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.DataGridView dataGridViewNiveaux;
        private System.Windows.Forms.TextBox txtCodeNiveau;
        private System.Windows.Forms.TextBox txtLibelle;
        private System.Windows.Forms.TextBox txtHoraire;
        private System.Windows.Forms.TextBox txtRechercher;
        private System.Windows.Forms.TextBox txtCount;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Button btnModifier;
        private System.Windows.Forms.Button btnSupprimer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnReinitialiser;
        private System.Windows.Forms.Label lblMatieres;
        private System.Windows.Forms.Label lblClasses;
        private System.Windows.Forms.DataGridView dataGridViewMatieres;
        private System.Windows.Forms.DataGridView dataGridViewClasses;
    }

}    
    
