﻿namespace GestionEcolePrimaire
{
    partial class NouvelleInscriptionForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NouvelleInscriptionForm));
            this.txtNumInscriptionRecherche = new System.Windows.Forms.TextBox();
            this.txtNomRecherche = new System.Windows.Forms.TextBox();
            this.btnRechercher = new System.Windows.Forms.Button();
            this.dgvResultats = new System.Windows.Forms.DataGridView();
            this.txtNumInscription = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.cmbSexe = new System.Windows.Forms.ComboBox();
            this.txtLieuNaissance = new System.Windows.Forms.TextBox();
            this.dgvParents = new System.Windows.Forms.DataGridView();
            this.btnAjouterParent = new System.Windows.Forms.Button();
            this.cmbAnneeScolaire = new System.Windows.Forms.ComboBox();
            this.cmbNiveau = new System.Windows.Forms.ComboBox();
            this.btnEnregistrer = new System.Windows.Forms.Button();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.dtpDateNaissance = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultats)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParents)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtNumInscriptionRecherche
            // 
            this.txtNumInscriptionRecherche.Location = new System.Drawing.Point(125, 36);
            this.txtNumInscriptionRecherche.Name = "txtNumInscriptionRecherche";
            this.txtNumInscriptionRecherche.Size = new System.Drawing.Size(197, 22);
            this.txtNumInscriptionRecherche.TabIndex = 15;
            // 
            // txtNomRecherche
            // 
            this.txtNomRecherche.Location = new System.Drawing.Point(400, 33);
            this.txtNomRecherche.Name = "txtNomRecherche";
            this.txtNomRecherche.Size = new System.Drawing.Size(150, 22);
            this.txtNomRecherche.TabIndex = 14;
            // 
            // btnRechercher
            // 
            this.btnRechercher.Location = new System.Drawing.Point(757, 25);
            this.btnRechercher.Name = "btnRechercher";
            this.btnRechercher.Size = new System.Drawing.Size(100, 30);
            this.btnRechercher.TabIndex = 13;
            this.btnRechercher.Text = "Rechercher";
            this.btnRechercher.Click += new System.EventHandler(this.btnRechercher_Click);
            // 
            // dgvResultats
            // 
            this.dgvResultats.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResultats.Location = new System.Drawing.Point(6, 102);
            this.dgvResultats.Name = "dgvResultats";
            this.dgvResultats.RowHeadersWidth = 51;
            this.dgvResultats.Size = new System.Drawing.Size(872, 100);
            this.dgvResultats.TabIndex = 12;
            this.dgvResultats.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvResultats_CellClick);
            // 
            // txtNumInscription
            // 
            this.txtNumInscription.Location = new System.Drawing.Point(128, 41);
            this.txtNumInscription.Name = "txtNumInscription";
            this.txtNumInscription.Size = new System.Drawing.Size(150, 22);
            this.txtNumInscription.TabIndex = 11;
            // 
            // txtNom
            // 
            this.txtNom.Location = new System.Drawing.Point(128, 71);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(150, 22);
            this.txtNom.TabIndex = 10;
            // 
            // txtPrenom
            // 
            this.txtPrenom.Location = new System.Drawing.Point(98, 104);
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(150, 22);
            this.txtPrenom.TabIndex = 9;
            // 
            // cmbSexe
            // 
            this.cmbSexe.Location = new System.Drawing.Point(476, 104);
            this.cmbSexe.Name = "cmbSexe";
            this.cmbSexe.Size = new System.Drawing.Size(100, 24);
            this.cmbSexe.TabIndex = 8;
            // 
            // txtLieuNaissance
            // 
            this.txtLieuNaissance.Location = new System.Drawing.Point(126, 135);
            this.txtLieuNaissance.Name = "txtLieuNaissance";
            this.txtLieuNaissance.Size = new System.Drawing.Size(200, 22);
            this.txtLieuNaissance.TabIndex = 6;
            // 
            // dgvParents
            // 
            this.dgvParents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvParents.Location = new System.Drawing.Point(22, 209);
            this.dgvParents.Name = "dgvParents";
            this.dgvParents.RowHeadersWidth = 51;
            this.dgvParents.Size = new System.Drawing.Size(878, 150);
            this.dgvParents.TabIndex = 5;
            // 
            // btnAjouterParent
            // 
            this.btnAjouterParent.Location = new System.Drawing.Point(22, 365);
            this.btnAjouterParent.Name = "btnAjouterParent";
            this.btnAjouterParent.Size = new System.Drawing.Size(182, 30);
            this.btnAjouterParent.TabIndex = 4;
            this.btnAjouterParent.Text = "Ajouter un parent/tuteur";
            this.btnAjouterParent.Click += new System.EventHandler(this.btnAjouterParent_Click);
            // 
            // cmbAnneeScolaire
            // 
            this.cmbAnneeScolaire.Location = new System.Drawing.Point(159, 32);
            this.cmbAnneeScolaire.Name = "cmbAnneeScolaire";
            this.cmbAnneeScolaire.Size = new System.Drawing.Size(200, 24);
            this.cmbAnneeScolaire.TabIndex = 3;
            // 
            // cmbNiveau
            // 
            this.cmbNiveau.Location = new System.Drawing.Point(454, 32);
            this.cmbNiveau.Name = "cmbNiveau";
            this.cmbNiveau.Size = new System.Drawing.Size(209, 24);
            this.cmbNiveau.TabIndex = 2;
            // 
            // btnEnregistrer
            // 
            this.btnEnregistrer.Location = new System.Drawing.Point(252, 734);
            this.btnEnregistrer.Name = "btnEnregistrer";
            this.btnEnregistrer.Size = new System.Drawing.Size(147, 35);
            this.btnEnregistrer.TabIndex = 1;
            this.btnEnregistrer.Text = "Enregistrer";
            this.btnEnregistrer.Click += new System.EventHandler(this.btnEnregistrer_Click);
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.Location = new System.Drawing.Point(472, 734);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(147, 35);
            this.btnAnnuler.TabIndex = 0;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 16);
            this.label1.TabIndex = 17;
            this.label1.Text = "Num Inscription:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(355, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Nom:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 16);
            this.label3.TabIndex = 19;
            this.label3.Text = "Année Scolaire:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(380, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 16);
            this.label4.TabIndex = 20;
            this.label4.Text = "Niveau:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(371, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 16);
            this.label5.TabIndex = 21;
            this.label5.Text = "Date Naissance:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 16);
            this.label6.TabIndex = 22;
            this.label6.Text = "Prénom:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 16);
            this.label7.TabIndex = 23;
            this.label7.Text = "Num Inscription:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 138);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 16);
            this.label8.TabIndex = 24;
            this.label8.Text = "Lieu Naissance:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(369, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 16);
            this.label9.TabIndex = 25;
            this.label9.Text = "Sexe:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(21, 71);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "Nom:";
            // 
            // dtpDateNaissance
            // 
            this.dtpDateNaissance.Location = new System.Drawing.Point(518, 47);
            this.dtpDateNaissance.Name = "dtpDateNaissance";
            this.dtpDateNaissance.Size = new System.Drawing.Size(218, 22);
            this.dtpDateNaissance.TabIndex = 27;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.dgvResultats);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtNumInscriptionRecherche);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtNomRecherche);
            this.groupBox1.Controls.Add(this.btnRechercher);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(920, 218);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Recherche Élève";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtNumInscription);
            this.groupBox2.Controls.Add(this.dtpDateNaissance);
            this.groupBox2.Controls.Add(this.txtNom);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtPrenom);
            this.groupBox2.Controls.Add(this.dgvParents);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.btnAjouterParent);
            this.groupBox2.Controls.Add(this.cmbSexe);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtLieuNaissance);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(18, 236);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(913, 404);
            this.groupBox2.TabIndex = 29;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Inforamtions D\'un eleve";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 187);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(109, 16);
            this.label11.TabIndex = 28;
            this.label11.Text = "Liste des parents";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.cmbAnneeScolaire);
            this.groupBox3.Controls.Add(this.cmbNiveau);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(40, 638);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(891, 81);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Informations scolaires :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 80);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 16);
            this.label12.TabIndex = 19;
            this.label12.Text = "Liste des eleves :";
            // 
            // NouvelleInscriptionForm
            // 
            this.ClientSize = new System.Drawing.Size(943, 774);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.btnEnregistrer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "NouvelleInscriptionForm";
            this.Text = "Nouvelle inscription";
            this.Load += new System.EventHandler(this.NouvelleInscriptionForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResultats)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvParents)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }
        private System.Windows.Forms.TextBox txtNumInscriptionRecherche;
        private System.Windows.Forms.TextBox txtNomRecherche;
        private System.Windows.Forms.Button btnRechercher;
        private System.Windows.Forms.DataGridView dgvResultats;
        private System.Windows.Forms.TextBox txtNumInscription;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtPrenom;
        private System.Windows.Forms.ComboBox cmbSexe;
        private System.Windows.Forms.TextBox txtLieuNaissance;
        private System.Windows.Forms.DataGridView dgvParents;
        private System.Windows.Forms.Button btnAjouterParent;
        private System.Windows.Forms.ComboBox cmbAnneeScolaire;
        private System.Windows.Forms.ComboBox cmbNiveau;
        private System.Windows.Forms.Button btnEnregistrer;
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dtpDateNaissance;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label12;
    }
}