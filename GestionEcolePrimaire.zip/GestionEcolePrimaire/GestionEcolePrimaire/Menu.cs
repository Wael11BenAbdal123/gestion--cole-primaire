﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class Menu : Form
    {
        Otulis o=new Otulis();
        LoginForm a=new LoginForm();
        public Menu()
        {
            InitializeComponent();
            this.Visible=false;
            a.ShowDialog();
        }

        private void gestionDesInscptionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GestionInscription gestionInscription = new GestionInscription();
            gestionInscription.ShowDialog();
        }

     

        private void saisirDesNotesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NoteForm n =new NoteForm(a.b);
            n.ShowDialog();

        }
        private void Menu_Load(object sender, EventArgs e)
        {
            if (a.b != null)
            {
                this.Visible = true;
                //this.Text += "  " + a.b;
                this.Text = "Bonjour !, " + o.Selection("select Nom_Utilisateur from Utilisateur where Code_Utilisateur=" + a.b + ";");
                if (o.Selection("select Role_Utilisateur from Utilisateur where Code_Utilisateur=" + a.b + ";").CompareTo("Secretariat") == 0) ;
                {
                    saisirDesNotesToolStripMenuItem.Enabled = false;
                    gestionDesInscptionsToolStripMenuItem.Enabled = true;


                }
                if (o.Selection("select Role_Utilisateur from Utilisateur where Code_Utilisateur=" + a.b + ";").CompareTo("Enseignant") == 0) ;
                {
                    saisirDesNotesToolStripMenuItem.Enabled = true;
                    gestionDesInscptionsToolStripMenuItem.Enabled = true;


                }

            }
            else
            {
                this.Close();
            }
        }

        private void affectationsDesElevesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            affectationEleve affectationEleve = new affectationEleve();
            affectationEleve.ShowDialog();
        }

        private void gestionUtlisateursToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Gestiondesutilisateurs GU =new Gestiondesutilisateurs();
            GU.ShowDialog();
        }

        private void gestionNivauxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 GN =new Form1();
            GN.ShowDialog();
        }

        private void enseignatsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnseingnantsForm enseingnantsForm = new EnseingnantsForm();
            enseingnantsForm.ShowDialog();
        }

        private void gestionMatieresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MatiereForm matiereForm = new MatiereForm();
            matiereForm.ShowDialog();
        }

        private void gestionDesClassesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClasseForm Gf =new ClasseForm();
            Gf.ShowDialog();
        }

        private void gestionClassToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClasseForm Cf =new ClasseForm();
            Cf.ShowDialog();
        }

        private void gestionTrimstreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GestionTrimestreForm gestionTrimestreForm = new GestionTrimestreForm();
            gestionTrimestreForm.ShowDialog();
        }

        private void gestionAnneeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GestionAnneeScolaireForm g =new GestionAnneeScolaireForm();
            g.ShowDialog();
        }
    }
}
