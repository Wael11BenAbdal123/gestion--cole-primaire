﻿using System;
using System.Data;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class AjoutModificationTrimestreForm : Form
    {
        private Otulis otulis = new Otulis();
        private int? codeTrimestre;

        public AjoutModificationTrimestreForm(int? codeTrimestre)
        {
            InitializeComponent();
            this.codeTrimestre = codeTrimestre;
            if (codeTrimestre.HasValue)
            {
                Text = "Modifier un Trimestre";
                txtCodeTrimestre.ReadOnly = true;
                LoadTrimestreData(codeTrimestre.Value);
            }
            else
            {
                Text = "Ajouter un Trimestre";
            }
        }

        private void LoadTrimestreData(int code)
        {
            try
            {
                string query = $"SELECT Code_Trimestre, Libelle_Trimestre FROM Trimestre WHERE Code_Trimestre = {code}";
                DataTable data = otulis.GetDataTable(query);
                if (data.Rows.Count > 0)
                {
                    txtCodeTrimestre.Text = data.Rows[0]["Code_Trimestre"].ToString();
                    txtLibelleTrimestre.Text = data.Rows[0]["Libelle_Trimestre"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des données : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodeTrimestre.Text) || string.IsNullOrWhiteSpace(txtLibelleTrimestre.Text))
            {
                MessageBox.Show("Veuillez remplir tous les champs.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query;
                if (codeTrimestre.HasValue)
                {
                    query = $"UPDATE Trimestre SET Libelle_Trimestre = '{txtLibelleTrimestre.Text}' WHERE Code_Trimestre = {codeTrimestre.Value}";
                }
                else
                {
                    query = $"INSERT INTO Trimestre (Code_Trimestre, Libelle_Trimestre) VALUES ({txtCodeTrimestre.Text}, '{txtLibelleTrimestre.Text}')";
                }
                otulis.RequtteMiseAjour(query);
                MessageBox.Show(codeTrimestre.HasValue ? "Trimestre modifié avec succès." : "Trimestre ajouté avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de l'enregistrement : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}