﻿using System;
using System.Data;
using System.Windows.Forms;

namespace GestionEcolePrimaire
{
    public partial class AjoutModificationAnneeScolaireForm : Form
    {
        private Otulis otulis = new Otulis();
        private int? codeAnnee;

        public AjoutModificationAnneeScolaireForm(int? codeAnnee)
        {
            InitializeComponent();
            this.codeAnnee = codeAnnee;
            if (codeAnnee.HasValue)
            {
                Text = "Modifier une Année Scolaire";
                txtCodeAnnee.ReadOnly = true;
                LoadAnneeScolaireData(codeAnnee.Value);
            }
            else
            {
                Text = "Ajouter une Année Scolaire";
            }
        }

        private void LoadAnneeScolaireData(int code)
        {
            try
            {
                string query = $"SELECT Code_Annee, Libelle_Annee FROM AnneeScolaire WHERE Code_Annee = {code}";
                DataTable data = otulis.GetDataTable(query);
                if (data.Rows.Count > 0)
                {
                    txtCodeAnnee.Text = data.Rows[0]["Code_Annee"].ToString();
                    txtLibelleAnnee.Text = data.Rows[0]["Libelle_Annee"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors du chargement des données : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEnregistrer_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCodeAnnee.Text) || string.IsNullOrWhiteSpace(txtLibelleAnnee.Text))
            {
                MessageBox.Show("Veuillez remplir tous les champs.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string query;
                if (codeAnnee.HasValue)
                {
                    query = $"UPDATE AnneeScolaire SET Libelle_Annee = '{txtLibelleAnnee.Text}' WHERE Code_Annee = {codeAnnee.Value}";
                }
                else
                {
                    query = $"INSERT INTO AnneeScolaire (Code_Annee, Libelle_Annee) VALUES ({txtCodeAnnee.Text}, '{txtLibelleAnnee.Text}')";
                }
                otulis.RequtteMiseAjour(query);
                MessageBox.Show(codeAnnee.HasValue ? "Année scolaire modifiée avec succès." : "Année scolaire ajoutée avec succès.",
                                "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de l'enregistrement : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAnnuler_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}