﻿namespace GestionEcolePrimaire
{
    partial class AffectationsEnseignantForm 
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewAffectations = new System.Windows.Forms.DataGridView();
            this.txtEnseignant = new System.Windows.Forms.TextBox();
            this.cboClasse = new System.Windows.Forms.ComboBox();
            this.txtCount = new System.Windows.Forms.TextBox();
            this.btnAjouter = new System.Windows.Forms.Button();
            this.btnSupprimer = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblNiveau = new System.Windows.Forms.Label();
            this.cboNiveau = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAffectations)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewAffectations
            // 
            this.dataGridViewAffectations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAffectations.Location = new System.Drawing.Point(19, 13);
            this.dataGridViewAffectations.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewAffectations.Name = "dataGridViewAffectations";
            this.dataGridViewAffectations.RowHeadersWidth = 51;
            this.dataGridViewAffectations.Size = new System.Drawing.Size(747, 369);
            this.dataGridViewAffectations.TabIndex = 0;
            // 
            // txtEnseignant
            // 
            this.txtEnseignant.Location = new System.Drawing.Point(133, 394);
            this.txtEnseignant.Margin = new System.Windows.Forms.Padding(4);
            this.txtEnseignant.Name = "txtEnseignant";
            this.txtEnseignant.Size = new System.Drawing.Size(265, 22);
            this.txtEnseignant.TabIndex = 1;
            // 
            // cboClasse
            // 
            this.cboClasse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboClasse.Location = new System.Drawing.Point(133, 466);
            this.cboClasse.Margin = new System.Windows.Forms.Padding(4);
            this.cboClasse.Name = "cboClasse";
            this.cboClasse.Size = new System.Drawing.Size(265, 24);
            this.cboClasse.TabIndex = 2;
            // 
            // txtCount
            // 
            this.txtCount.Location = new System.Drawing.Point(667, 394);
            this.txtCount.Margin = new System.Windows.Forms.Padding(4);
            this.txtCount.Name = "txtCount";
            this.txtCount.ReadOnly = true;
            this.txtCount.Size = new System.Drawing.Size(92, 22);
            this.txtCount.TabIndex = 3;
            this.txtCount.TextChanged += new System.EventHandler(this.txtCount_TextChanged);
            // 
            // btnAjouter
            // 
            this.btnAjouter.Location = new System.Drawing.Point(413, 394);
            this.btnAjouter.Margin = new System.Windows.Forms.Padding(4);
            this.btnAjouter.Name = "btnAjouter";
            this.btnAjouter.Size = new System.Drawing.Size(100, 28);
            this.btnAjouter.TabIndex = 4;
            this.btnAjouter.Text = "Ajouter";
            this.btnAjouter.UseVisualStyleBackColor = true;
            this.btnAjouter.Click += new System.EventHandler(this.btnAjouter_Click);
            // 
            // btnSupprimer
            // 
            this.btnSupprimer.Location = new System.Drawing.Point(413, 435);
            this.btnSupprimer.Margin = new System.Windows.Forms.Padding(4);
            this.btnSupprimer.Name = "btnSupprimer";
            this.btnSupprimer.Size = new System.Drawing.Size(100, 28);
            this.btnSupprimer.TabIndex = 5;
            this.btnSupprimer.Text = "Supprimer";
            this.btnSupprimer.UseVisualStyleBackColor = true;
            this.btnSupprimer.Click += new System.EventHandler(this.btnSupprimer_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 398);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Enseignant:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 469);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Classe:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(600, 398);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Total:";
            // 
            // lblNiveau
            // 
            this.lblNiveau.AutoSize = true;
            this.lblNiveau.Location = new System.Drawing.Point(16, 435);
            this.lblNiveau.Name = "lblNiveau";
            this.lblNiveau.Size = new System.Drawing.Size(53, 16);
            this.lblNiveau.TabIndex = 5;
            this.lblNiveau.Text = "Niveau:";
            // 
            // cboNiveau
            // 
            this.cboNiveau.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNiveau.Location = new System.Drawing.Point(133, 435);
            this.cboNiveau.Name = "cboNiveau";
            this.cboNiveau.Size = new System.Drawing.Size(265, 24);
            this.cboNiveau.TabIndex = 6;
            this.cboNiveau.SelectedIndexChanged += new System.EventHandler(this.cboNiveau_SelectedIndexChanged);
            // 
            // AffectationsEnseignantForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(961, 627);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSupprimer);
            this.Controls.Add(this.btnAjouter);
            this.Controls.Add(this.txtCount);
            this.Controls.Add(this.cboClasse);
            this.Controls.Add(this.txtEnseignant);
            this.Controls.Add(this.dataGridViewAffectations);
            this.Controls.Add(this.lblNiveau);
            this.Controls.Add(this.cboNiveau);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AffectationsEnseignantForm";
            this.Text = "Affectations Enseignant - Classe";
            this.Load += new System.EventHandler(this.AffectationsEnseignantForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAffectations)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.DataGridView dataGridViewAffectations;
        private System.Windows.Forms.TextBox txtEnseignant;
        private System.Windows.Forms.ComboBox cboClasse;
        private System.Windows.Forms.TextBox txtCount;
        private System.Windows.Forms.Button btnAjouter;
        private System.Windows.Forms.Button btnSupprimer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboNiveau;
        private System.Windows.Forms.Label lblNiveau;
        #endregion
    }
}